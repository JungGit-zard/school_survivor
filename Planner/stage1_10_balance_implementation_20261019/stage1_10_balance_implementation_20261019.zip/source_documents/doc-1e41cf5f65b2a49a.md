# 일회성 영구 랭킹 REST 복원 어댑터 — main 전용

backendmini가 신규 운영 어댑터와 synthetic 테스트만 추가했다. 기존 runtime/rules/backfill script/QA manifest 파일은 이번 작업에서 수정하지 않았다. 실제 인증 토큰 취득·DB 읽기/쓰기는 어댑터로 실행하지 않았다.

## 고정 대상 및 승인 입력
- 프로젝트: escape-zombie-school.
- .env에서 VITE_FIREBASE_DATABASE_URL 한 개를 읽고 HTTPS 및 정확한 escape-zombie-school-default-rtdb.asia-southeast1.firebasedatabase.app 호스트를 검증한다. URL credentials/query/path/다른 host는 거부한다.
- 후보: C:/Users/admin/AppData/Local/Temp/ranking-firebase-audit-20261016/alltime-backfill-candidate.json.
- 검토 입력 SHA-256: 583045768ff21e087de894f6e5c41757c170bada7d6671f12167b29a0ab19520.
- 후보 global 14, stage 22, snapshot 변화 30, 0점 global 4. 실행 시 최신 값에 따라 실제 committed 수는 달라진다.
- --candidate-sha256 필수. 동일 파일 bytes를 hash 대조한 뒤 메모리에 읽은 바로 그 plan만 사용한다. 기본은 GET/dry-run이며 --apply가 있어야 조건부 PUT이 가능하다.

## 쓰기 안전
- 기존 applyReviewedPlan의 전체 경로/필드 preflight와 best-only updater를 그대로 호출한다.
- GET: Authorization Bearer + X-Firebase-ETag:true. PUT: Authorization Bearer + If-Match:직전 ETag. URL에 토큰을 넣지 않는다. redirect 금지 및 요청별 30초 timeout.
- PUT 전마다 실제 current/etag/시각을 repo 밖 새 JSONL journal에 append하고 fsync한다. journal 저장 실패/ETag 누락/인증 오류에서는 PUT을 실행하지 않는다.
- 412일 때 다시 GET하고 updater를 재평가한다. 최대 5회이며 unconditional fallback 없음. 동시 갱신으로 current가 같거나 높아지면 쓰지 않는다.
- PUT 성공 후 GET으로 best>=candidate를 확인한다. 불일치/실패 시 중단한다. 부분 적용은 가능하므로 journal 검토 없이 전체 강제 덮어쓰기를 하지 않는다.
- journal 파일은 repo 밖 realpath 검증 및 wx(기존 파일 덮어쓰기 금지)로 생성한다. 로그/보고에는 집계만 출력한다. public UID별 원문/ETag/스냅샷은 private journal에만 있다.

## 설치된 firebase-tools API 특이점
- C:/Users/admin/AppData/Roaming/npm/node_modules/firebase-tools/lib/auth.js의 getGlobalDefaultAccount()는 {user,tokens}, getAccessToken(refreshToken,authScopes)는 {access_token,expires_at,...}를 반환한다. authScopes 인수가 필수인 실제 코드를 확인했다.
- refreshTokens는 기본적으로 configstore에 갱신 토큰을 저장하므로, 어댑터는 호출 동안 이 프로세스의 configstore set/delete/clear를 메모리 no-op으로 두고 logger.silent=true로 호출한다. finally에서 원래 메서드/로거 상태를 복구한다. 설치 파일·기존 인증 캐시를 수정하지 않는다.
- 토큰 만료/형태/refresh token fallback 반환을 검증한다. refresh/access token은 출력·journal·파일에 쓰지 않는다. 원시 인증 오류도 출력하지 않는다.

## 검증 및 실행 인계
- native PowerShell node --test Developer/r3f_prototype/scripts/ranking-alltime-restore.test.mjs: 9 passed, 0 failed.
- 412 후 동시 최고 보존, 새 ETag 재시도, dry-run PUT 없음, 401 PUT 없음, 412 상한, journal 실패 차단, post-GET 검증 실패, credential cache 저장 억제/복구, host 제한을 synthetic 응답으로 실행했다. 실제 DB 통과 주장이 아니다.
- 두 신규 script에 git diff --check exit 0. main의 npm/build/server는 실행·중단하지 않았다.

아래 명령은 main이 독립 QA 완료 후 실행한다. 처음은 --apply 없는 읽기 전용 검토다. repo root native PowerShell 기준:

```powershell
node .\Developer\r3f_prototype\scripts\ranking-alltime-restore.mjs --candidate 'C:/Users/admin/AppData/Local/Temp/ranking-firebase-audit-20261016/alltime-backfill-candidate.json' --candidate-sha256 '583045768ff21e087de894f6e5c41757c170bada7d6671f12167b29a0ab19520' --journal 'C:/Users/admin/AppData/Local/Temp/ranking-firebase-audit-20261016/restore-dryrun-main.jsonl'
```

main이 dry-run 및 QA를 승인한 뒤에만 새 journal 파일명으로 명시 적용:

```powershell
node .\Developer\r3f_prototype\scripts\ranking-alltime-restore.mjs --candidate 'C:/Users/admin/AppData/Local/Temp/ranking-firebase-audit-20261016/alltime-backfill-candidate.json' --candidate-sha256 '583045768ff21e087de894f6e5c41757c170bada7d6671f12167b29a0ab19520' --journal 'C:/Users/admin/AppData/Local/Temp/ranking-firebase-audit-20261016/restore-apply-main.jsonl' --apply
```

위 명령은 이 worker가 실행하지 않았다. 후보 변경 시 기존 hash로 실행할 수 없으며 다시 검토해야 한다. journal 이름이 이미 존재하면 새 이름을 선택해야 한다. 배포/서버/커밋 없음.
