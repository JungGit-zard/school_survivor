# t_a0c98fd3 WEB Hosting 배포 — BLOCKED / NO-GO

기록 기준: 2026-10-16 08:17 KST 도구 관측. 실행자 launchmini, Advisor-managed direct worker. Board escape-zombie-school. 사용자 권한은 WEB Hosting production에 한정하며 소스 수정, 데이터/rules/functions 배포 및 Play는 제외한다.

## 최종 판정과 정확한 차단점

프로덕션 승격하지 않았다. 현재 라이브와 대응하는 최신 검증 소스를 확정하지 못했다. 단순히 dirty tree라는 이유가 아니라 다음 구체적인 provenance 불일치 때문에 중단한다.

1. canonical 로컬 HEAD는 `6f416d836e355d22a4e348516cca45e194bcc56c`. 이미 배포됐다고 기록된 진행도/로그아웃 보존 수정 `e791a1e3bd1b836a51d8fdd92ab9036bcf196913`은 HEAD의 조상이 아니다(`git merge-base --is-ancestor e791a1e3 HEAD` exit 1). 로컬 HEAD의 깨끗한 clone만 배포하면 이 수정을 누락할 위험이 있다.
2. 원격을 실제 `git fetch origin zombie_only`로 갱신했다. 최신 관측 origin/zombie_only는 `5e1acde061d25017e75d4fd0ff57460208698814`. e791a1e3는 이 원격의 조상이다(exit 0). 하지만 원격 및 e791a1e3에는 `Developer/r3f_prototype/src/components/RosariRoom.jsx`가 없다. `git show e791a1e3:<위 경로>`는 exit 128, `git ls-tree origin/zombie_only <위 경로>`는 빈 결과다. 반면 완료 배포 카드 t_309e540a는 Rosari 방의 실제 라이브 배포/화면 승인과 별도 통합 소스 `15cb067c`를 기록하고 있다. 이 통합 커밋은 fetch 후에도 이 canonical object DB에서 해석되지 않는다. 보존된 `C:/t309r/repo`는 clean HEAD `09477dcc163844cd1e848791937cc68f2f64f160`으로, 나중의 e791a1e3 수정과 결합된 최신 검증 정본이라는 증거가 아니다.
3. 가장 최근 확인한 배포 문서 `Developer/구현기록/빌드배포/web_stage_unlock_release_20261016.md`는 e791a1e3, Hosting version `0acd595a13d3fdc1`, HTML SHA-256 `4597732121311a31bb8e160dcf43982016c99bbfb1f2e005f1a750cfef7551c2`를 기록한다. 이번 실제 라이브 HTML은 SHA-256 `250aad31d435839a5131e4adad5881737391c31e4fd4b4ac8b0b2dab5ab4e873`, entry `/assets/index-63wetOdR.js`다. 기록된 HTML과 바이트가 다르므로 e791a1e3를 현재 라이브 그대로라고 단정할 수 없다. 이 차이가 어느 변경 때문인지, 현재 Hosting version/source가 무엇인지는 미검증이다.
4. canonical의 미커밋 Rosari/Stage5/vending/ranking 및 UI 변경을 임의로 섞어 차이를 해소할 수 없다. 소스 수정 금지이며, 해당 작업들의 최종 통합/release QA도 미완료다. 최신 원격이 현재 라이브 기능을 모두 보존한다는 근거 없이 원격만 택하거나, 과거 방 소스를 임의 overlay하는 것은 허용 범위 밖이다.

필요한 해제 조건: 현재 라이브 version/전체 파일과 연결된 불변 소스·승인 overlay 목록을 확정하고, 기존 라이브 기능 및 e791a1e3 진행도 보존 수정을 포함함을 증명한 검증 소스가 필요하다. 신규 통합/수정은 별도 소유자 작업으로 처리해야 한다. 추가 production 승인 자체가 부족한 것이 아니다.

## 사전 게이트

첫 명령: F: canonical checker, Profile launchmini, Domain auto, TaskSummary hosting-release-deployment. exit 0.
- resolved_domains: common, aab (launchmini 기본값).
- matched_domains: []; match_evidence: [].
- combined_receipt_sha256: `a1566955e910c53872cd1b1f4a872dcfa93eec01da4f9e8da3cbe7a436d2e133`.
- emitted 문서 전체 및 generic launchmini Android Google-login preflight를 절대 경로로 읽음. SESSION_MEMORY는 최신 Entry 1을 확인함.
- AGENTS/project policy/CEO current priorities/최근 release 및 QA 문서를 읽음.
- GSTACK_OK.
- 요청한 escape-zombie-school-product-workflow는 현재 프로필 skill_view에서 not found. 실제 글로벌 정본 `C:/Users/admin/AppData/Local/hermes/skills/software-development/escape-zombie-school-product-workflow/SKILL.md`를 찾아 전체 읽기만 수행했다. 설치/복사/프로필 설정 변경 없음.
- kanban-worker skill 로드. promote-hosting-preview.mjs, firebase.json, .firebaserc와 검증 스크립트를 읽었다. nonce → build → legal/cards → preview asset verify → clone live 절차를 우회하지 않았다.
- execute_code는 동의가 필요하다는 도구 정책으로 거부됐고 재시도하지 않았다. 실제 필독 문서는 native read_file로 확인했다.

## 실제 실행 결과

| 항목 | 실제 결과 |
|---|---|
| git fetch origin zombie_only | exit 0, 원격 갱신; canonical branch/HEAD/작업 파일 변경 없음 |
| 최신 후보 | local HEAD와 fetched origin을 조사했으나 업로드 후보 미선정 |
| npm build / focused tests | 실행 안 함 — immutable source 선택 선행 게이트 차단 |
| 격리 release directory | 신규 생성 안 함 — 출처 불명 소스를 후보로 만들지 않음; 기존 C:/t309r/repo 보존 |
| npm run deploy:hosting:safe | 실행 안 함 |
| preview URL / version | 신규 없음 |
| production promotion | 실행 안 함 |
| node scripts/verify-hosting-assets.mjs --url https://escapezombie.com | exit 0; JavaScript 61개 HTTP/MIME/import 검증 통과. 현재 서비스의 자산 전달 검사일 뿐 신규 배포 증거가 아님 |
| GET https://escapezombie.com/ | HTTP 200, SHA-256 250aad31d435839a5131e4adad5881737391c31e4fd4b4ac8b0b2dab5ab4e873 |
| GET https://escapezombie.com/game | HTTP 200, 같은 HTML SHA-256 |
| GET https://escapezombie.com/landing | HTTP 200, 같은 HTML SHA-256 |
| fresh browser title → 홈페이지로 → /landing | 미실행/미검증. HTTP 200이나 module 검사로 화면 검증을 대체하지 않음 |
| Google login / Firebase 사용자 상태 | 접근·변경·테스트 안 함 |

## 최근 QA와 제외 작업

- t_1e2d9ef7 완료 증거: e791a1e3의 실제 코드를 대상으로 headless Chrome 1000회 memory-adapter 회귀 검증 통과. 실제 Google OAuth 1000회 검증이 아니며 현재 dirty 전체를 승인한 자료가 아니다.
- t_aa02566e: Rosari room polish blocked. 독립 StrictMode 결함의 좁은 수정은 `Quaility_Assurance/rosari_strict_recheck_20261016.md`에서 accepted; 5 files/42 tests, source hash 858f546c6ed263536511ad3de56ee6fc301ae4abe67acb3a9297c45debdd99ec로 기록됨. 이 문서 자체가 post-repair full build/full-wave/deployment 승인은 아니라고 명시한다. 이번 worker가 재시험 또는 현재 해시 일치 검증한 것으로 주장하지 않는다.
- t_c49f88b6: Stage5 playable/vending 통합 blocked; 배포 제외.
- t_133952fc: ranking 최종 운영 검증 blocked; synthetic 검증과 실제 read-only dryrun 구분. rules/functions 및 데이터 복원은 이번 범위에서 완전히 제외.
- canonical 미커밋 Enemies/Enemy/Floor/Game/GameCanvas/Lobby/ReadyGameApp/TitleScreen/RosariRoom/useGameStore, stage5/expansion/vending/랭킹 모듈, database.rules.json/functions/firebase.json, 마케팅·기타 변경 모두 보존하고 배포하지 않았다.
- local HEAD와 원격 사이의 추가 홈페이지/만화 변경도 이번에 검증된 업로드 대상으로 선정하지 않았다. 이미 라이브에 있는지 단정하지 않는다.

## 실행 소유권 및 카드

카드를 처음 읽을 때 의도된 mirror와 달리 dispatcher run1686이 running으로 보였고 이전 run1685는 crashed였다. OS read-only PID 확인에서 5032/20988은 존재하지 않았으며 재조회 때 두 run 모두 crashed, 카드 blocked였다. 이 worker는 delegate/spawn/재디스패치하지 않았다.

`hermes kanban ... block`은 이미 blocked 카드에 대해 `cannot block`을 출력했으나 BLOCKED direct-execution 주석을 추가했다. subsequent show로 blocked와 주석을 확인했다. safeguards/프로필/gateway 설정은 변경하지 않았다. 실행중 카드 조회는 빈 결과였으며 narrowly filtered OS 조회에서 이 카드 prompt를 가진 Hermes/python tree만 관측했다. 이를 머신 전체에 다른 worker가 전혀 없다는 증명으로 확대하지 않는다.

최종 결과는 동일 카드에 comment하고 blocked 상태를 유지한다. done 처리하지 않는다.

## 보호 범위

No source edits, no stash/reset/checkout/삭제, no broad stage/commit/push, no 데이터/rules/functions 배포, no Firebase/Auth 데이터 쓰기, no Play/AAB, no profile/safeguard 변경, no worker spawn. 리포지토리 쓰기는 이 요청 보고서뿐이며 Git fetch는 remote-tracking refs/object만 갱신했다. 읽기 전용 라이브 HTTP 검사로 신규 배포/기능 QA 완료를 주장하지 않는다.
