﻿# Phase 4 storage diagnosis and release hold

Candidate: 62dc162b4db451ea4edef9c8f320340faf822622. Board: t_883d4617 (backendmini), t_eebe49ae (balanceqa), t_e2815ba8 (launchmini). Registered workers exited with code 0; an exit code is not acceptance.

backendmini read-only diagnosis: firebaseAuth.js calls getAuth(app) before setPersistence(inMemoryPersistence). SDK default initialization can probe __sak and firebase:authUser keys. Independently, RTDB module initialization probes firebase:sentinel and uses firebase:host and firebase:previous_websocket_failure. QA recorded key-only operations, not token values. Auth-only modification cannot remove the RTDB operations.

Auth initialization source and SDK dependency files match baseline 641e5f99. This is not evidence of a newly introduced integration regression, nor proof that deployed assets have identical behavior. No verified safe RTDB public configuration was established. A proposed initializeAuth/inMemoryPersistence change remains unimplemented and requires actual OAuth popup/redirect/native regression verification. Global storage suppression, policy exception, or removal of login is not accepted.

Independent QA remains NO-GO. Blocked operations: normal push, minimal live rules publication, and npm run deploy:hosting:safe (which promotes preview to live in the same operation). No operations above were executed in this lane. Live service remains unchanged. The explicit preserve-auth scope and actual-login gate prevent treating an unverified authentication patch as a safe release fix.

Other unresolved acceptance: rendered expansion attack warning/safe-channel proof; external-network-blocked title render is not a live title success result. Stage6-10 actual controlled scenes were captured, but peripheral furniture was not demonstrated by those views.

Verified: 932 tests and build gates passed for identical runtime/test/dist at 7023dca0, preserved through 62dc162b marketing-only merges. Independent focused 38 tests passed; UI10000 completed with 690004 assertions; room narrow portrait/landscape and real pointer release evidence exists. These results do not override NO-GO.

Final local-browser cleanup: final-rendered-evidence.json step21 proves complete original in-memory state restoration (identical=true, stage1, paused; remote writes blocked). Driver CLOSE receipt confirmed. User Chrome and port5173 were not stopped. Candidate git status clean, zombie_only ahead8 of last-fetched origin; no push claim. Audio package remains frozen and included, no duplicate sound writer or deploy.

Evidence: phase4-storage-diagnosis-worker.log; phase2-qa-result.md; ../../../../Quaility_Assurance/integrated_release_20261016/final-bounded-qa-result.md; final-rendered-evidence.json; candidate-ready.json. Full source/test/dist manifests remain authoritative in this directory.
