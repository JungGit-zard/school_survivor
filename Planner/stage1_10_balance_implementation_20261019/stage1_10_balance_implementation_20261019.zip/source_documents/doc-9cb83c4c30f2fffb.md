# t_3beb016a — levelmini 최종 수리 핸드오프

상태: 요청된 gameplay 수리 검증 통과. 전체 집중 회귀는 7개 실패로 승인 차단 상태이며 완료/배포 승인으로 간주하지 않는다. 상세 결과는 gameplay_implementation_result.md 및 gameplay_final_manifest.json 참조.

## 단일 마운트와 소유권

- 실제 마운트는 graphics 소유 `src/components/GameCanvas.jsx`의 `<ExpansionHazardLayer events={expansionAttackSnapshots} resetKey={gameKey} />` 한 곳뿐이다.
- `src/components/Game.jsx`의 중복 마운트와 불필요한 시각 import만 제거했다. gameKey/stage 변경 및 unmount 시 정리 effect, gameover/cleared 시 clearExpansionAttacks 호출은 보존했다.
- GameCanvas/graphics 모듈은 levelmini가 수정하지 않았다. graphics 기존 implementation_handoff.md의 “Game.jsx에서 마운트” 및 단순 이벤트 배열 설명은 오래된 제안이다. 현재 소스와 이 문서의 단일 GameCanvas 마운트가 통합 기준이다.
- graphics: 모델/인스턴스/Floor/Studio/시각 adapter. levelmini: 데이터/공격/풀/스폰/진행/충돌 및 Game cleanup. backend: 저장/랭킹/rules. UI: Lobby/preview/locales. 작업자 호출·dispatch 없음.

## 실제 exports와 소비 경로

- `src/lib/expansionContent.js`: EXPANSION_STAGES, EXPANSION_ENEMIES, EXPANSION_BOSSES, EXPANSION_BEHAVIORS, EXPANSION_LIMITS 및 isExpansionStage/isExpansionEnemy/isExpansionBoss/getExpansionStats. runtime 정본이며 Planner import 없음.
- `src/lib/expansionAttackRuntime.js`: expansionAttackSnapshots(Map), clearExpansionAttacks, createExpansionAttackState, cancelExpansionAttack, stepExpansionAttack, expansionAttackContains, stepExpansionPooledAttack, cleanupExpansionPoolAttacks, resetExpansionPoolAttacks.
- `components/expansion/ExpansionHazardLayer.jsx`: default 및 named ExpansionHazardLayer({events=[],eventsRef=null,resetKey}); named syncExpansionTelegraphs. 위 Map을 읽기 전용으로 소비한다.
- `components/expansion/ExpansionZombieMesh.jsx`: default({type,animPhase='normal',hitFlash=false,staticPose=false}); ZombieMesh 경유 신규 보스 및 forceMesh 렌더.
- `components/expansion/ExpansionZombieInstanceLayer.jsx`: default({resetKey}); GameCanvas 경유 신규 일반 적 code17~31.
- `components/expansion/ExpansionStageEnvironment.jsx`: default({stageId,staticPose=false}); FloorVisual 경유.
- `components/expansion/expansionTelegraphs.js`: EXPANSION_PATTERN_SHAPES, EXPANSION_TELEGRAPH_CAPACITY, createExpansionTelegraphVisual, disposeExpansionTelegraphVisual. 현재 adapter는 실제 snapshot의 복합 형상을 지원한다. 과거 요청 명칭 ExpansionAttackTelegraph/ExpansionEnemyVisual/ExpansionBossVisual을 import하지 않는다.

## Snapshot 계약

Map 값: type/key/attackId/sourceEntityId/patternId/gameKey/originXZ/targetXZ/sourceXZ/directionXZ/yaw/phase/elapsedMs/shape/rangeUnits/widthUnits/windupMs/activeMs/recoveryMs/damage, 복합 패턴의 anglesDeg/angleDeg/offsetsUnits/lineOffsetsUnits 포함.

- phase: windup/active/recovery. windup 시작 시 origin/target 고정; 같은 형상을 피해 판정과 시각이 공유한다.
- shape: disk/three_disks/annulus/line/cross/three_lines/sector/grid. cross는 월드 angleDeg, line/three_lines는 yaw 상대, sector는 directionXZ, annulus 내부반경은 rangeUnits-widthUnits.
- 거리 단위 units; 1block=4units. 신규 맵 장애물 halfX=.6units(.15blocks), halfZ=1unit(.25blocks), 높이1.2units(.3blocks). 중앙 통로 및 포탈 보존.
- 시각 모듈은 피해/게임시간을 생성하지 않는다. 풀 재설정은 runtime.reset→resetExpansionPoolAttacks로 WeakMap 상태를 취소한다. Game의 Map cleanup은 별도 보존했다.

## 내용/진행 보존

정확히 stage6~10 5개, E19~E33 일반15개(code17~31), B05~B09 보스5개(code32~36). 이번 수리는 내용/수치/웨이브 변경 없음.
Stage5 nextStage=null 유지. Stage6는 stage5Clears>=1 이후 로비 진입. 신규6→7→8→9→10→최종 종료. 실제 계약 필드 unlockClearsKey/scoreStageBonus, 기록 키 stageNClears/stageNBestSurvivalSec을 검사한다.

## 실행 증거와 QA

- repair_red: 기존 결함 및 중복 마운트 회귀 재현, exit1.
- repair_green: 통합11 + store6 =17 통과, exit0.
- final: 정상 npm test 사전 게이트 유지, 실제 22파일/424테스트 실행. 417통과/7실패, exit1. 이전289 PASS로 대체하지 않는다.
- Stage5 store2 및 vending store9는 통과. stageVending.test.js 1개와 stageObjectPlacements.test.js 6개는 실패를 그대로 보존했다. Stage1/2 배치와 타 소유 vending 기대값을 통과 목적으로 변경하지 않았다. baseline 원인 귀속이 입증됐다고 주장하지 않는다.
- 실제 Enemy.test.jsx는 없으므로 실제 EnemyMatildaCollider/EnemyMathTeacherSpecial/EnemyChefBossSightExemption 세 회귀 파일을 최종 묶음에 포함했다.
- Graphics/material/screenshot 및 UI10k 검증은 각 작업자 범위이며 본 보고의 승인 대상이 아니다. Balance_QA_Mini는 실패7건의 기존 배치/자판기 정합을 먼저 확인하고 보스10패턴·중앙 통로·pause/death/reset을 최종 플레이로 인계받는다.
- full build는 Advisor. 브라우저/서버/Firebase 실데이터/배포/커밋/정책 변경은 수행하지 않았다. 원격 저장 또는 시각적 최종 QA 완료를 주장하지 않는다.
