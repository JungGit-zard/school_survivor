# Rosari room 현재 소스 인계 — t_aa02566e

상태: IMPLEMENTED / CURRENT FOCUSED TESTS PASS / INDEPENDENT QA PENDING / NOT RELEASE ACCEPTED.
작성 기준: 2026-10-15T16:33Z (한국 2026-10-16). 담당 uimini, 유일한 room writer.
정본 루트: F:/From_SSD_D_20261005/JungSil/2.Minigame_project/school_survivor-integration
카드는 Advisor-managed blocked mirror 유지. dispatch/unblock/complete/추가 worker 없음. 배포/커밋/푸시/빌드 없음.

이 문서는 이전 timeout 중심 보고를 현재 결과로 갱신한다. 이전 rosari_focused_green_20261016.log의 4 files/37 PASS는 마지막 변경 전 결과이므로 현재 acceptance 근거가 아니다. 이전 DPR2/3 이미지도 INVALID 상태를 유지하며 이번 새 이름의 증거와 혼합하지 않는다.

## 필수 게이트 / 역할

첫 명령 checker exit0, matched_domains graphics/ui/qa/backend, evidence visual/ui/qa/auth(authorized의 auth 부분문자열). backend는 매칭됐지만 실제 변경 권한으로 해석하지 않았다. 기본 UI 및 common 포함, 필독 문서 전부 읽음. 상대경로 read_file 도구 cwd 불일치는 F 절대경로로 해결. gstack 및 profile gstack 모두 OK. systemic-debugging/test-driven-development/kanban-worker와 gstack browse 절차를 로드했다. 신규 QA 기록으로 latest required가 바뀐 뒤 checker 재실행 exit0, 변경 문서를 다시 완독했다. 최종 receipt 5f62323a7320e14715a56e6e955d82cf93a06854fff0b6c1535f38b13fe3b9ef, 원문 rosari_completion_gate_receipt.json. 프로필/정책/가드는 편집하지 않았다.

## 이번 수정 범위

- src/components/RosariRoom.jsx: 누락된 export disposeRosariModel 구현. RosariModel의 useGLTF clone은 모든 surface 재질을 새 toon 재질로 교체한 뒤 사용하므로 그 복제본만 정리한다. material Set, outline geometry Set으로 배열/여러 메시 공유를 한 cleanup 안에서 한 번만 dispose한다. surface geometry, material.map, 공유 toon gradient texture에는 dispose하지 않는다. cached GLTF 원본에 호출하는 범용 함수가 아니다.
- 같은 소스: 실제 부모 width가 0보다 크고 280 미만일 때 compact 분기. 제목 16px, subtitle hidden. 일반 390px 및 landscape sideRail 분기, 44px controls, 원래 카메라/이동/충돌/GLB/normalMatrix는 유지.
- RosariRoom.outline.test.jsx: 기존 oracle 보존, 같은 material 배열/두 메시 및 같은 hull geometry 공유 시 단 한 번 해제하는 회귀 테스트 추가.
- 기존 rosari-room-visual-qa.js만 확장: renderer DPR 1/2/3 명시 설정·원상복귀, 실제 buffer 크기 기록, 연속 180 rAF pose/행렬/geometry/texture 관측. 앱에서는 import하지 않는 개발 전용 하니스다. rosari-room-qa.html은 변경하지 않았다.
- mobileInteraction/titleEntry/helper tests 및 movement helper는 이번 continuation에서 편집하지 않았다. 이전 continuation의 전용 테스트 및 소스 변경은 그대로 보존했다.
- App/ReadyGameApp/TitleScreen/shared models/GLB/Firebase/Auth/audio/Stage5/vending/프로필 config/memories/plugins는 이번 실행에서 수정하지 않았다.

## 현재 RED → GREEN 증거

모두 Developer/r3f_prototype cwd, 정상 npm test 경로. pretest/branch/no-legacy-B02/dialogue/Studio sync 가드 우회·축소 없음. 중복 외부 Vitest 실행 없음.

1. rosari_dispose_red_20261016.log를 읽어 기존 재현 확인.
2. rosari_completion_red_20261016.log: 정상 npm test -- src/components/RosariRoom.outline.test.jsx src/components/RosariRoom.mobileInteraction.test.jsx → exit 1. 3 failed / 31 passed. disposeRosariModel missing 2건 + compact 20px != 16px 1건. 의도한 원인으로 실패.
3. 최소 소스 수정 뒤 rosari_completion_green_20261016.log → exit 0, 4 files / 40 tests PASS.
4. 최종 source+tests hash freeze 후 다시 아래 명령 실행:
   npm test -- src/lib/rosariRoom.test.js src/components/RosariRoom.titleEntry.test.jsx src/components/RosariRoom.mobileInteraction.test.jsx src/components/RosariRoom.outline.test.jsx
   rosari_completion_final_focused_20261016.log → exit 0. 현재 검증의 정본 로그.
5. git diff --check 전용 소스/테스트 통과. node --check rosari-room-visual-qa.js 통과.
6. 최종 테스트 후 manifest 8/8 SHA256 재계산 일치(FROZEN_HASHES_MATCH 8).

주의: error-boundary 테스트가 의도적으로 던지는 `Error: room load rejected`가 jsdom stderr에 나타난다. 테스트 실패/undefined symbol이 아니며, 로그를 삭제하거나 oracle를 약화하지 않았다. 오류 없는 pristine log라고 주장하지 않는다.

## 실제 브라우저 확인

- 현재 5173 소유 프로세스 PID18844, F 정본의 Vite --host 0.0.0.0 --port 5173 --strictPort 확인. 기존 서버 readiness GET http://localhost:5173/rosari-room-qa.html HTTP200. 서버/keepalive 시작·정지·변경 없음.
- 매 launch 시 npm run browser:reserve 정상 가드 통과, 관측 GAME_BROWSER_INSTANCES=2 LIMIT=3.
- gstack 기본 headless는 D:/DevCache/playwright의 Chromium executable 누락으로 실패. 설치/설정 편집 없이 지원되는 GSTACK_CHROMIUM_PATH='C:/Program Files/Google/Chrome/Application/chrome.exe' + browse --headed로 설치된 Chrome 실행 성공. 이후 명령도 --headed 유지.
- 기존 하니스 로드 후 browser 메모리에서 R3F _roots store를 연결. Firebase 접근/변경 없이 독립 방만 사용.
- constrained 실제 부모 219x390: rosari_completion_compact.png와 rosari_completion_compact_metrics.json. 제목 한 줄 16px, subtitleHidden true, root overflow false, canvas 197x202, stage 203x208, D-pad 44x44, 타이틀/옷장 버튼 height44 확인. 실제 방과 가구 렌더 확인. 작은 부모에서 캐릭터가 작게 보이는 사실까지 없앴다고 주장하지 않는다.
- 390x844 부모에서 renderer DPR 1/2/3 비균일 스케일 45도 outline on/off 원본 framebuffer 확보. 실제 CSS canvas 368x641.59375. buffer는 368x641 / 736x1283 / 1104x1924. devicePixelRatio는 계속1이다. 이것은 유효한 renderer DPR2/3 증거지만 device DPR2/3 emulation/기기 검증은 아니다. 앱의 dpr=[1,1.5]를 바꾸지 않고 개발 하니스에서만 override 후 restore했다.
- rosari_completion_raw_dpr{1,2,3}_{false,true}.png는 gl.render와 같은 JS task 안에서 canvas.toDataURL로 얻은 원본. 같은 이름의 .txt는 실제 base64 응답. rosari_completion_render_dpr{1,2,3}.json은 renderer/buffer/viewport 관측이다. CSS 해상도의 rosari_completion_render_dpr*.png와 원본 framebuffer를 혼동하지 않는다.
- DPR3 원본을 직접 열어 확인: 얼굴을 덮는 검은 오염이나 큰 silhouette spike는 해당 45도 샘플에서 관찰되지 않았다. 모든 각도/모든 동작의 아트 승인으로 확대하지 않는다.
- rosari_completion_dpr_raster.json: 실제 on/off 중간60% row extents 진단. 세 DPR 모두 중앙값 2 CSS px. p95는 6/6/5.667, max는24/22.5/25. 수평 단면 거리이므로 경사진 모서리의 normal 두께와 다르며 이 값으로 모든 edge가 정확히2px라고 합격 처리하지 않는다.
- rosari_completion_stability.json: 실제 연속 180 rAF, 180개 서로 다른 팔 pose, 모든 world matrix finite, geometry110/texture2 유지, x 이동0.001665→3.6. 단일 고정 walk pose가 아니다. 장시간 기기 FPS/육안 temporal flicker/video 승인은 미검증.
- rosari_completion_occlusion.png: frame loop never에서 캐릭터를 옷장 뒤(-2.85,0,-2.5)에 두고 실제 furniture visible 상태로 렌더. 몸 outline은 옷장 면을 뚫어 보이지 않고 상단에 머리 윗부분만 노출됨을 직접 이미지 확인. 충돌을 우회한 browser 메모리 전용 렌더 테스트이며 실제 이동 규칙을 바꾸지 않았다. 이후 pose/camera/room/DPR/frameloop restore.
- console에는 출처 미확정 resource HTTP401/404 두 기록이 남음(rosari_completion_browser_errors.log). 렌더 성공과 별개로 콘솔 완전 무오류 PASS를 주장하지 않는다. network 기록만으로 실패 URL을 확정하지 못했다.
- 종료 browse --headed stop 호출 뒤 CLI가 connection lost→재시작을 시도하고 기본 Chromium 누락 오류를 출력했다. 종료 후 CIM 조회에 browse server-node/Vitest 없음, 기존5173 PID18844 유지 확인. 브라우저 종료 명령의 깨끗한 exit를 주장하지 않는다.

## 해시 고정·독립 QA 인계

정본 manifest: Developer/agent_room/rosari_completion_source_tests_manifest.json.
기존 main 소유 final-artifact-hashes.json은 수정하지 않았다. manifest는 runtime+전용4 tests+helper+기존2 harness를 포함하며 자기 참조 해시는 포함하지 않는다.
- RosariRoom.jsx SHA256: 40d7d7b9dd710daf73c977451a26d45e14fb1a5461d49d47375f600a733a9895
- RosariRoom.outline.test.jsx SHA256: 6c6e8762c23ba6120acb3f52909d6dfdde75cf1228b41da5d4a1d91bf347a8d0

Advisor/balanceqa는 이 frozen manifest와 final focused 로그를 먼저 소비하고 독립 QA한다. 카드는 blocked 유지, 최종 완료/릴리스 승인은 Advisor 소유다. 이번 source/test correction은 완료했으나 production build, 완전한 시각 acceptance, 물리기기 DPR2/3, 장시간 temporal flicker/성능은 미승인이다. 정상/landscape DOM·camera 회귀는 focused suite로 검증했지만 이번 continuation에서 전체 portrait/landscape 브라우저 행렬을 새로 촬영한 것은 아니다. 이전 다각도 자료는 역사적 보조 근거일 뿐 현재 freeze 이후의 독립 검증을 대체하지 않는다.
