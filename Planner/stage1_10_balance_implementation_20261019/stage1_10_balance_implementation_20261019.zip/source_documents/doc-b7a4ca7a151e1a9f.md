# Owner priority: Rosari room maximum quality

Latest Terry instruction: 방은 할수있는 모든짓을 전부 다 총동원해서 최고로 만들어.
This expands QUALITY within Rosari room, not permission for destructive operations or unrelated rewrites. Reuse existing specialist owners; no duplicate runtime writers.

## Mandatory outcome
- A finished, readable, polished room rather than a tiny canvas demo. Preserve approved character model, face/colors, furniture and movement/collision semantics. No silent model replacement.
- Room-only responsive composition: portrait, landscape and narrow 9:16 host. Camera fits actual bounds/aspect; prevent tiny character, clipped furniture, title overflow and controls consuming the scene.
- Actual matrices: 320x740, 360x800, 390x844, 844x390, constrained 219x390; dynamic resizing, DPR1/2/3 when feasible. Record actual tested and untested cases, no invented PASS.
- Character outline exactly 2 CSS px across DPR/resizing; prevent initial 1x1 viewport regression. Preserve approved visual identity. Improve room-local visual hierarchy and consistency where demonstrably useful; do not change global title/Studio or add arbitrary effects that hurt readability.
- Movement: keyboard plus 44px minimum touch targets, clear pressed state, reliable pointer capture/release/up/cancel/lostcapture/blur/visibility handling. No stuck motion. Preserve furniture collision and wardrobe proximity.
- Wardrobe: clear nearby action, useful focus/labels, stable open/close, always reachable independent close button, border-box bounded dimensions, working vertical touch scrolling. No viewport overflow, no movement input leaking through modal.
- Loading/error/return states: useful room-scoped feedback, no blank screen, predictable return without changing shared auth/title lifecycle.
- Mobile cost: no avoidable React rerender loop, duplicate listeners, leaked geometry/materials or repeated model fetch/clone allocation; measure where possible. Do not claim device FPS from desktop unit tests.
- Accessibility: readable Korean labels/contrast, focus visibility and keyboard-accessible controls. Motion should not reduce usability.

## Execution ownership
uimini existing t_aa02566e owns RosariRoom.jsx and room-specific helpers/styles/tests only. Finish actual implementation first, then behavioral tests and exact change/hash/report. Read this as newest quality acceptance; preserve other dirty work. Do not abandon Stage5 ownership silently or create competing writers.
Independent balanceqa room review must use frozen artifact hashes after implementation; parallel read-only review/oracle allowed. QA must test the true constrained parent layout, not only standalone fullscreen. Return actionable failures for owner to repair; never weaken tests.
If threemini room shader advice is needed, read-only review first; any write handoff requires UI owner freeze and explicit disjoint paths. Current Stage5 worker must not silently edit RosariRoom concurrently.

## Finish evidence
Focused tests with intact pre/post gates, production build gate during final release phase, real browser screenshots for portrait/landscape/constrained host and wardrobe open/closed, actual outline/DPR evidence, changed paths/hashes, remaining defects and honest limits. Browser reserve and existing server-stop fence remain: do not restart stopped servers without release coordinator approval; surface screenshot blocker if still off. No approval/production deployment claim until independent review.

## Non-goals / safety
No new gameplay economy, cloud wardrobe persistence, unapproved audio, character remodelling, paid service/install, destructive cleanup, hook bypass, auth/Firebase live writes, broad staging or automatic production deployment from this brief.
