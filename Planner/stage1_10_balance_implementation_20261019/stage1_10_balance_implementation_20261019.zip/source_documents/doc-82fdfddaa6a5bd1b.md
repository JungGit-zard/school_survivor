# 인구 보강 구현 검토 — 읽기 전용 / 미적용

검토 관측: 2026-10-19T00:19:35.902493+09:00. 기존 blocked 미러 t_b7475ffc 재사용. 런타임/퍼블리셔 단독 오너는 launchmini. 신규 카드·dispatch·unblock 없음. 독립 balanceqa의 실제 브라우저 QA와 별개인 정적 소스 리뷰다. 테스트/빌드/브라우저/서버/배포를 실행하지 않았다.

## 결론 및 소스 결속

**전체 Stage 5–10 요구 충족 판정은 NO. Stage 6–10은 명백히 미지원이며 대체 실행 경로가 없다. Stage 5는 이 expansion guard에 제외되지 않는다.** Stage 1–5는 해당 경로가 연결되어 있다는 소스 판단이지, 실제 20마리 원자 생성의 런타임 합격 판정이 아니다.

후보: F:/From_SSD_D_20261005/JungSil/2.Minigame_project/releases/owner-all-complete-20261018.
Developer/agent_room/owner_all_20261018/integration-ready.json의 sourceHashManifest는 533c7977c5a5cfdd3ac1e00cdd69f65dffeaf38a5dbd2dcbed388aebc26064f1. 본 리뷰의 핵심 소스 8개 SHA-256을 그 manifest 항목과 직접 대조하여 모두 일치했다. 이는 전체 freeze/dist 재검증이 아니다. Git HEAD 408fb6a89626acf51327b3a022ad4eb5878456be와 sourceHashManifest는 서로 다른 식별자이며 혼동하지 않는다. 개별 해시는 동명 JSON에 기록했다.

현재 필독 체커 exit 0: matched_domains gameplay, qa / match_evidence gameplay:gameplay, qa:qa. combined_receipt_sha256=89a2613c9455e301a4d91ba8a93e7411a36deb36fa51b99cb4e2fa05d3e32656으로 기존에 읽은 필독 문서 영수증과 같아 재사용했다. 범위 검토 priority-population-scope-review.md 및 Planner/stage5_full_release_plan.md, Planner/current_game_rules.md를 읽었다. 오래된 current_game_rules의 시간 값을 현재 후보 수치로 덮어 해석하지 않았다. 브라우저를 사용하지 않아 gstack browse를 실행/재활성화하지 않았다.

아래 소스 경로는 후보 Developer/r3f_prototype/src/ 기준이다.

## 실제 호출 경로와 지원 범위

1. components/Enemies.jsx:1924–1933은 totalZombieCounts의 pooledActive + specialActive를 저밀도 타이머에 전달한다. 화면 내 수가 아니라 전역 생존 수다. :1613–1617 및 :1240–1249에서 사망/삭제대기/무효 special은 제외한다. 보스 등 ENEMY_STATS에 있는 special은 포함하며 DOGE 이벤트를 좀비로 더하지 않는다.
2. lib/usePlayingFrame.js:16–22는 playing일 때만 콜백을 실행한다. lib/gameplayFrameTime.js:4–5,21–35는 1/60초 fixed-step, raw delta 최대 0.5초를 사용한다. 따라서 여기서 10초는 활성 시뮬레이션 시간이지 비활성/백그라운드 벽시계 10초가 아니다.
3. lib/lowDensityReinforcement.js:2–7,30–55는 <=3, 연속 활성 10초, E07×10/E01×10을 정의한다. >3이면 streak를 0으로 한다. 다른 예약은 생존 수로 계산하지 않으며 queuedEnemyCount 인자는 실제 타이머 로직에서 사용하지 않는다. 20슬롯 부족이면 timer readiness를 보존한다.
4. 임계 도달 시 :53에서 pending=true로 바뀌지만 Enemies.jsx:1936의 !isExpansionStage(stageRuntime.id)가 expansion enqueue를 차단한다. :1934–1937의 retry도 같은 guard 내부다. expansion에서 pending만 잠기고 소비/finish로 이어지지 않는다.
5. lib/expansionContent.js:2211–2219의 API는 DATA.stages를 사용한다. 실제 키는 stage6,stage7,stage8,stage9,stage10뿐이다. Stage 5는 lib/stageConfig.js:129–145에 별도 정의되며 isExpansionStage('stage5')는 false다. 따라서 문제 범위를 'Stage5–10 모두 guard로 차단'이라고 쓰면 부정확하다.
6. 허용된 stage에서는 Enemies.jsx:1489–1499 enqueue → :1416–1429 RAF schedule 소비 → :1689–1700의 전용 consumer로 연결된다. count=20 및 batch.length=20을 요구하고 addEnemies(batch,false,cache.spawnToken)으로 즉시 pooled 생성한다. 3/RAF spawnDrain을 사용하지 않는다.
7. 전용 kind=9의 enqueue 호출은 :1937이고 소비는 :1689다. expansion BURST :1766–1774/:2068–2070은 시간표 사건이지 이 조건 기반 보강의 대체 경로가 아니다. catch-up은 :1969에서 expansion offset=0이며, dominance 역시 :2016에서 expansion 제외다. dominance 80 E07/가시 수 catch-up으로 population 요구를 대체할 수 없다. overtime도 별도 시간 기반 경로다.

| 범위 | 소스상 전용 보강 연결 | 판정 |
|---|---|---|
| Stage1–4 | 연결됨 | 기존 범위. 본 작업에서 재실행하지 않음 |
| Stage5 | 연결됨, expansion 아님 | guard 미지원 주장의 예외. 명세 정합/실행 QA 별도 |
| Stage6–10 | timer는 호출, enqueue 차단 | 전체 playable population 요구에 NO_GO |

## E07/E01 설정·캐시·풀링 실체

- components/Enemy.jsx:346 E01={hp:8,speed:0.5225,damage:8,scale:1,xp:4,contactDist:0.28}; :366 E07={hp:16,speed:1.045,damage:16,scale:1,xp:8,contactDist:0.28}. 두 타입 모두 실제 기본 설정이 존재한다. 이를 새 expansion 적으로 복제하거나 다른 적 수치를 올릴 필요가 없다.
- lib/expansionContent.js:2220–2226의 getExpansionEnemy/getExpansionStats는 expansion 전용 적/보스만 조회한다. DATA.enemies에는 E01/E07이 없다. getExpansionStats('E01'/'E07')만 조회하면 null이다. 그러나 전역 ENEMY_STATS에는 기본 타입과 ...EXPANSION_STATS(:392)가 함께 존재한다. nonexistent getExpansionEnemyConfig 같은 API를 가정하면 안 된다.
- Enemies.jsx:1375–1395의 stageRuntimeCacheRef는 id/gameKey/spawnToken/bounds/burstEvents/obstacles/stageConfig만 캐시한다. **enemyConfig 필드는 현재 없다.** buildLowDensityReinforcementBatch(:1252–1270)는 ENEMY_STATS를 직접 읽고 stageHpOverride(:1037–1042)를 사용한다. :828–830은 expansion existingEnemyHpMultiplier를 읽으므로 기존 적의 현재 스테이지 HP 규칙을 그대로 재사용해야 한다.
- lib/enemyEntityPool.js:3,8,25에서 cap=150, E01 code=1, E07 code=15. Enemies.jsx:1111,1146–1150에서 둘 다 일반 pooled 타입이다. :1592–1601은 실제 ENEMY_STATS와 statOverride로 spawnInto를 호출한다.
- buildLowDensityReinforcementBatch의 첫 위치 경로는 :1260→:310–313→:299–302로 expansionSpawnPosition까지 도달 가능하다. lib/expansionSpawns.js:3–18은 명시 scale override를 받을 수 있어 E01/E07의 expansion 전용 stats 부재가 자동 차단을 뜻하지 않는다.
- 다만 :1261–1264의 legacy formation fallback(:244–268)은 expansion safe ring의 최소거리/개체 간격을 동일하게 보장하지 않는다. guard만 제거하면 이 fallback까지 expansion에 확장된다. 실패 시 batch<20이면 소비를 연기하는 기존 안전책을 보존해야 한다.
- consumer의 길이/슬롯 선검사는 동기 20마리 생성 의도다. 하지만 addEnemies(:1619–1641)는 spawnPooledEnemy 반환 성공 수를 검증하지 않고, consumer는 곧바로 finish한다. 따라서 현재 소스만으로 'spawnInto 실패까지 포함한 실제 전부 아니면 전무 원자성'을 증명할 수 없다.

## Stage5 authored spec 충돌

정본 Planner/stage5_full_release_plan.md:5,15–20은 명시 버스트를 실제 공급 정본으로 기술하고, :18은 보스 후 10초 읽기 여백을 의도한다. 전역 저밀도 보강과 catch-up이 발화하면 이 여백/총 공급량은 별도 예외가 된다. 이 문서는 :11에서 Stage5를 마지막 스테이지로 두지만 후보에는 Stage6–10 데이터도 있다. 이는 작성 시점/범위 차이며 이번 인구 수정으로 진행 경로까지 바꿀 권한이 생기지 않는다.

최신 오너의 전역 population 요구를 보조 예외로 명시하는 최소 명세 정합이 필요하다: '기존 고정 시간표는 유지하되, 실제 전역 생존 <=3이 활성 10초 연속이면 E07×10/E01×10 추가; 다른 적 수치/보스 시각/HP 조건/가시 수 조건은 변경하지 않음.' Stage5를 expansion으로 편입하거나 기존 stage5 시간표를 수정하는 해결은 제안하지 않는다. 본 작업은 Planner 파일을 수정하지 않았다.

## 최소 안전 패치 제안 — TEXT ONLY, 미적용

launchmini가 별도 수정/재동결할 경우의 최소 범위는 Enemies.jsx의 캐시·전용 builder·dispatch·consumer와 해당 통합 테스트다. expansionContent 데이터/Enemy 스탯/타 스폰 시스템/백엔드 규칙은 바꾸지 않는다.

A. :1387–1395 캐시 생성 시 기본 ENEMY_STATS.E07/E01과 stageHpOverride(type,currentStageId)로 두 타입의 reinforcement 설정을 캐시한다. 새 필드 이름은 예를 들어 reinforcementEnemyConfig이며 '기존 enemyConfig가 있다'고 가정하지 않는다. hp/scale 유효성 및 pooled 타입을 검증한다. 지원 stage 집합은 명시적으로 stage1..stage10만 포함한다. 유효하지 않으면 timer를 pending으로 만들지 않는 readiness gate를 타이머 전단에 둔다.

B. :1252–1270에서 Stage1–5의 기존 배치를 보존한다. Stage6–10은 캐시의 E07/E01 scale을 넘겨 아래 실제 API만 사용한다. expansion에서는 legacy formation fallback을 쓰지 않고 20개 안전 위치가 모두 확보되지 않으면 아무것도 생성하지 않고 deferred 재시도한다.

```js
// 제안 의사 코드. 실제 API 인자 순서만 명시. 적용하지 않음.
const pos = expansionSpawnPosition(
  type, cache.id, playerPos, cache.bounds,
  taken, cache.obstacles, random,
  cache.reinforcementEnemyConfig[type].scale,
)
```

C. 설정/배치 준비 후 :1936의 blanket !isExpansionStage를 '명시 supportedStage + 검증된 reinforcement config' eligibility로 교체한다. timer와 enqueue가 같은 eligibility를 공유하게 해 pending-only 잠금을 없앤다. 기존 pending/deferred/단일 kind=9/phase/stage+gameKey/spawnToken fencing을 보존한다. dominance/catch-up guard는 건드리지 않는다.

D. :1689–1700은 count=20, E07 정확히10/E01 정확히10, 안전 위치20을 확인한 뒤 같은 RAF에 전부 실제 pool로 commit한다. 기존 addEnemies(false)는 부분 실패 반환을 감추므로 엄격한 원자성은 별도 작은 low-density 전용 commit seam에서 검증해야 한다. 실제 사용 가능한 pool 슬롯을 선확보하고 spawnInto 실패 시 이 배치의 생성 handle만 rollback하며 finish/encounter 부수효과는 성공20 확인 뒤에 수행한다. 실패는 새 적0·pending/deferred 유지로 끝낸다. pool 일반 동작을 재작성하거나 cap을 늘리는 것은 최소 패치가 아니다. 장애물 때문에 20개 안전 위치가 없으면 '정확히 10초 즉시20' 보장은 안전과 양립하지 않으므로 강제 근접 스폰 대신 연기를 명시한다.

## 필요한 Red/Green 통합 seam — 실행하지 않음

components/Enemies.test.jsx:105–230에 실제 Enemies frame→scheduler→pool 통합 seam이 이미 있다. 현재 state는 :109에서 stage1 고정이며 :245의 builder 안전성 매개화도 stage1–4뿐이다. helper-only 또는 문자열 포함 검사(:261–274)는 expansion guard 결함을 잡지 못한다. components/Enemies.stage5.test.jsx:20–106은 실제 시간표 seam이며 저밀도 expansion 검증의 대체가 아니다.

- RED: 기존 실제 Enemies 통합 seam을 stage5..stage10으로 매개화. 실제 stage 캐시/배치/consumer/pool을 유지하고 오직 주변 무관 효과·고정 시간표 사건만 격리한다. 기존 test의 catch-up 격리 패턴은 쓰되 lowDensity dispatch를 mock하지 않는다. 현재 Stage6–10에서는 활성 10초 후 RAF를 flush해도 kind9/실제 E07/E01 증가가 없어 실패해야 한다. Stage5는 같은 guard 실패를 기대하지 않는다.
- GREEN: usePlayingFrame의 실제 playing gate/fixed-step 경로에 frame 공급하고 9.999초 무보강, 임계 10초 후 단일 소비에서 E07+10/E01+10 및 global alive+20을 확인. fake scalar frame(delta=10)만으로 active-clock 수용 판정을 대신하지 않는다. delta 공급은 실제 1/60초 계약 또는 기존 fixed-clock 함수 사용.
- 전역 수 회귀: 화면 밖 pooled 적도 포함, 살아 있는 special/보스 포함, 사망/삭제 대기 제외. HP·처치속도·화면 수와 무관. >3에서 streak 리셋, pause/levelup/dialogue 동안 진전/소비 없음, stage/retry/gameKey 변경 시 과거 요청 폐기.
- 원자성 회귀: 20슬롯 미만·schedule ring full·안전 위치 부족·주입된 spawnInto 실패에서 새 적0/중복0, 안전 조건 회복 시 정확히20을 한 RAF에 생성. spawnDrain max3/RAF로 분할되지 않음. 성공 뒤 다음 연속10초로 반복 가능.
- 실제 stage별 bounds/obstacle 및 spawnPolicy의 최소/최대 거리를 각 데이터 값 그대로 검증한다. 거리 증거는 units 및 /4 blocks 병기. 기본 비expansion 링 4–6.5 units는 1–1.625 blocks지만 expansion에 이를 임의 복사하지 않는다. 타입 HP override 및 원래 speed/damage/scale 유지도 검증한다.

## 백엔드 의존성과 인계

이 저밀도 판정→kind9→builder→pool 생성 경로에는 Firebase stage whitelist 승인 API가 없다. E07/E01은 이미 로컬 기본 적이며 spawn hotfix를 위해 백엔드 whitelist나 규칙 배포를 선행할 필요는 없다. 단 Planner/stage5_full_release_plan.md:31,34의 stage 기록/랭킹 저장 whitelist 확인은 전체 게임 영속 저장 QA의 별도 의존성이다. 현재 실제 규칙을 검사하거나 통과했다고 주장하지 않는다.

launchmini: 전체 Stage1–10 population 충족 표기는 현 freeze에서 금지. 필요한 범위만 수정·해당 RED/GREEN 실행·새 freeze·독립 balanceqa QA 후 단일 publisher 절차를 따른다. 이는 발행 승인이나 이번 작업의 향후 실행 약속이 아니다. 오너 우선순위 population을 dominance/visible catch-up 조정으로 바꾸지 않는다. 기존 fences blocked 유지.
