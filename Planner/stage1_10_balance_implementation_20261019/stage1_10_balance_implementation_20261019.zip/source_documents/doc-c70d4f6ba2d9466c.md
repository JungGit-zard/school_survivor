# 자판기 릴리스 읽기 전용 준비 — t_f9d59ace

담당 launchmini / 보드 escape-zombie-school
재개 세션: 20261018_204451_2a129c
관측 기준: 2026-10-18T11:54:25.283511Z
상태: PREPARED_WAITING_SOURCE_AND_SCOPE_RECONCILIATION
준비 완료. 배포 판정 NO-GO. 제품 실패나 구현 완료 판정이 아니다.

## 카드와 권한

카드 제목: Vending serialized safe release and live preservation
실제 show 결과 blocked / launchmini / do-not-dispatch. 원문 brief는 세션에 그대로 표시했다. 사용자 직접 요청의 준비 단계만 실행했으며 카드 상태를 바꾸거나 worker를 dispatch하지 않았다.
구현 t_b7475ffc, 독립 QA t_f6491f51, UI oracle t_7df165e3.
기존 홈페이지 로컬 후보와 fence는 접근/변경하지 않았다. 홈페이지 QA 문서는 중앙 checker 필독으로만 읽었고, 그 GO를 자판기 GO로 사용하지 않았다.

## 필수 게이트

첫 명령과 최종 재실행 모두 현재 F-root checker exit0.
TaskSummary: vending release card t_f9d59ace read only preparation production approval independent QA live ranking preservation
matched_domains: qa, corporate
match_evidence: qa→qa, corporate→vat
resolved_domains: common, qa, corporate, aab
corporate는 preservation 안의 vat 문자열 매칭일 뿐 법인 업무 범위가 아니다.
일반 AAB 실기기 Google 로그인 preflight 포함 및 필독 전체 읽기 완료. gstack global/profile 모두 OK.
최초 receipt: a4b7e86e8e49374d4fde1715de2262c3e94c2c6111efa0e4d02e302abd0dd881
최종 receipt: 406df613cc9c53ea94aa831d967bcbc5498d88bdfd99ea5715ed934acdc18b69
최신 QA 선택이 PREPARED.md로 바뀌어 checker 재실행 후 새 문서를 전체 읽었다. 기존 필독 해시는 동일하다.
CEO/current_product_priorities.md 및 현재 release/QA/보존 기록도 읽었다.

## 가장 중요한 발견: 카드 기준이 이미 이동했다

현재 Hosting GET:
- LIVE 65d2acb686b75f1b
- releaseTime 2026-10-18T11:48:02.270Z
- 627파일(provider 파일 포함)
- root HTTP200, text/html; charset=utf-8
- root raw SHA256 09f6d78c44a8b155b8ad69ed2e43a465c53e581816797b3b224c59090af6b111
- 활성 entry /assets/index-BNuo4AR0.js
- 경로/Hosting gzip hash 정렬 manifest SHA256 2ee479a6585d795b880f6edc86d705e17ca48f8a1148635c1153f3d886523470
  계산 규약은 JSON 산출물 currentBaseline에 명시했다. 과거 raw manifest hash와 직접 비교하지 않는다.

현재 git ls-remote origin refs/heads/zombie_only:
47f4a4e1d1c2a8fdf3a857e2c5aabce830cb25b3
정상 remote: https://github.com/JungGit-zard/school_survivor.git

구 LIVE0a6810bb54bf1b61/572파일 대비 현재627파일:
- 삭제 0
- 기존 변경 /index.html 1개
- 추가55개: JS9개와 공유 HTML/PNG46개
- cleanUrls, cache headers, /index.html rewrite는 관측된 기존 구성 그대로다.

GitHub compare상86e81c7d→47f4a4e1 사이4커밋:
- e21fd94f: Add homepage board preview and private contact inquiries
- f84df57a: merge
- 13399c91: Fix ranking retries across accounts and periods
- 47f4a4e1: merge

따라서 카드의 “홈페이지 f84df57a는 local-only” 가정은 더는 원격 상태와 일치하지 않는다. 이를 승인됐다고 임의 판정하거나 홈페이지 로컬 후보를 만지지 않았다. 현재 LIVE에도 새 홈페이지 관련 graph가 보인다. 이미 LIVE인 기능 제거와 아직 LIVE가 아닌 원격 랭킹 변화의 묵시적 승격 모두 위험하므로 정확한 최신 scope를 Advisor가 다시 귀속해야 한다.

## 기존 랭킹 보존 배포의 실제 성격

이전 clone:
C:/Users/admin/AppData/Local/Temp/ranking-redeploy-approved-20261018-110630
HEAD86e81c7d9728413b73a32f27aad4276bc4afef16
로컬 dist570파일을 이전 raw manifest와 실제 재해시: 불일치0.
Hosting572와의 차이2개는 /__/firebase/init.js 및 init.json provider 파일이다.

redeploy-owner-isolate.py 및 prepare.py를 읽어 확인한 절차:
- source clone에 이전 stage-progress의 승인 dist/hosting을 복사했다.
- 임시 predeploy는 nonce → legal → cards → pinned cmd였다.
- 이 임시 설정은 일반 game build 재실행 결과를 그대로 올리는 경로가 아니었다.
- frozen checker는 HEAD86e81c7d 및 정확570파일/기존 source hash를 고정한다.

따라서 기존 dist는 HEAD 이름만 보고 재현 가능한 새 빌드라고 간주할 수 없다. 옛 승인과 옛 pin을 vending 승인으로 재사용할 수 없다. deploy-owner-current-result.json의 과거 d6/BLOCKED 기록과 이후 실제 재배포 result, 이번 현재 GET도 분리했다.

## 왜 재빌드 차이를 단순히 자산 회귀라고 단정하지 않는가

현재 entry와 새 JS9개의 HTTP 본문, 이전 파일을 결합한 보수적 인용 JS 경로 closure는62개다. 계산형 경로/실행/전체 export ABI 검증은 아니다.
현재 사용 graph의 예:
- useGameStore-Fazgztmh.js
- GameCanvas-CRnCg6Qu.js
- HUD-LWr1CjG2.js
- PlayerMesh-BibVbziE.js
- TitleScene3D-D1_6GjGu.js
- firebaseRanking-Ck-ltzwZ.js

같은 dist에 비활성인 다른 세대 useGameStore-GmeRHCr0.js, PlayerMesh-DrBP9LNa.js 등도 남아 있다. 보존된 파일의 존재는 새 entry가 그 파일을 사용한다는 증거가 아니다.
TitleScene3D 두 버전은 JS 파일명 hash를 정규화하면 완전히 같다. 일부 hash 변화는 dependency hash 전파다. 반면 PlayerMesh/GameCanvas는 store/progress의 minified export alias도 다르고 store 두 버전은 본문 길이도 다르다. 새 store만 옛 chunk에 끼우거나 import 이름만 치환하면 모듈 인터페이스 불일치 또는 Zustand store 이중 생성 위험이 있다.
전체 source/toolchain 차이의 의미적 동등성은 이번 준비에서 증명하지 않았다. 실제 화면 회귀가 있다고 단정하지도 않는다.

## 정확한 보존 경로 — 실행 허가나 무회귀 보증 아님

선택: 현재 LIVE 기준 재조정 → 기준 source/활성 artifact graph 대응 → vending 최소 source build → additive 최종 package → 그 package 독립 QA.

1. 현재627파일과 설정을 동결 baseline으로 삼는다. 구572파일을 기준으로 되돌리지 않는다. 배포 직전 다시 LIVE/remote를 읽어 이동하면 재귀속한다.
2. 홈페이지 후보/fence와 분리된 구현자 전용 후보에서 최신 원격을 보존한다. 현재 원격에 들어간 홈페이지와 새 랭킹 코드 중 LIVE와 다른 부분은 Advisor의 명시 scope 결정이 필요하다. 옛86e81c7d 소스를 대신 쓰지 않는다.
3. vending 없는 기준 source의 lock/env/compiler와 활성 배포 graph를 대응한다. title/model/audio/landing/ranking/progress 차이를 실제 의미 변경과 파일명 전파로 구분한다. 보호 경로의 차이가 설명되지 않으면 안전 중단한다.
4. 그 기준에 vending 및 Floor/HUD/store 최소 hunk만 적용하고 정상 branch/env/Studio/build/postbuild gate를 그대로 통과한다. 동일 store/refs 한 인스턴스를 공유하는 완전한 module graph를 만든다.
5. 최종 배포 디렉터리는 현재 baseline의 모든 nonprovider 경로/bytes/config를 그대로 남기고 검증된 새 vending graph를 추가한다. 승인된 index/entry만 전환한다. 옛 파일을 남겨둔 채 새 graph가 다른 title/model/audio를 사용하게 되는 거짓 보존은 허용하지 않는다.
6. 보호 모듈을 재컴파일한 graph를 사용해야 하면 동등성 및 실제 화면/행동 회귀를 독립 QA가 확인한다. 증명 불가면 No-Go. minified chunk 문자열 치환/새옛 store 혼합은 현재 승인된 대안이 아니다.
7. balanceqa GO는 반드시 최종 source와 최종 assembled dist에 함께 귀속한다. 보존 작업 전 build dist나 홈페이지 QA GO는 대체 증거가 아니다.
8. binding production-go 후에만 후속 release 검토가 가능하다. 지금 실행 가능한 검증 완료 무회귀 후보는 없다. 경로는 식별했지만 provenance와 QA가 빠진 상태에서 “보존 가능/완료”로 보고하지 않는다.

기존 pinned checker는86e81/570파일을 강제하므로 새 vending/627기준에 쓸 수 없다. 수정·핀 해제·우회하지 않았다. 별도로 승인된 새 scope validation 경로 없이는 중단한다.

## 현재 후보와 정확한 차단점

- canonical candidate-ready.json 없음. releases/vending-owner-20261018-ready는 힌트일 뿐 권위 없음.
- 힌트 clone HEAD86e81c7d. 조회 당시 tracked changes는 Floor.jsx, HUD.jsx, useGameStore.js. dist 없음. 내용을 복사하거나 수정/빌드하지 않음.
- source stageConfig와 이전 활성 store에서 정적으로 관측한 stage는1–4다. Stage1–10 인수 계약과의 차이를 임의로 축소하거나 expansion을 무단 반입하지 않는다.
- balanceqa PREPARED.md는 준비 인계뿐이다. final-qa.json/md 및 최종 source/dist GO 없음.
- canonical vending production-go.json 없음.
- remote47f4 및 LIVE65d2로 이동하여 source/live/scope 재조정 필요.
- 기존 frozen gate 및 보호 graph/source 대응 미해결.

필수 production-go binding:
독립 QA GO 파일/hash, source manifest, candidate-ready hash와 절대경로, 최종 assembled dist manifest, 최신 remote SHA, 기대 LIVE version, Hosting-only 범위, 보호/허용 변경 경로, sole publisher 확인, rollback 정책. 존재만 하는 JSON이나 과거 GO는 권한이 아니다.

## 후속 배포 체크리스트 — 전부 이번에는 미실행

- [ ] 현재 필수 문서/receipt와 branch guard 통과
- [ ] 최신 원격 포함 및 LIVE concurrency 일치
- [ ] 현재 LIVE의 고유 rollback backup과 exact version readback
- [ ] 정상 build 및 nonce/legal/cards/frozen/asset gate 모두 보존
- [ ] 승인된 preview-only로 최종 package 검증
- [ ] final QA와 production-go가 그 source/dist/preview에 정확히 binding
- [ ] 명시 승격 후 root/game/landing, JS MIME/rawSHA/import closure 및 LIVE version 검증
- [ ] 즉시 결과 JSON과 미검증 제한 보고

Play Console/AAB/track/rules/auth/Functions/DB는 이 Hosting 준비의 실행 범위가 아니다. Play 업로드나 프로덕션 제출 권한 없음. AAB를 별도 요청할 때는 PRE/POST 및 실기기 Google Play 로그인 게이트를 새로 적용해야 한다.

## 실행 경계와 도구 제한

이번 세션의 쓰기는 release-preparation.json과 이 md뿐이다.
source/dist/Git stage·commit·push·fetch·reset·clean·stash·rebase 없음. build/test/browser/server 없음. 배포·preview·clone·rollback writes 없음. 홈페이지 후보/fence, 카드 상태, profile/config/guard/skill 변경 없음. Auth/rules/Functions/DB/Play writes 없음.
Hosting GET에는 기존 저장 access token만 메모리에서 사용했으며 표시·refresh·config write하지 않았다. Git ls-remote/GitHub compare/raw 및 공개 root/JS GET은 읽기 전용이다.
execute_code는 동의 부족으로 차단되어 재시도하지 않았다. 상대 file 경로는 실패하여 절대 F 경로로 해결했다. 광범위 검색2건은60초 timeout 후 bounded listing으로 축소했다. 비싼 문자열 diff는20초 timeout 뒤 선형 정규화 비교로 제한했다. 구현을 기다리거나 polling하지 않았다.

## 재개

세션 ID: 20261018_204451_2a129c
현재 F-root checker와 바뀐 필독을 먼저 읽고 이 JSON을 기준으로 이어간다. 이 준비 문서는 publication 권한이 아니다. 구현/QA 대기 루프 없이 여기서 종료한다.
