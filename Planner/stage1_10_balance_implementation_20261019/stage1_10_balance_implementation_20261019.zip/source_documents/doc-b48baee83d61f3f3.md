# 2026-05-16 게임 기술스택 · 코드 중간점검

> 한 세션 동안 수행한 주요 인프라/코드 정비 및 기술스택 리뷰 결과 요약.
> 이 문서는 향후 회고/의사결정 시 참조용 단일 페이지.

---

## 1. 세션 메모리 규정 — LOCKED 2026-05-16

### 변경 전
- 세션 메모리 규정이 4개 문서(`CLAUDE.md`, `AGENTS.md`, `project_develop_policy.md`, `SESSION_CONTINUITY.md`)에 중복 산재
- 요약 저장소가 `Session_Logs/` 디렉토리에 파일 단위로 흩어짐

### 변경 후 — 단일 정본 + 영구 누적 1개 문서
- **정본**: `SESSION_CONTINUITY.md` (LOCKED 표식, 임의 변경 금지)
- **데이터 저장소**: `SESSION_MEMORY.md` (프로젝트 루트, append-only)
- 다른 3개 문서는 1줄 포인터만 보유
- 레거시 `Session_Logs/` 보존 (신규 쓰기 없음)

### 룰
| 시점 | 동작 |
|---|---|
| 세션 시작 | `SESSION_MEMORY.md`의 **가장 최근 엔트리 1개만** 자동 리마인드 |
| 그 이상 과거 회수 | 사용자 명시 요구시에만 직접 읽기 |
| 3시간마다 | 신규 엔트리 append |
| 9시간 = 3 엔트리 | 자동 `/clear` 권고 → 다음 세션 시작 |

→ **1 세션 = 9시간 = 3 요약 + 1 초기화**

---

## 2. 기술스택 문서 전면 갱신

### `Developer/tech_stack.md` 갱신
구버전 outdated 부분 수정 + 신규 시스템 반영. 10개 섹션 구성:

1. 런타임 의존성 버전 (`react 18.3.1`, `three 0.164.1`, `@react-three/fiber 8.17.10`, `drei 9.109.5`, `rapier 1.4.0`, `zustand 4.5.4`, `vite 8.0.10`)
2. 레이어 구조 (React DOM → Zustand → R3F → Rapier → Three.js → localStorage)
3. 각 기술의 역할 (코드 수준 매핑)
4. 게임 시스템 모듈 8개 (외곽선 / VFX / itemEffects / upgrades / pickup / 이중 드랍 / 적 / 음식)
5. 데이터 흐름 다이어그램
6. 영속화 (localStorage 1키만, BE 없음)
7. 개발 환경 / 도구 (Node 24.15 / Bun 1.3.14 / gstack / PowerShell `cs` 별칭)
8. 빌드 / 실행 / 검증
9. 의도적 미사용 (BE / Redux / Tailwind / drei 무거운 헬퍼 / 2D / postprocessing)
10. 참고 문서 링크

### 주요 정정
- XpOrb → XpTextbook
- 4 무기 → 9 무기
- VFX 인프라 / itemEffects 레지스트리 신규 섹션
- Stencil Layer + `inflateScale` 외곽선 시스템 추가
- 이중 드랍(XP+골드) + localStorage 명시
- DataTexture → CanvasTexture 정정

---

## 3. plan-eng-review 실행 (gstack 스킬, 매뉴얼 모드)

엔지니어링 매니저 모드의 인터랙티브 리뷰. 5개 발견 사항 식별 + 우선순위화:

| # | 발견 사항 | 진행 |
|---|---|---|
| 1 | **Vitest 도입 + 첫 유닛 테스트** | ✅ 완료 |
| 2 | **Weapons.jsx 1808줄 분할** | ✅ 완료 |
| 3 | **useFrame/VFXLayer 성능 점검** | ✅ 일부 완료 |
| 4 | Persistence/BE 결정 트리 | ⬜ 미진행 (추후) |
| 5 | TypeScript 부분 도입 전략 | ⬜ 미진행 (추후) |

### 결론
> 스택은 견고하고 큰 결함 없음. **잘못 고른 것**보다는 **지금 없는 것** 쪽이 더 큰 리스크.

---

## 4. Vitest 도입 — 회귀 안전망 가동

### 적용
- `vitest 4.1.6` + `jsdom 29.1.1` devDeps 추가
- `vite.config.js`에 `test` 블록 (`environment: 'node'`, `globals: false`)
- `package.json` 스크립트: `test`, `test:watch`
- `src/lib/upgrades.test.js` — 19 케이스 작성

### 테스트 커버리지 (`upgrades.js`)
| 그룹 | 케이스 수 |
|---|---|
| `applyUpgradeToWeapon` | 6 (unlock/damage/damage-Lv5 cap/stat/stat cap/undefined stat) |
| `isUpgradeAvailable` | 10 (player/minLevel/active/4종 상한/Lv5 게이트/stat cap 등) |
| `UPGRADE_EFFECTS` 테이블 무결성 | 3 |

### 결과
- `npm run test` → **19/19 passed (197ms)**
- 이전에 잡았던 3 버그(4종 상한 누락 / Lv5 stat 카드 노출 / stat이 level을 안 올림) 재발 시 즉시 빨강

---

## 5. Weapons.jsx 1808줄 분할 — 유지보수성 ↑

### 변경 전
- `Weapons.jsx` 단일 파일 1808줄, 9 무기 + 공유 헬퍼 혼재
- `easeOutCubic` / `smoothStep`이 `vfxMath.js`와 중복

### 변경 후 — 무기당 1파일 + barrel + 공유 헬퍼 lib

```
src/components/Weapons/
├── index.js              # barrel (9 re-exports)
├── Pencil.jsx            ├── SchoolBag.jsx    ├── Tumbler.jsx
├── Bell.jsx              ├── Flask.jsx        ├── Missile.jsx
├── Starlink.jsx          ├── StunGun.jsx      └── Onigiri.jsx

src/lib/
├── weaponTargeting.js    # NEW — findClosestEnemy / findBestSplashTarget
└── vfxMath.js            # +lerpAngle, 중복 제거
```

### 마이그레이션 절차
- Phase 0: 공유 헬퍼 추출 (`weaponTargeting.js` 신규, `vfxMath.js`에 `lerpAngle` 추가)
- Phase 1–9: 9개 무기를 작은 것부터 순차 추출 (Tumbler → Pencil → Bell → Flask → SchoolBag → Missile → Starlink → StunGun → Onigiri)
- Phase 10: barrel 생성, `Game.jsx` import 경로 갱신, 원본 삭제

### 효과
- 가장 큰 파일: `Weapons.jsx 1808줄` → `Missile.jsx ~340줄`
- 새 무기 추가 = 새 파일 + barrel 1줄 (기존 1800줄 파일 편집 X)
- 빌드 검증: `npm run build` ✓ 620 modules
- 테스트: `npm run test` ✓ 19/19 (Weapons 외 영역 영향 없음 확인)

---

## 6. VFXLayer 성능 최적화 — setState 디바운스

### 발견
[`VFXLayer.jsx`](../../Developer/r3f_prototype/src/components/VFXLayer.jsx) emit 콜백과 onDone 콜백이 매 호출마다 직접 `setEvents`. 같은 마이크로태스크 내 N개 emit + M개 done이 발생하면 N+M회 React reconciliation.

### 적용
`queueMicrotask` 기반 디바운스 — 같은 마이크로태스크 내 다중 호출을 setState **1회**로 합침.

```js
const flushPending = useCallback(() => {
  if (pendingRef.current) return
  pendingRef.current = true
  queueMicrotask(() => {
    pendingRef.current = false
    setEvents([...eventsRef.current])
  })
}, [])
```

emit 콜백 / onDone 둘 다 `setEvents` 직접 호출 제거 → `flushPending()`만 호출.

### 검증
- `npm run build` ✓ 594ms
- `npm run test` ✓ 19/19

### 실측은 TODO
실제 프레임 드랍 측정은 DevTools Performance 캡처 필요. 이 변경은 이론적 이득(reconciliation 횟수 감소), 위험 거의 없는 안전한 개선.

---

## 7. 누적 변경 통계 (오늘 세션)

| 종류 | 수량 |
|---|---|
| 신규 파일 | 14 (Weapons 9 + barrel + `weaponTargeting.js` + `upgrades.test.js` + `SESSION_MEMORY.md` + 본 문서) |
| 수정 파일 | 5+ (`vite.config.js`, `package.json`, `Game.jsx`, `vfxMath.js`, `VFXLayer.jsx`, `tech_stack.md`, `SESSION_CONTINUITY.md`, `CLAUDE.md`, `AGENTS.md`, `project_develop_policy.md`) |
| 삭제 파일 | 1 (`Weapons.jsx` 1808줄) |
| devDeps 추가 | 2 (`vitest`, `jsdom`) |
| 테스트 수 | 0 → 19 (모두 그린) |
| 빌드 / 테스트 검증 | 매 단계 ✓ |

---

## 8. 다음 단계 — 우선순위

| 우선순위 | 항목 | 트리거 |
|---|---|---|
| ⏰ 측정 의존 | DevTools Performance 캡처 (4~5분차 적 피크) | dev 서버 재기동 후 시각 검증 시 동시 진행 |
| 🎯 다음 큰 작업 | 백엔드 결정 트리 (Supabase / CF Workers + D1 / Firebase 비교) | 리더보드/계정/메타프로그레션 기획 확정 시점 |
| 🛡️ 점진 도입 | TypeScript 부분 도입 (`lib/` 디렉토리만 `.ts`) | 코드 안정화 + 새 무기/적 추가 빈도 줄어들 때 |
| 🎨 마무리 작업 | VFX wiring 미연결 (`onHit` 9 무기, `onDeath` 5 적, `onSpawn` 3 드랍, `onLevelUp` 글로벌) | `effect_sloution.md` §9 placeholder |
| 📋 보류 | dual_drop_system §3-3 보스 보너스 / §7 XP 보정 일부 미적용 | 보스 처치 보상 밸런싱 시점 |
| 📋 보류 | 타이틀/랜딩 화면 작업 | 게임플레이 완성 후 |

---

## 9. 기술 스택 안정성 평가 (현재 시점)

| 영역 | 평가 | 코멘트 |
|---|---|---|
| 의존성 선택 | 🟢 견고 | pmndrs 생태계 정석, 모두 메이저 안정 버전 |
| 아키텍처 패턴 | 🟢 적절 | subscribeWithSelector / 모듈 큐 / Stencil Layer 등 정확한 선택 |
| 코드 구조 | 🟡 정비 중 → 🟢 | Weapons.jsx 분할 완료, 다음 무기 추가 친화적 |
| 테스트 커버리지 | 🟡 → 🟢 일부 | upgrades.js 회귀 안전망. pickup/itemEffects/toon 추가 가능 |
| 타입 안전성 | 🟡 (의도적) | JS-only, 솔로 프로토타입 OK. 코드 커지면 검토 |
| 영속화 | 🟢 (현 단계) | localStorage 1키. BE는 리더보드 도입 시점에 결정 |
| 성능 | 🟢 (추측) | 안티패턴 회피 확인, 실측은 DevTools 필요 |
| 도구 체인 | 🟢 | Vite HMR 빠름, Bun + gstack 통합 |

---

## 참조

- 본 세션 누적 작업의 전체 기록: [`Session_Logs/session_summary_2026-05-16_0043.md`](../../Session_Logs/session_summary_2026-05-16_0043.md)
- 세션 메모리 정본: [`SESSION_CONTINUITY.md`](../../SESSION_CONTINUITY.md)
- 영구 누적 로그: [`SESSION_MEMORY.md`](../../SESSION_MEMORY.md)
- 현재 기술스택 상세: [`Developer/tech_stack.md`](../../Developer/tech_stack.md)
- 외곽선/VFX 구조: [`Planner/Tech_plan/effect_sloution.md`](../Tech_plan/effect_sloution.md)

---

## 10. 문서 깨짐 점검 및 실제 수정

### 확인 결과
- `Planner/` 문서의 한글 깨짐처럼 보이던 현상은 대부분 PowerShell 기본 출력 인코딩 문제였다.
- `Get-Content -Encoding UTF8` 기준으로 주요 문서는 정상 한국어로 확인됐다.
- 실제 깨진 문자열은 문서 본문이 아니라 코드 주석 일부에서 발견됐다.

### 수정한 깨진 주석
- `Developer/r3f_prototype/src/components/Enemies.jsx`
- `Developer/r3f_prototype/src/components/HUD.jsx`
- `Developer/r3f_prototype/src/store/useGameStore.js`

### 재검색
- `rg -F "?"`
- `rg -F "媛"`
- `rg -F "臾"`
- `rg -F "쒖"`
- `rg -F "�"`

위 패턴 기준으로 추가 깨진 문자열은 확인되지 않았다.

---

## 11. 현재 게임 검증용 서브에이전트 / gstack 스킬 조사

### 추천 서브에이전트 순서
| 순서 | 역할 | 목적 |
|---|---|---|
| 1 | `code-mapper` | 현재 구현 기능과 검증 표면 지도화 |
| 2 | `reviewer` | 변경 diff 기반 회귀 위험 검토 |
| 3 | `qa-reviewer` | 전체 QA 계획, 테스트 기준, 리스크 기록 |
| 4 | `game-developer` | 게임 루프, 밸런스, 스폰/드롭/무기 흐름 검증 |
| 5 | `graphic_designer` | 3D 카툰 렌더링, HUD, VFX, 모바일 가독성 검증 |
| 6 | gstack browser | 실제 브라우저 실행, 콘솔, 반응형, 스크린샷 검증 |

### 보조 후보
- `ui-designer`: HUD, 터치 조작, 모바일 레이아웃 검토
- `frontend-developer`: React/R3F UI 구현 안정성 검토
- `security-auditor`: 점수/골드/저장값 조작 방지 검토
- `develop-director`: 수정 우선순위와 작업 분할 판단

### 추천 gstack 스킬
| 스킬 | 용도 |
|---|---|
| `/qa` | 기능 전체 QA와 증거 수집 |
| `/qa-only` | 수정 없이 검증만 수행 |
| `/browse` | 실제 페이지 열기, 스크린샷, 콘솔, 네트워크 확인 |
| `/review` | diff 기반 코드 리뷰 |
| `/investigate` | 재현 가능한 버그 원인 추적 |
| `/design-review` | 시각 품질과 UI/HUD 검토 |
| `/plan-eng-review` | 기술 설계와 구조 리뷰 |

---

## 12. 추천 순서 기반 실제 순차 검증 결과

### 12-1. code-mapper 결과
확인된 주요 구현:
- `App.jsx`: 모바일 세로형 R3F 화면, `gameKey` 기반 Physics 리셋
- `Game.jsx`: 5분 생존 루프, 클리어 전환
- `useGameStore.js`: 상태, XP, HP, 골드, 리셋, localStorage 누적 골드
- `Player.jsx`: 키보드 이동, 피격, 520ms 무적
- `Enemies.jsx`: Stage 1 웨이브, 버스트, 4분 B01 보스
- `Weapons/`: 현재 코드 기준 7종 무기 분리 구조
- `HUD.jsx`: HP/XP/레벨/골드/레벨업/게임오버/클리어 UI

위험 표면:
- `gainXp`가 한 번에 한 레벨업만 처리
- B01 보너스 교과서 XP 0 가능성
- `refs.js` 전역 상태 리셋 누락 가능성
- 후반 카드 후보 부족 또는 효과 없는 카드 가능성
- Stage 1 E04 제외는 되어 있으나 E04 투사체 코드 잔존

### 12-2. reviewer 결과
심각도 높은 항목:
1. `gainXp(40)` 같은 큰 XP 입력에서 Lv.2, `xp:34 / xpToNext:10`처럼 초과 XP가 즉시 다음 레벨업으로 이어지지 않음.
2. B01의 `xp`가 0이라 B01 보너스 교과서 3개가 실제 성장 보상을 주지 않을 수 있음.

중간 위험:
- 후반 카드가 3개 미만이거나 `moveSpeed` 상한 도달 뒤 no-op 카드가 남을 수 있음.
- `resetGame`이 `playerPos`, `playerFacing`, `bagSwingState`, `enemyBodies`, `joystickDir`를 명시 초기화하지 않음.
- 골드 코인은 최악 분포에서 5분 8개만 나올 수 있음.

### 12-3. qa-reviewer 결과
작성 파일:
- [`Quaility_Assurance/qa_stage3_full_plan_report_2026-05-16.md`](../../Quaility_Assurance/qa_stage3_full_plan_report_2026-05-16.md)

검증:
- `npm test` 통과: 1개 테스트 파일, 19개 테스트 통과
- `npm run build` 통과
- 번들 크기 500 kB 초과 경고 있음

QA 결론:
- 자동 테스트는 업그레이드 유틸 중심이라 전체 5분 플레이 안정성을 보장하지 않는다.
- 다음 검증 우선순위는 XP/레벨업, B01 보상, 후반 카드 유효성, 재시작 초기화다.

### 12-4. game-developer 결과
확인된 구현:
- 5분 루프는 `playing` 중 타이머 누적 후 300초에 `cleared` 전환.
- 상태 흐름은 `playing`, `paused`, `levelup`, `gameover`, `cleared`.
- 별도 `start` 상태는 없음.
- E04는 Stage 1 웨이브/버스트에서 제외.
- 240초에 B01 보스 1회 스폰.
- `Weapons.jsx` 삭제 후 `components/Weapons/index.js` barrel import 구조는 빌드에서 정상.

반드시 고칠 항목:
- XP 연속 레벨업 처리
- B01 XP 0 보상
- 골드 8개 최악 분포
- 시작 대기/카운트다운 상태가 필요하다면 `start` 상태 추가 검토

### 12-5. graphic_designer 결과
작성 파일:
- [`Graphic_designer/UI_HUD_Title/stage5_graphic_hud_qa_2026-05-16.md`](../../Graphic_designer/UI_HUD_Title/stage5_graphic_hud_qa_2026-05-16.md)

정책 준수:
- 플레이어/몬스터는 `MeshToonMaterial` 기반 toon 재질을 사용.
- 외곽선 표현이 있음.
- 실제 3D geometry 기반이며 2D 스프라이트 대체는 확인되지 않음.
- 플레이어 모델은 `RigidBody` 하위에 붙어 있어 게임 좌표와 분리될 위험이 낮음.

시각/HUD 리스크:
- 레벨업/게임오버/클리어 모달 `minWidth: 440`은 390px 모바일 프레임에서 잘릴 수 있음.
- `VirtualJoystick.jsx`는 있지만 `App.jsx`에 연결되지 않음.
- 모바일 일시정지 버튼 없음.
- 안전 영역 대응 없음.
- 하단 HP/XP와 향후 조이스틱 영역이 겹칠 수 있음.

---

## 13. gstack 브라우저 실기동 검증

작성 파일:
- [`Quaility_Assurance/stage6_gstack_browser_validation_2026-05-16.md`](../../Quaility_Assurance/stage6_gstack_browser_validation_2026-05-16.md)

### 준비
- gstack browse 실행 파일 확인:
  - `C:\Users\admin\.claude\skills\gstack\browse\dist\browse.exe`
- 최초 실행 시 Playwright headless Chromium revision `1208`이 없어 실패.
- `npx playwright@1.58.0 install chromium`으로 gstack이 요구하는 revision 설치.

### 실행
- 개발 서버:
  - `npm run dev -- --host 127.0.0.1 --port 5173`
- URL:
  - `http://127.0.0.1:5173/`

### 확인 결과
- 로컬 서버 `200` 응답.
- 초기 렌더링 정상.
- 첫 화면 텍스트:
  - `00:00`, `Lv.1`, `HP100/100`, `연필`, `자OK`, `0`
- 콘솔 치명 JS 오류 없음.
- WebGL `ReadPixels` GPU stall 성능 경고만 확인.
- 네트워크 요청은 개발 서버 기준 `200` 또는 캐시성 `304`.

### 모바일 검증
- `390x844` viewport에서 게임 화면은 표시됨.
- `snapshot -i` 결과 인터랙티브 요소 0개.
- 키보드 `p`로 `PAUSED` 모달은 뜨지만, 터치로 조작할 pause/resume 버튼은 없음.
- 모바일에서 조이스틱/터치 이동 UI가 실제 연결되지 않은 상태가 확인됨.

### 반응형 캡처 판정
| 화면 | 결과 |
|---|---|
| `375x812` | 게임 화면은 꽉 차지만 하단 HUD가 안전 영역에 가까움 |
| `390x844` | 모바일 표시 정상, 터치 인터랙션 부재 |
| `768x1024` | 중앙 390px 게임 프레임 좌우 검은 여백 |
| `1280x720` | 중앙 390px 게임 프레임 좌우 넓은 검은 여백 |

---

## 14. 현재 최우선 수정 리스트

| 우선순위 | 항목 | 이유 |
|---|---|---|
| P0 | `gainXp` 연속 레벨업 처리 | 성장 루프 핵심 실패 가능성 |
| P0 | B01 보너스 교과서 XP 0 수정 | 보스 보상 체감 실패 |
| P0 | 모바일 조이스틱 연결 | 모바일 게임인데 터치 이동 불가 |
| P0 | 모바일 pause/resume 버튼 추가 | 터치 환경에서 일시정지 접근 불가 |
| P1 | 레벨업/결과 모달 모바일 폭 수정 | 390px 화면 잘림 위험 |
| P1 | `refs.js` 전역 상태 리셋 helper 추가 | 재시작 반복 안정성 |
| P1 | 골드 코인 최소 개수 보정 | 5분 보상 체감 하한 보장 |
| P2 | E04 투사체 코드 Stage 1 회귀 방지 테스트 | 향후 스폰 테이블 실수 방지 |
| P2 | WebGL/번들 크기 성능 추적 | 모바일 로딩/프레임 안정성 |

---

## 15. 최종 상태

### 검증 명령
- `npm test` → 19/19 passed
- `npm run build` → success
- gstack browse 실기동 → 초기 렌더링, 콘솔, 네트워크, 반응형 캡처 확인

### 오늘 결론
현재 기술스택 자체는 유지 가능하고 빌드/테스트도 통과한다. 다만 실제 플레이 완성도 기준에서는 성장 루프와 모바일 조작성이 가장 큰 병목이다.

다음 작업은 새 기능 추가보다 먼저 다음 4개를 고치는 것이 좋다.

1. XP 연속 레벨업 처리
2. B01 보상 XP 0 문제
3. 모바일 조이스틱 연결
4. 모바일 pause/resume 버튼 및 모달 폭 수정
