# Android AAB v20 빌드 기록 (2026-07-17)

## 결과

- 파일: `Developer/r3f_prototype/android/app/build/outputs/bundle/release/app-release.aab` (사본 `app-release-v20.aab`, integration 워크트리에도 복사)
- Android 버전: `versionCode 20`, `versionName 1.0.11`
- 애플리케이션 ID: `com.jungyoon.zombieschool`
- 빌드 소스 커밋: `549a4ad` (origin/feature/stage2-corridor-floor-graphics)
- 빌드 워크트리: `zombie_claude/` (claude-dev — 2026-07-16 개편된 에이전트별 워크트리 체계의 첫 릴리스 빌드)
- 파일 크기: 15,049,596 bytes
- SHA-256: `2b0ed3eebbc30953caa0bd3792f3580c169a03d22837a574d9f55c335bb2bee3`

## v19 대비 포함된 변경

- 도지 황금고블린 이벤트(60s 스폰→도주→상자→코인), 스테이지1 중간보강+보스호위 스폰
- HUD 개편(레벨업 카드 중앙 팝인·심플 HP바·최상단 XP·슬림 상단바), 타이틀 BGM+글자 슬램+도지 2마리
- stage1 스폰 1.3x·stage3 GymProps(codex), 세션·워크플로우 문서
- 참고: 웹 자산 최적화(WebP·BGM 재인코딩)는 v19에 이미 포함 — 크기 변동 미미(+32B)한 이유

## 검증

- 빌드 전 로컬 HEAD = origin HEAD(549a4ad) 일치 확인 (fetch + reset --hard)
- vitest 전체 스위트: 통과 (exit 0)
- `npx vite build` + `npx cap sync android`: 통과
- `gradlew clean :app:bundleRelease` (JAVA_HOME=Android Studio jbr): BUILD SUCCESSFUL, 161 tasks
- `unzip -t`: 압축 오류 없음
- `jarsigner -verify`: `jar verified.`
- 병합 Manifest: versionCode 20, versionName 1.0.11

## 빌드 중 확인한 문제

- zombie_claude 워크트리에 git 제외 파일 3종 부재 → integration에서 복사로 해결: `keystore.properties`, `app/upload-keystore.jks`, `local.properties`(sdk.dir). 이 워크트리에서 재빌드 시 재복사 불필요(이제 존재).
- 셸에 JAVA_HOME 미설정 → `C:\Program Files\Android\Android Studio\jbr` 지정 필요.

## 릴리스 제한

- 연결된 Android 기기/AVD 없음 — WebView 실기 실행 증거 미확보. Play Console 업로드 전 실기 확인 필요 (v19와 동일 제한).
