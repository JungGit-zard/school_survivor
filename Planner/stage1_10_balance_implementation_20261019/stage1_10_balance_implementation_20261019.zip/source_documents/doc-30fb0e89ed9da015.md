# Phase5 backendmini — actual storage repair 결과

판정: **수정 구현 및 집중 회귀 PASS / 전체 릴리스는 HOLD**.
기존 t_883d4617 blocked Advisor mirror 재사용, backendmini 단독 runtime writer. 자동 dispatch 없음. 브라우저 소유 balanceqa(t_eebe49ae)에 카드 댓글로 조정 요청 완료.
후보: F:/From_SSD_D_20261005/JungSil/2.Minigame_project/releases/integrated-game-20261016-t_e2815ba8
기준 HEAD: 62dc162b4db451ea4edef9c8f320340faf822622, zombie_only. 시작 clean. 커밋하지 않음.
필독 체커 두 차례 EXIT0, common+backend. 최종 matched_domains=[backend], match_evidence=backend/firebase. receipt c222950c882b46603399801745607683d248a3050ec2f84fb864f914d4330f71 동일. GSTACK_OK.

## 실제 구현

1. firebaseAuth.js: 최초 `getAuth(app)`를 `initializeAuth(app, { persistence: inMemoryPersistence, popupRedirectResolver: browserPopupRedirectResolver })`로 교체. 기본 IndexedDB/localStorage 계층 초기화 자체가 시작되지 않는다. 기존 후속 setPersistence(memory)는 유지. 기존 popup, fallback redirect, Android web/TWA redirect, pending redirect 소비, Studio named app, native Google credential bridge, 로그아웃/계정 삭제·재인증 분기는 변경하지 않았다. 다른 설정으로 이미 초기화된 Auth에는 SDK가 already-initialized 오류를 내며 기본 getAuth로 조용히 우회하지 않는다.
2. scripts/firebase-database-memory-storage.mjs: 승인된 @firebase/database 1.1.3의 브라우저 엔트리 `dist/index.esm.js`에서 정확히 한 선언 `PersistentStorage=createStoragefor('localStorage')`만 SDK 원래 `new MemoryStorage()`로 변환한다. 버전 또는 해당 선언/클래스 구조 불일치는 빌드 변환 오류로 중단. 전역 Storage는 건드리지 않고 node_modules 파일도 수정하지 않았다.
3. vite.config.js: 일반 pre-transform과 Vite 8 `optimizeDeps.rolldownOptions.plugins`에 동일 변환을 연결. install로 사라지는 의존성 직접 패치가 아니라 저장소 추적 대상 소스이다. Firebase 업그레이드는 버전/구조 재검토 및 실측 테스트가 필요하다.

RTDB에서 바뀐 저장 대상은 SDK 내부 호스트 캐시/이전 websocket 실패/디버그 연결 힌트뿐이다. SDK의 실제 auth/network/DB/subscription 구현은 유지한다. Firebase-only Studio·progress·ranking 데이터 경로, 정본, 규칙 및 저장 함수는 변경하지 않았다. 메모리 힌트는 사용자 데이터 fallback/로컬 정본이 아니다. 세션 내 transport 힌트는 유지되지만 새로고침/새 탭에는 남지 않으며 다음 세션에서 연결 탐색이 다시 일어날 수 있다. RTDB sessionStorage 및 Auth redirect의 기존 sessionStorage 절차는 변경하지 않았으므로 '모든 브라우저 저장소 무사용'이라고 주장하지 않는다.

## 정확한 변경 파일

아래 7개는 모두 후보 루트 기준이다.
- Developer/r3f_prototype/src/lib/firebaseAuth.js
- Developer/r3f_prototype/src/lib/firebaseAuth.test.js
- Developer/r3f_prototype/src/lib/firebaseAuth.twaStress100000.test.js
- Developer/r3f_prototype/vite.config.js
- Developer/r3f_prototype/scripts/firebase-database-memory-storage.mjs (신규)
- Developer/r3f_prototype/scripts/firebase-database-memory-storage.test.js (신규)
- Developer/r3f_prototype/scripts/firebase-sdk-storage.test.js (신규)

기존 mock 테스트는 새 initializeAuth/resolver export를 추가하고 최초 memory-only 인자 및 getAuth 미호출 검증을 추가했다. 기존 assertion/반복 횟수를 삭제하거나 완화하지 않았다. 최초 집중 실행의 1개 실패는 새 assertion에서 기존 fixture의 initializeApp 반환값 undefined가 드러난 것으로, 실제 named studioApp fixture를 제공해 정확한 app identity를 검증하도록 수정했다.
최종 git diff --check EXIT0. 다른 작업자의 Graphic_designer/expansion_20261016/evidence/ 산출물은 보존했고 건드리지 않았다.

## 실측 검증

모든 Vitest 실행은 `npm test -- ...`로 branch, no-legacy-B02, dialogue-store, Studio-game-sync 정상 pretest 게이트를 통과했다. 게이트 우회 없음.

### RED → GREEN 실제 SDK
- scripts/firebase-sdk-storage.test.js는 Rolldown으로 실제 Firebase **browser** SDK를 메모리 번들링해 JSDOM에서 실행한다. Node의 storage-free 배포본 또는 Firebase mock을 쓰지 않는다. 프로덕션 게임 빌드/dist 생성은 아니다.
- localStorage getter 및 getItem/setItem/removeItem/clear/key를 기록하되 원래 DOM Storage 메서드를 그대로 실행한다. 접근을 삼키거나 예외로 숨기지 않는다.
- Firebase/Auth 저장 로직은 실제 SDK이며 네트워크 transport만 격리한다. 테스트 전용 가짜 project/key 사용, 원격 사용자/DB/Google에 연결하지 않는다.
- 최초 import, Auth 초기화/ready, 재생성, Auth 구독, 실제 getDatabase/ref/onValue('.info/connected'), websocket 시도, offline/unsubscribe/signOut/deleteApp 수명주기를 실행했다.
- 수정 전 RED: sentinel, __sak, authUser, host, previous_websocket_failure 접근으로 실제 실패. phase5-sdk-red.log.
- 수정 후 GREEN: Auth persistence NONE, 구독 null/false 전달, websocket 경로 실행 및 localStorage getter/연산 모두 0. phase5-sdk-green.log.
- 추가한 양성 대조군은 변환을 빼면 동일 계측이 RTDB sentinel/host/websocket_failure를 실제 검출함을 확인한다. optimizer에 등록된 동일 plugin 경로도 실제 SDK 실행에서 접근 0을 확인했다. 다만 전체 Vite dev 서버/최종 dist의 브라우저 검증을 대체하지 않는다.
- 변환 단위 테스트는 실제 SDK 파일에서 정확히 한 선언만 변경, 비대상 모듈 불변, 선언 누락/중복/클래스 변형 차단을 확인한다.

### 집중 회귀 PASS
명령:
`npm test -- scripts/firebase-sdk-storage.test.js scripts/firebase-database-memory-storage.test.js src/lib/firebaseAuth.test.js src/lib/firebaseAuth.twaStress100000.test.js src/lib/firebaseProgress.test.js src/store/useAuthStore.cloudProgress.test.js --maxWorkers=1 --no-fileParallelism`
결과: **6 files / 60 tests PASS**, phase5-focused-final.log. 기존 TWA 100,000회 격리 하니스 및 native/popup/redirect 분기, cloud-progress 회귀 포함. 이들 분기 mock의 성공은 실제 OAuth 성공 증거가 아니다.

### 전체 테스트 실패 — 숨기거나 수정하지 않음
명령: `npm test -- --maxWorkers=1 --no-fileParallelism`
결과: 311 files 중 287 PASS / 24 FAIL; 3068 tests PASS / 30 FAIL / 20 SKIP. 별도 Hanako.runtime mock export 로딩 오류 1개가 있어 실패 표제는 총 31개. phase5-full-tests.log.

원인 구분을 위해 실패한 24개 파일을 수정 전 Auth 소스로 로드하고 RTDB plugin을 제거한 진단 전용 config로 다시 실행했다. runtime 파일 자체는 되돌리거나 덮어쓰지 않았다. 나머지 candidate/test/setup은 동일하다. 결과: 24 FAIL, 30 tests FAIL / 246 PASS, **실패 표제 31개 완전 동일**(자동 비교 true). phase5-baseline-comparison.log 및 .config.mjs는 이 비교만을 위한 증거이며 개발·빌드·정상 테스트 경로에 연결하지 않았다. 변경 전 조건에서도 재현되는 실패이며 새 수정이 전체 게이트를 통과시킨 것은 아니다. 기획/Stage 확장 기대값, Studio fail-closed 기대값, toon mock export 등 범위 밖 실패를 임의 수정하지 않았다.

기계 검증/파일 SHA256/로그 SHA256: phase5-backend-verification.json.
QA 요약: Quaility_Assurance/integrated_release_20261016/phase5-backend-headless.md (canonical integration 루트).

## 남은 한계 / 인계 경계

- 실제 Google OAuth popup/redirect 완료와 Android native 실기기 로그인은 검증하지 않았다. 외부 Firebase auth helper/iframe의 저장소 동작도 이번 무네트워크 SDK 테스트의 보증 범위 밖이다.
- 최종 production build/dist는 브리프대로 Advisor 소유로 남겼으며 이 worker는 npm run build, server listen, browser 실행, sync, deploy를 하지 않았다. build와 실제 브라우저 OAuth/storage 검증 전 READY/배포 가능 판정 금지.
- 전체 테스트가 실패하므로 전 프로젝트 완료/릴리스 승인 주장하지 않는다. 기존 blocked mirror를 ready/running으로 바꾸지 않아 중복 dispatcher를 막는다.
- 사용자 Firebase 데이터 read/write/delete/seed/restore 명령, live deploy, rules/functions 변경, commit/push, title/audio/model 변경 없음. 실행한 테스트의 SDK 네트워크는 격리했다. 기존 Firebase 데이터 값으로 테스트 fixture를 만들지 않았다.

결론: 진단만 남긴 것이 아니라 실제 Auth+RTDB 최소 수정을 후보에 구현했고 실제 browser SDK 초기화에서 localStorage 접근 제거를 검증했다. 최종 OAuth·브라우저·빌드와 기존 전체 테스트 실패는 별도 미충족 게이트로 명시해 인계한다.
