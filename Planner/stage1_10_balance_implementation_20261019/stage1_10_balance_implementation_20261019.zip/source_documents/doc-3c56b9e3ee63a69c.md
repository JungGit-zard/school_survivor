# 기존 Firebase 영구 경로 정렬 및 오프라인 backfill 검토

담당 backendmini / 직접 Worker t_a3649121. blocked ADVISOR mirror 승격·자동 dispatch 없음. t_b331d7c0 provenance 유지. UI/auth/title/store 변경 없음.

## 읽기 증거와 정본 경로
- 근거: Quaility_Assurance/ranking_three_tabs_t_a3649121/firebase-readonly-field-audit.json 및 사용자가 지정한 저장소 밖 raw snapshot 3개를 오프라인으로 직접 읽었다. 새 Firebase CLI 조회/원격 쓰기는 하지 않았다.
- 실제 영구 경로는 rankingService/v1/public/all-time/global/allTime/all-time/entries 및 rankingService/v1/public/all-time/stage/{stage1..stage4}/allTime/all-time/entries.
- 위 기존 경로 하나로 runtime fetch/subscribe/submit/registration/promotion/account deletion을 정렬했다. 잘못 추가했던 /public/alltime 별도 영구 저장소는 runtime 및 명시 rules에서 제거했다. daily/weekly 시즌 경로는 그대로다. 영구 경로는 활성 시즌과 독립이다.
- rules는 all-time → allTime → all-time 정적 키만 연다. 임의 window/period를 허용하도록 wildcard를 넓히지 않았다. 본인 UID, stage 허용 목록 및 stageId 일치(비삭제 분기), 점수 단조 증가, 소유자 삭제 보호를 유지했다.
- users 9개, rankingService 점수 엔트리 266개. legacy rankings 점수 엔트리 14개 포함 입력 280개. 국가 필드는 실제 감사상 전부 없음. 국가 생성/추론/수집/외부 API/국가 schema 추가 없음. UI는 미기록으로 표시해야 한다.

## 오프라인 후보 실제 산출 결과
- 도구: Developer/r3f_prototype/scripts/ranking-alltime-backfill.mjs.
- private 후보: C:/Users/admin/AppData/Local/Temp/ranking-firebase-audit-20261016/alltime-backfill-candidate.json.
- raw users/email/photoURL/token 또는 UID별 후보 파일을 repo에 복사하지 않았다. private plan에는 공개 랭킹에 필요한 7필드와 쓰기 경로만 포함하고 원본 snapshot SHA-256을 담았다. stdout은 집계만 출력한다. 출력 위치가 repo 내부이면 거부하며 기존 후보 파일 덮어쓰기도 거부한다.
- 후보 global 14개, stage 22개, 총 36개 대상. snapshot 기준 insert-or-raise 30개, keep-current 6개. 신규 0점 global 후보 4개. 이름 누락으로 건너뛴 user 0개.
- 14 UID는 기존 공개 기록 UID와 users 9개를 합친 합집합이지 현재 Firebase Authentication 전체 계정 수의 증명이 아니다. 삭제된 계정 여부는 Authentication export 없이는 확정할 수 없다.
- stage를 알 수 없는 legacy global 2개는 임의 stage로 변환하지 않았다. 추가 오프라인 대조 결과 두 행 모두 동일 UID의 후보 global 최고가 해당 점수 이상으로 이미 포함되어 있다.
- 원본 점수가 있으면 그 점수를 보존한다. 개인 aggregate만 있는 경우 기존 getRankingScore를 재사용하고 최고 생존 런의 탈출·보스 보너스를 추정하지 않는다. 기존 공개 기록의 닉네임을 유지한다. users 신규 입장자는 실제 저장 nickname/displayName을 쓰며 UID를 생성하지 않는다.
- 제출 시각은 원본 submittedAt만 사용한다. ISO는 동일 시각의 epoch 밀리초로 변환한다. updatedAt은 기록 시각의 증거로 사용하지 않는다. 원본 시각이 없으면 필수 숫자 스키마에 0(미기록)을 넣으며 지금 시각으로 과거 기록을 꾸미지 않는다. 신규 실제 runtime 입장/런의 현재 시각 처리는 유지한다.

## 제안 쓰기 경로 / 실행 경계
- rankingService/v1/public/all-time/global/allTime/all-time/entries/{existingUid}
- rankingService/v1/public/all-time/stage/{stage1..stage4}/allTime/all-time/entries/{existingUid}
- 오프라인 CLI에는 apply 옵션이 없다. 실제 실행은 main이 private 후보를 검토한 뒤, 인증된 admin DB 핸들을 명시적으로 제공하여 export된 applyReviewedPlan(db, plan, { approved: true })를 호출하는 별도 승인 단계다. 이 세션은 이 함수를 실제 DB에 호출하지 않았다.
- apply 함수는 전체 후보 경로/필드/UID/stage를 먼저 검증한 후 각 UID 경로에서 transaction으로 최신 current를 다시 비교한다. current 점수가 같거나 높거나 malformed이면 쓰기를 중단한다. snapshotAction은 검토 안내일 뿐 적용 시점의 현재값을 덮는 권한이 아니다. database:update/set으로 plan을 통째로 적용하면 안 된다.
- 여러 UID에 걸친 transaction은 전체 atomic 작업이 아니다. 중간 실패 시 일부만 적용될 수 있다. 재실행은 각 경로 최신 최고를 다시 비교한다. 실행 전후 admin 검토/실제 DB 검증은 main의 별도 단계다.

## 수정 파일 / 실행 검증
- Developer/r3f_prototype/src/lib/firebaseRanking.js
- Developer/r3f_prototype/database.rules.json
- Developer/r3f_prototype/src/lib/firebaseRanking.test.js
- Developer/r3f_prototype/src/lib/firebaseRanking.entry.test.js
- Developer/r3f_prototype/src/lib/databaseRules.test.js
- Developer/r3f_prototype/scripts/ranking-alltime-backfill.mjs (신규)
- Developer/r3f_prototype/scripts/ranking-alltime-backfill.test.mjs (신규)
- 본 Developer 기록.
- mandatory checker exit 0, common/backend, matched backend/firebase, receipt c222950c882b46603399801745607683d248a3050ec2f84fb864f914d4330f71.
- native PowerShell node offline 후보 생성 exit 0 및 private 후보 readback allowlist/path 검증 성공.
- native PowerShell node --test scripts/ranking-alltime-backfill.test.mjs: 4 passed, 0 failed. synthetic transaction 테스트이며 실제 DB 호출 없음.
- git diff --check 지정 5개 기존 파일 exit 0. 최종 npm/rules/build는 main이 맡으므로 중복 실행하지 않았다. runtime/rules 전체 테스트의 새 통과를 이 기록에서 주장하지 않는다.
- 라이브 DB 쓰기/배포/서버/워치독/commit/push/pull 없음. 이전 Developer/agent_room/ranking_entry_retry_contract.md의 경로·일괄 backfill 미포함 설명 중 이번 명시 확장 범위와 충돌하는 부분은 이 실측 경로/오프라인 후보 기록으로 대체한다.
