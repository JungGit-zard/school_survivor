# Web release rollback package — 2026-10-05

Kanban task: `t_6cb1ba8f`
Role: `launchmini`
Scope: web release preparation only; no AAB, no Play Console, no Firebase mutation, no hosting deploy/promotion.

## Mandatory gate receipt

- Checker: `Developer/agent_room/mandatory_precommand/check-required-documents.ps1`
- Profile: `launchmini`
- Domain: `auto`
- Safe task summary: `web release checkout rollback patches validation`
- matched_domains: `qa`
- match_evidence: `qa` keyword `validation`
- resolved_domains: `common`, `qa`, `aab`
- combined_receipt_sha256: `50c5bcc4546506c91ab045b62c941e87f01799ddda3bac5a723edfe4f7e94147`
- launchmini generic mandatory preflight was included and read: `Developer/agent_room/launchmini_aab_physical_android_google_login_mandatory_preflight.md`

## Release checkout

- Source bare repository: `C:/Users/admin/AppData/Local/Temp/weapon-publish-bb95.git`
- Checkout path: `C:/Users/admin/AppData/Local/Temp/web_release_t_6cb1ba8f_20261005_234753`
- Checkout mode: `git worktree add --detach` from the existing bare repository; no full-history fetch performed.
- Release commit: `5edf7a00a8a052245b69a369f832ad929f806bc6`
- Release parent used for weapon rollback baseline: `dbd2209` parent relationship via `5edf7a0^`
- Release checkout status after validation: clean detached HEAD (`## HEAD (no branch)`).
- Main checkout was not reset, cleaned, rebased, merged, committed, pushed, or deployed.

## Rollback patches

Patches are stored under `Developer/agent_room/web_release_20261005/patches/` and are generated in rollback direction: current/new release state -> prior state.

| Patch | Scope | Size | SHA-256 | Validation |
| --- | --- | ---: | --- | --- |
| `rollback_weapon_tumbler_to_prior.patch` | `Tumbler.jsx`, `Tumbler.test.jsx` only | 2,230 bytes | `038b0478a5058929d80bd86cfdc2cb941aa3f20e099349630451c563cde8fa48` | PASS: applies to release tree via temporary index; changed paths exactly 2 expected paths |
| `rollback_weapon_shark_missile_to_prior.patch` | `SharkMissile.jsx` only | 8,436 bytes | `3f790eccdf551be23830faf5e107da159c0991c7c58b6ea7eff1ff451177354d` | PASS: applies to release tree via temporary index; changed paths exactly 1 expected path |
| `rollback_weapon_umbrella_guard_to_prior.patch` | `UmbrellaGuard.jsx` only | 3,794 bytes | `4842f93a8e9c7c56155d425e2618acea492c1d572b6a257963ff2f7b6cd7dfc7` | PASS: applies to release tree via temporary index; changed paths exactly 1 expected path |
| `rollback_player_appearance_f842495_to_prior.patch` | independent rollback of commit `f8424957f4f5ea192ca297f2a3c7a3ec3fcdc7fe` | 178,694 bytes | `9d323bbfb1abe8b6198f7488c13e58b2a7ed39175a1f5afe17aabdd4d94c821d` | PASS: applies to release tree via temporary index; changed paths exactly 17 expected paths |

Validation log:

- `Developer/agent_room/web_release_20261005/rollback_patch_validation.log`
- SHA-256: `61d3b68082fb96b4bd6ede1aaa4c12ed1773f9c79dee98b99ae4b66a5d885b62`

## Player appearance rollback changed paths

The independent `f842495` rollback patch deletes or modifies only the paths introduced/changed by that commit:

- `Developer/agent_room/player_appearance_backend_review_20261005.md`
- `Developer/agent_room/player_appearance_toggle_20261005.md`
- `Developer/r3f_prototype/database.rules.json`
- `Developer/r3f_prototype/src/components/LobbySettingsModal.jsx`
- `Developer/r3f_prototype/src/components/LobbySettingsModal.test.jsx`
- `Developer/r3f_prototype/src/components/Player.jsx`
- `Developer/r3f_prototype/src/components/Player.modelComparison.test.jsx`
- `Developer/r3f_prototype/src/lib/firebaseProgress.js`
- `Developer/r3f_prototype/src/lib/firebaseProgress.test.js`
- `Developer/r3f_prototype/src/lib/firebaseProgressRules.test.js`
- `Developer/r3f_prototype/src/lib/locales/en.js`
- `Developer/r3f_prototype/src/lib/locales/ja.js`
- `Developer/r3f_prototype/src/lib/locales/ko.js`
- `Developer/r3f_prototype/src/lib/titleSettings.js`
- `Quaility_Assurance/player_appearance_settings_20261005.md`
- `Quaility_Assurance/player_appearance_settings_desktop_20261005.png`
- `Quaility_Assurance/player_appearance_settings_mobile_20261005.png`

## Notes and boundaries

- Stage3 was already live per task body/advisor note; no hosting clone backup, build, deploy, promotion, or live QA was performed here.
- Rollback validation used a temporary Git index (`GIT_INDEX_FILE`) against the release checkout, so the checkout working tree remained untouched.
- No secrets are included in this manifest or patch set.
- Firebase data, authentication configuration, Android/AAB files, and dirty main-checkout work were preserved.
