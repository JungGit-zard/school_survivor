# 확장 저장 계약 — t_ba672cc5 / backendmini

## 상태와 소유권

- Board: escape-zombie-school. 등록된 backendmini Worker의 카드 t_ba672cc5 산출물.
- Reuse decision: 기존 backendmini 재사용 — Firebase 진행도/랭킹/규칙 전문 영역.
- 이전 읽기 전용 조사에서 도구 한도로 저장하지 못했던 계약을 이번 명시적 구현 배정으로 생성했다.
- ownership.md의 초기 문서 전용/encyclopedia 제외 문구는 이번 후속 사용자 배정으로 해당 경로에 한해 대체된다. ownership.md 자체는 수정하지 않았다.
- 이번 구현 소유 경로는 아래 목록뿐이다. 계정 seed, 실제 Firebase 읽기/쓰기, 배포, 인증 lifecycle, Studio/graphics/gameplay 런타임은 범위 밖이다.
- 제품 우선순위 문서의 일반 확장 보류에 대해 이번 소유자의 명시적 자율 확장 요청을 좁은 재우선순위로 적용했다. 새 백엔드 플랫폼/서버를 도입하지 않는다.

## 기준 계약

Planner/expansion_20261016/content_data.json과 build_contract_data.py를 읽었다. 초기 읽기에서는 JSON의 scoreStageBonus가 아직 없었으나 최종 정적 확인 시 생성된 JSON에 300/360/420/480/540이 반영되어 있었다. 이 Worker는 기획 파일을 생성/수정/재생성하지 않았다.

- 스테이지: stage6, stage7, stage8, stage9, stage10.
- 신규 일반 적: E19~E33. E09~E18은 임의 활성화하지 않는다.
- 신규 보스: B05~B09.
- Stage5의 마지막 포탈 종료를 변경하지 않는다. stage6는 Stage5 clear 후 별도 로비 진입으로 gameplay 담당자가 연결한다.
- 신규 보스 영구 패시브는 사양에 없다. bossPassiveUnlocks에 새 키를 만들지 않는다.

## 최소 진행도 인터페이스

정본 경로: users/{uid}/progress. 기존 schemaVersion=1, 저장 큐, hydrate 조건, 사용자 UID 경계를 유지한다. 신규 저장소/스토리지 키/상위 노드/계정 초기화는 없다.

records에 추가하는 정확한 10개 필드:

| stage | clear | best | 선행 해제 기록 | stage bonus |
|---|---|---|---|---:|
| stage6 | stage6Clears | stage6BestSurvivalSec | stage5Clears | 300 |
| stage7 | stage7Clears | stage7BestSurvivalSec | stage6Clears | 360 |
| stage8 | stage8Clears | stage8BestSurvivalSec | stage7Clears | 420 |
| stage9 | stage9Clears | stage9BestSurvivalSec | stage8Clears | 480 |
| stage10 | stage10Clears | stage10BestSurvivalSec | stage9Clears | 540 |

- firebaseProgress.js와 playerRecords.js의 두 RECORD_KEYS를 동일하게 확장한다.
- 기존 정규화 그대로 유효하지 않은 숫자/음수는 0으로 정규화하고 정수로 저장한다. 미등록 기록 키는 제거한다.
- 기존 계정의 누락 신규 필드는 기존 정규화 메커니즘으로 0을 얻는다. 원격 계정 생성/seed 업로드가 아니다.
- clear는 incrementRecord, best는 setBestIfHigher의 기존 경로를 재사용한다. 이전 최고 기록보다 낮은 결과는 best를 내리지 않는다.
- database.rules.json의 records.$recordKey는 이미 숫자 범위를 검사하므로 필드명을 추가하는 규칙 변경은 없다. 기존 0~1e9 경계도 이번에 변경하지 않는다.
- activity.lastStageId는 기존 문자열 검증으로 새 stage를 담을 수 있다. activity/auth/profile/consent 코드는 변경하지 않는다.

## 조우 ID와 정확한 라벨

기존 users/{uid}/progress/encounteredZombieTypes 아래 ID별 값 1을 재사용한다. 클라이언트 true 입력은 기존 정규화대로 1이 되고, DB 저장 규칙은 숫자 1만 허용한다.

| ID | nameKo |
|---|---|
| E19 | 서가운반 좀비 |
| E20 | 색인질주 좀비 |
| E21 | 반납투척 좀비 |
| E22 | 배양액 좀비 |
| E23 | 자석실험 좀비 |
| E24 | 보안경돌격 좀비 |
| E25 | 분무정원 좀비 |
| E26 | 덩굴견인 좀비 |
| E27 | 종자도약 좀비 |
| E28 | 조명기사 좀비 |
| E29 | 리본무용 좀비 |
| E30 | 북채행진 좀비 |
| E31 | 전선수리 좀비 |
| E32 | 풍향계질주 좀비 |
| E33 | 축전지운반 좀비 |
| B05 | 금서관장 |
| B06 | 융합과학교사 |
| B07 | 온실관리장 |
| B08 | 가면지휘자 |
| B09 | 폭풍교장 |

firebaseProgress의 명시 whitelist, zombieEncyclopedia의 알려진 ID/라벨, DB 조우 규칙에 모두 추가했다. encyclopedia는 기존 ENEMY_TYPE_NAMES와 불변 신규 ID 목록을 중복 제거해 결합하므로 levelmini의 풀 등록이 도착하기 전에도 저장 허용 범위가 누락되지 않는다. 풀에 새 export를 요구하지 않는다. levelmini 소유 enemyEntityPool.js는 수정하지 않았다.

## 랭킹 경계 — 기존 정본 보존

정본 all-time 경로는 변경하지 않는다:

- rankingService/v1/public/all-time/global/allTime/all-time/entries/{uid}
- rankingService/v1/public/all-time/stage/{stageId}/allTime/all-time/entries/{uid}

시즌 경로도 기존대로 유지한다:

- rankingService/v1/public/{seasonId}/global/{daily|weekly}/{periodKey}/entries/{uid}
- rankingService/v1/public/{seasonId}/stage/{stageId}/{daily|weekly}/{periodKey}/entries/{uid}

- firebaseRanking의 RANKING_STAGE_IDS, Functions ALLOWED_STAGE_IDS, DB 랭킹 관련 8개 stage whitelist 표현식을 Stage1~10으로 일치시켰다. Stage5는 기존 +240 그대로이며 저장/랭킹 정합성을 위해 포함한다.
- 클라이언트 STAGE_BONUS/우선순위/정책 반환값 및 Functions SERVER_STAGE_BONUS에 Stage6~10을 추가했다. 승인 공식은 60*(order-1). Stage1~5 기존 점수값과 탈출 15% → 보스 20% 순차 계산을 바꾸지 않는다.
- 기존 record → all-time 승격 코드의 survivalKeys를 Stage1 특수 키와 Stage2~10 BestSurvivalSec에 대응시킨다. clear 횟수로 과거 최고 런의 clear/boss 보너스를 추정하지 않고, 없는 기록 시각을 현재 시각으로 만들지 않는다.
- 로그인/로그아웃/계정 자동 등록 lifecycle 호출부는 변경하지 않는다. 테스트 외 신규 계정/가짜 진행도 생성은 없다.
- UID 자기 쓰기, entry UID 일치, per-stage 경로와 payload stage 일치, 단조 최고점, 독립 버킷 쓰기, failed/skipped 구분을 유지한다. time/score에 임의 게임 시간 상한을 새로 두지 않는다.
- 소유자의 삭제는 newData 없음 분기로 허용하며, 미로그인/다른 UID/미등록 stage 경로 삭제는 거절한다. 삭제 대상은 10 stage × 3 windows + global 3 windows = 33개이다.
- 과거 시즌/기간 전체를 클라이언트에서 열거할 수 없는 기존 삭제 한계는 그대로다. 이번 변경이 전체 역사 삭제를 보장하지 않는다.
- Functions 참조 구현의 기존 누적 projection을 클라이언트 최고점 모델로 바꾸지 않는다. 현재 클라이언트는 직접 RTDB 경로를 사용한다.

## Studio 카탈로그 저장 경계 — 변경 없음

- 정본: studioWorkspaces/v1/canonical/current.
- 기존 schemaVersion/revision/datasets 및 tunings/decals 등의 JSON 문자열 저장 방식 유지.
- 그래픽 담당은 신규 20개의 studioItemId(zombie-e19~zombie-e33, zombie-b05~zombie-b09)를 카탈로그/시각 컴포넌트에 연결해야 한다. 기존 tuning map은 카탈로그 ID whitelist로 필터링하지 않으므로 신규 DB dataset/권한 규칙은 불필요하다.
- B02 stage2-boss-v2, E07 특수 Studio ID, 기존 모델과 튜닝/승인값은 보존한다.
- firebaseStudio.js, graphicsStudioConfig.js 및 관련 모델/입력/원격 정본은 이 카드에서 수정하지 않는다. 이 카드는 화면 일치/Studio 적용 완료를 인증하지 않는다.

## 구현 파일 소유 경계

기준 경로: Developer/r3f_prototype/

- src/lib/firebaseProgress.js: 신규 record/조우 whitelist.
- src/lib/playerRecords.js: 신규 record 허용.
- src/lib/zombieEncyclopedia.js: 신규 ID/정확한 라벨 및 풀 등록과 독립된 저장 허용.
- src/lib/firebaseRanking.js: Stage1~10 등록/승격/삭제 범위. 기존 경로/알고리즘 보존.
- src/lib/rankingScorePolicy.js: 신규 점수 보너스/우선순위.
- functions/src/ranking.js: Stage1~10 whitelist/점수 참조.
- database.rules.json: 조우 whitelist와 랭킹 stage whitelist만 확장. users 권한, Studio, inspection 등 다른 규칙은 유지.
- 관련 테스트: expansionPersistence.test.js, databaseRules.test.js, firebaseRanking.test.js, firebaseRanking.entry.test.js, functions/test/ranking.test.js.

## 검증과 남은 통합 경계

실제 명령/결과는 persistence_implementation_result.md와 동명 로그를 따른다. RED에서 확장 필드/조우/랭킹 허용이 없어서 실패함을 확인한 뒤 구현했다.

필수 로컬 회귀: 신규 기록 hydrate→갱신→메모리 transport save→rehydrate, 기존 Stage1~5/골드 보존, 신규 20개 라벨/조우 멱등성, malformed/unknown 거절, 10개 stage client/server score parity, 모든 랭킹 family의 소유권/최고점/삭제/읽기 경계, canonical 경로와 역사 시각 보존.

실제 Firebase를 읽거나 쓰지 않았고 규칙을 배포하지 않았다. 따라서 소스/메모리 테스트 통과이지 운영 저장 승인 또는 실제 클라우드 저장 성공이 아니다. gameplay 스폰/보스/포탈/선택 UI와 graphics 연결 및 최종 독립 QA는 다른 담당자의 영역이다.
