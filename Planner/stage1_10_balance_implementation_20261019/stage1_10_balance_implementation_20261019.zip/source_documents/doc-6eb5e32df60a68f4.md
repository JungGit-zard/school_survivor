# Phase5 Level regression — 준비 전용 / 쓰기 승인 대기

Reuse decision: 기존 levelmini t_88579f49 blocked direct mirror를 재사용한다. 중복 작업자·카드를 만들지 않는다.

대상 후보: F:/From_SSD_D_20261005/JungSil/2.Minigame_project/releases/integrated-game-20261016-t_e2815ba8
정본 브리프: Developer/agent_room/integrated_release_20261016/phase5-level-regression-brief.md

## 쓰기 금지선
준비 시 canonical phase5-allow-regression-edits.json이 존재하지 않음을 확인했다. Advisor만 QA browser 종료 후 생성한다. 이 문서는 준비 기록이며 수리 완료/실행 결과가 아니다. 후보 소스·테스트를 변경하지 않았으며 테스트·빌드·브라우저도 실행하지 않았다. 카드 blocked 상태는 Advisor direct fence이므로 유지한다.

## 읽기 기반 확인 / 승인 후 acceptance
- Hanako.runtime.test.jsx: toon mock은 getCachedBoxGeo를 제공하지 않는다. 시각 의존성 mock만 호환시키고 실제 프레임 기반 반복 힐, 치비코 부재, 피해 중 힐, 주기 직전 무회복 검증을 유지한다. Hanako 런타임은 변경하지 않는다.
- bossPassiveItems: boxCutterDamage와 bikittyCutterDamage는 현재 damageMultiplier:1.15를 사용한다. 삭제된 .dmg로 기대값을 계산하는 기존 공식을 분리한다. 가산 카드와 비율 카드를 구분한 독립 기대값, B01/B02 1.05배, 치비코 1.1배, 반복 적용 비중첩을 유지한다. 실수치 계약 근거를 추가 확인한 뒤 테스트한다.
- unlocks/HUD: 현재 stageConfig.js:149–165는 Stage4→5, Stage6→7→8→9→10을 정의하고 Stage5/10 다음 항목은 없다. Stage4가 최종이라는 fixture를 제거하되 Stage4→5 실제 클릭/전이, Stage5/10 종료·gameKey 유지, Stage5→6 자동 이동 금지, 별도 로비 Stage6 진입 계약을 구별해 검증한다. HUD/타이틀 런타임은 쓰기 대상이 아니다.
- gameplayStateVerifier.js: STATE_VERIFIER_STAGES와 통계가 Stage1–4만 포함한다. portal action은 playing 상태에서 clearStageAndStartNext()를 호출하지만 store:1420 alias는 continueToNextStage()이며 cleared+escapeResult가 필요하다. ended 분기는 cleared를 곧바로 종료 취급한다. 따라서 실제 clear→명시적 continue 경로를 실행하는 verifier 수정이 필요하다. 기존 nextStageTransitions >0 assertion을 유지하고, 전이 전후 stage/phase/gameKey 증거와 Stage5/10 종결, Stage1–10 시작 coverage를 추가한다. 20,000 runs·결정성·5분 예산·상태복원·외부 저장 0회 검증을 약화하지 않는다. 이 항목은 게임 런타임 수리가 아닌 허용된 verifier 수리다.
- TitleScreen.settings: 모든 non-starter가 계정 해금 대상이라는 가정이 존재한다. weaponUnlocks.getAllUnlocked()는 isAccountUnlockable 필터를 적용한다. hanako의 확정 계정/동반자 획득 계약을 추가 확인한 뒤 fixture를 구성한다. 타이틀 소스는 잠금 유지.
- studentProximity: Stage3 학생 좌표 리터럴과 override 개수/목록의 의미를 조사 중이다. 33→34 숫자만 바꾸지 않는다. 차이 ID 및 published revision1947+3delta 근거를 확인한 후 authored placement를 그대로 둔 테스트를 작성한다. 아직 ID delta를 확정하지 않았다.

## Balance_QA_Mini 인계
승인 후 정상 npm test -- <담당 파일> --maxWorkers=1 --no-fileParallelism으로 수정 전 실패와 수정 후 결과를 보존한다. pretest는 우회하지 않는다. 우선 집중 테스트만 수행하며 9분 full suite는 자체 실행하지 않는다. canonical phase5-level-regression-result.md에 실제 로그·diff·파일 해시와 확인하지 못한 범위를 기록한다. 전체 QA 및 브라우저·실제 OAuth·built SDK storage 검증은 별도 승인 대상이며 본 준비 기록으로 GO 판정하지 않는다.

거리·맵·배치 변경은 없으므로 신규 unit/block 수치는 해당 없음. 잠긴 title/audio/graphics/Studio, 기존 충돌·안전 통로, authored 배치를 보존한다.
