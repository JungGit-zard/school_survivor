# Android AAB v19 빌드 기록

## 결과

- 파일: `Developer/r3f_prototype/android/app/build/outputs/bundle/release/app-release.aab`
- Android 버전: `versionCode 19`, `versionName 1.0.10`
- 애플리케이션 ID: `com.jungyoon.zombieschool`
- 빌드 소스 커밋: `c251832ddaa4cca340fe880cde2bb29a4fefc358`
- 원격 브랜치: `origin/feature/stage2-corridor-floor-graphics`
- 파일 크기: 15,049,564 bytes
- SHA-256: `d09075e1b32bedae14b88e5619d52410074caa4899d92aef124c03404280571a`

## 검증

- 빌드 전 로컬 SHA와 원격 SHA 일치 확인: 통과
- `clean :app:bundleRelease`: 통과, 161개 작업
- `unzip -t`: 압축 오류 없음
- `jarsigner -verify -verbose -certs`: `jar verified.`
- 업로드 인증서 SHA-256: `FE:18:FA:0E:BD:5C:E7:0F:30:04:6F:25:D3:07:5A:65:8A:2C:33:EA:DD:6F:5E:30:0C:85:FB:6E:E5:54:0F:3B`
- 인증서 만료일: 2053-11-06
- 병합 Manifest: versionCode 19, versionName 1.0.10, package `com.jungyoon.zombieschool`
- 번들 내부 최신 스테이지 3 표식: `stage3-hoop-north-normal`, `stage3-hoop-south-damaged`

## 빌드 중 확인한 문제

- 첫 AAB는 새 작업공간에 Git 제외 대상인 `keystore.properties`와 업로드 키가 없어 미서명 상태였다.
- 기존 프로젝트의 로컬 서명 자료를 복사한 후 `clean` 빌드했고, 최종 AAB에서 서명을 재검증했다.
- 미서명 중간 산출물은 최종 서명 AAB로 교체했다.

## 릴리스 제한

- 연결된 Android 기기와 AVD가 없어 WebView 실기 실행 증거를 확보하지 못했다.
- 이 파일은 검증된 AAB 빌드 후보지만, Play Console 업로드 전 실제 Android 실행 확인이 필요하다.
