# PLAYER Blender 모델링 보정 수용 계획 — t_692d1738

## 목표·권한·산출물

- 보드: escape-zombie-school. Advisor 감독 아래 levelmini가 순서와 수용 기준을 작성한다. 향후 그래픽 구현 담당은 기존 threemini, 독립 판정은 Balance_QA_Mini(balanceqa), 최종 원화 적합 승인자는 Terry다. 추가 자동 dispatch나 중복 카드를 만들지 않는다.
- 이번 실행은 이 계획 파일 하나와 기존 카드 댓글만 작성한다. 모델, 코드, 뷰어, Blender script/blend를 이번에 생성·수정하지 않는다. 아래 작업과 PASS 조건은 향후 승인된 archive-only 구현의 요구사항이며 실행 결과가 아니다.
- runtime/Firebase/타이틀/Studio/Git/auth/hooks/config/배포/서버 변경 금지. 역사적 D 경로는 사용하지 않고 검증된 F 루트를 사용한다. Stage 1 모바일 playable loop 우선순위를 바꾸거나 신규 콘텐츠로 확대하지 않는다.
- 보정 대상은 납품된 no-outline archive GLB다. 현재 게임 V9는 읽기 전용 비교·진단 대상이지 교체 대상이 아니다. 아카이브 변형을 Firebase Studio 값으로 가져오거나 게임 정본으로 승격하지 않는다.
- 사용자 마지막 해부학 문장이 미완성이다. '어깨와 목이 정확히 같은 높이/깊이여야 한다'는 식의 수치·등식은 만들지 않는다. 측면 원화에서 확인할 수 있는 상대 부착 위치만 기준으로 삼는다.
- 석재 표면, 푸른/금색 반사 리본, 흐르는 광택 및 glow FX는 명시적으로 후순위/범위 밖이다. 구조 결함을 효과로 가리지 않는다. no-outline은 이 archive study에만 허용된 예외이며 게임의 toon/외곽선 정책 변경이 아니다.

## 1. 실제로 읽은 근거와 확인 범위

프로젝트 루트: F:/From_SSD_D_20261005/JungSil/2.Minigame_project/school_survivor-integration

### 시작 게이트

- 실행: migrated root의 Developer/agent_room/mandatory_precommand/check-required-documents.ps1, -Profile levelmini -Domain auto -TaskSummary "PLAYER Blender graphics reference planning".
- 결과: exit 0. matched_domains=[graphics], match_evidence=graphics 키워드 graphics. resolved_domains=[common,graphics,gameplay]로 프로필 기본 gameplay가 포함되고 중복이 제거됐다.
- combined_receipt_sha256: edc5b10bf459292679e60573cb22e4517c87e33a732b108908eff6768ef9f6f7.
- 모든 발행 필독 문서를 읽었다. SESSION_MEMORY는 최신 단일 엔트리를 기준으로 삼는다. 추가로 Planner/current_game_rules.md와 Planner/game_guide_evidence_20261011.md를 읽었다. 기존 기획의 오래된 보스 시각·슬롯 수는 이번 모델링 수용 계획의 근거로 사용하지 않는다.
- gstack gate 실제 결과 GSTACK_OK. kanban-worker, systematic-debugging, writing-plans를 읽었다. 계획 작성 스킬의 일반 commit/실행 권고보다 이번 명시적 문서-only·Git 금지 범위가 우선한다.

### 현재 선택 경로: 코드 관찰이지 실제 게임 화면 검증은 아님

- Developer/r3f_prototype/src/components/Player.jsx 전체: PlayerVisual의 comparisonModel==='legacy'에만 PlayerMesh, 나머지는 PlayerV9Model. savedAppearance는 Firebase progress hydration 후 playerAppearance 또는 v9, hydration 전 v9. 개발 F8 비교 상태도 존재한다. 실제 사용자 원격 appearance는 조회하지 않았으므로 '현재 세션 화면이 무조건 V9'라고 단정하지 않는다.
- Developer/r3f_prototype/src/components/PlayerV9Model.jsx 전체: ../assets/models/PLAYER_v9_final.glb?url을 useGLTF로 소비한다. itemId=player-v9, grp_head/grp_armL/grp_armR/grp_legL/grp_legR/grp_pack을 포즈에 사용한다. 기존 숫자 child 경로·그룹·pivot·Studio 합산 계약을 변경하는 제안은 범위 밖이다.
- cloneMaterial은 toonMat으로 전환하며 원본 material.side와 map/alphaMap/normalMap/transparent/opacity/alphaTest를 이어받고 depthTest=true, depthWrite=true를 강제한다. 표면 renderOrder=90, frustumCulled=false, stencilRef=3. 따라서 depth 꺼짐 또는 frustum culling을 이미 확정된 원인으로 쓰면 안 된다.
- Developer/r3f_prototype/src/lib/toon.js 및 playerV9Outline.js 전체: 5단 nearest gradient, MeshToonMaterial, BackSide inverted hull/stencil 외곽선. V9 hull renderOrder=91, depthWrite=false, Decal_은 hull 생성 제외. 원본 표면과 hull/alpha decal을 분리해 진단해야 한다.
- 실제 V9 GLB JSON/accessor read-only 파싱: 389120 bytes, 40 mesh 정의, TRIANGLES 3784. 모든 material doubleSided=true이며 face/uniform/pleats/backpack 일부 재질은 alphaMode=BLEND. 3784는 authored 삼각형 수이며 런타임 hull·그림자·랜턴의 추가 비용을 포함하지 않는다.
- 코드 기준 높이: 0.89244 world units (0.22311 블록), gameplay 0.9 배율 적용 시 0.803196 world units (0.200799 블록). raw V9 height=3.0900000194이며 scale=0.2888155322. 이는 소스 기준 환산값이지 live Firebase 적용 후 측정값이 아니다. archive의 raw 좌표를 V9 raw 좌표와 그대로 비교하지 않는다.

### 납품 아카이브와 기존 메타데이터

- 입력: Graphic_designer/game_resource_library/source-art/player_glowing_surface_no_outline_20261011/PLAYER_glowing_surface_no_outline.glb.
- 같은 폴더 README.md 및 Quaility_Assurance/player_glowing_surface_no_outline_20261011/{structural_verification.json,browser_verification.json,verification_manifest.json} 전체를 읽었다.
- 이번 독립 GLB 파싱: 386004 bytes, 37 triangle meshes, 998 triangles. hair만 doubleSided=true, 대부분 material은 doubleSided 생략(단면 기본). 얼굴 이미지 이름 PLAYER_original_pixel_face_atlas_v3. 기존 메타는 원본 RGBA/UV 보존, mode-1 line primitive 36개/636 segments 제거, remaining line primitives 0을 기록한다. 제거 후에도 미참조 line buffer bytes가 남을 수 있다.
- 메타의 technical_pass=true와 human_art_approval=false는 동시에 존재한다. 기존 browser FX toggle 검증은 새 보정 결과의 원화 적합/Blender 작업 PASS가 아니다. glow는 viewer-side shader이고 GLB 표준 재질에 포함된 결과가 아니다.
- 이번 간이 topology 조사: POSITION을 소수 6자리로 좌표 병합해 무방향 edge 사용횟수를 집계했다. coherent_head_skull_UV_image_face 164 tris, backpack body 28 tris, torso core 32 tris, jacket front 좌/우 및 back 각 12 tris는 boundary edge 0, >2회 edge 0, 같은 좌표로 붕괴한 삼각형 0이다. continuous_fitted_reference_bob 154 tris는 boundary edge 20이다. 이것은 인덱스 연결·볼륨·노멀·winding·자가교차·가방 전체 조립의 합격 판정이 아니다. 특히 '가방 벽이 실제로 삭제됐다'는 가설은 아직 입증되지 않았다. 닫힌 듯한 메시도 뒤집힌 면, 면 방향 불일치, 재질/가림 때문에 열린 것처럼 보일 수 있다.
- 실제 PLAYER_no_outline_fx_off.png를 열어 보았다. 정면에서 재킷 앞판이 분절되어 보이고 상부 셔츠가 넓게 노출되며 손목 위 피부 구간이 보인다. 정면 캡처만으로 어깨 앞뒤 깊이, 뒤통수, 가방 측벽의 원인을 확정하지 않는다.

### 실제 원화 패널을 직접 열어 본 관찰

다음은 비교 모델 PNG가 아니라 실제 original 패널이다.

- Graphic_designer/game_resource_library/player_face_texture_v3_t_34a7ea5d/final/viewport_original_front_reference.png: 402×720 pixels. 넓고 큰 분홍 단발, 짧은 목·몸통, 몸 옆으로 이어지는 빨간 긴 소매, 흰 손목 커프, 가운데 흰 셔츠/칼라와 노란 넥타이 개구부, 파란 어깨끈. 의도된 흰 셔츠를 전부 빨강으로 메우면 실패다.
- 같은 final/viewport_original_side_reference.png: 300×720 pixels. 얼굴은 화면 오른쪽을 향한다. 후두부/단발은 정수리에서 뒤로 둥글게 이어져 목 뒤쪽까지 충분한 깊이를 가지며, 몸보다 머리의 앞뒤 볼륨이 크다. 소매 부착은 목·상체 측면 아래에 놓이고 뒤쪽 파란 어깨끈이 그 위를 지난다. 뒤의 가방은 두께와 위·아래·측면이 읽히는 닫힌 파란 덩어리이고 포켓이 외부에 붙는다.
- 두 패널은 정면/측면 관찰 근거이며 별도 후면 원화는 없다. 뒤쪽 장식·정확한 봉제·새 헤어 층을 발명하지 않는다. 필요한 숨은 후면은 이 두 패널의 외곽을 잇는 보수적인 닫힌 구조 후보로 만들고 Terry 승인을 받는다.

## 2. 순서와 단계별 수용 게이트

순서: 입력/좌표 기준 → 원인 분리 → 재킷·가방 구조 → 두개골·어깨 기준 구조 → 머리 피팅 → 전체 원화 피팅 → FX-free toon 검증. 구조 게이트 실패 시 미용·효과 단계로 넘어가지 않는다.

### P0 — 원본 보존과 비교 기준 고정 (threemini)

1. 신규 승인된 archive-only 작업 폴더에서 no-outline 입력을 복사한 후보만 사용한다. 원본 두 PNG, GLB, 기존 viewer를 덮어쓰지 않는다. 현재 과업은 그 폴더조차 만들지 않는다.
2. 설치된 Blender 실행 파일 C:/Program Files/Blender Foundation/Blender 5.2/blender.exe를 향후 headless 실행에 사용한다. 이번에는 존재만 확인했으며 Blender 실행/버전 동작 PASS를 주장하지 않는다.
3. Blender 정면·측면 orthographic viewport에 위 original PNG를 reference image로 넣는다. screenshot/model overlay를 원화 대신 넣지 않는다. exported GLB에서 reference-image 오브젝트는 제외한다.
4. 발바닥, 머리 꼭대기, 몸 중앙을 정렬하고 축 변환을 기록한다(Blender Z-up ↔ glTF Y-up). glTF 정면은 +Z로 고정하되 변환 확인 전 pivot 숫자의 부호만으로 앞/뒤를 판정하지 않는다.
5. 비교는 캐릭터 높이를 공통 H로 정규화한다. 카메라·포즈·정렬은 고정하며 부위별 카메라 왜곡/스케일로 맞추지 않는다.

수용: 입력 및 export 경로, reference image datablock 원본 경로, 카메라/축/정규화 H, 보존 대상 목록이 기록되고 정면·측면 Blender 캡처에 실제 원화 패널이 보일 것. 파일을 읽지 못하거나 원본 대신 비교 모델만 넣으면 중단.

### P1 — 원인 분리: normals/winding/depth/culling (모델 수정 전)

각 증상별로 원본 FX-free 동일 카메라에서 RED 캡처와 mesh/material/path를 기록한다. 노멀은 면의 바깥 방향, winding은 삼각형 정점 순서, culling은 뒤쪽 면을 그리지 않는 규칙이다.

1. skull/hair/jacket/backpack만 따로 보고 wireframe·face orientation을 확인한다. UV seam을 좌표 병합해 boundary loop를 분류하되 원본 정점을 손상시키지 않는다. missing cap, 비다양체 edge, zero-area, 뒤집힌 winding, negative-scale determinant, 자가교차를 구분한다.
2. 닫힌 가방은 각 연결 성분의 edge가 양방향 1회씩 공유되는지와 signed volume/바깥 노멀을 검사한다. 닫힘 edge 0만으로 PASS하지 않는다. 표면 NORMAL attribute와 geometry cross-product 방향 불일치도 확인한다.
3. 같은 후보·포즈로 FrontSide와 DoubleSide만 바꾼 diagnostic A/B를 독립 viewer 안에서 비교한다. DoubleSide에서만 돌아오는 면은 winding/단면 문제 후보이지 '닫힌 가방 해결'이 아니다. V9의 DoubleSide도 원인이 맞다는 증거가 아니다.
4. opaque surface는 depthTest=true/depthWrite=true, 기본 renderOrder로 검사한다. alpha decal과 outline/glow는 따로 끈다. BLEND와 depthWrite 조합/공면 decal의 가림이 의심되면 해당 레이어 하나만 끈 동일 시점 A/B를 남긴다. depth off/renderOrder 우선순위를 최종 수정으로 쓰지 않는다.
5. frustumCulled 진단은 메시 전체 소실과 bounds에만 적용한다. 면 한쪽의 구멍과 분리하며 현재 V9가 false라는 사실을 기록한다. 실시간 게임 코드를 바꿔 실험하지 않는다.

수용: 네 요구사항 각각에 '실제 누락면 / winding·노멀 / 조립 gap·관통 / alpha·depth·outline / 실루엣 불일치' 중 입증된 원인 및 아직 미확정 항목을 표로 남긴다. 한 변수 변경 전후 이미지가 없는 원인은 추정으로 표시한다. 3회 가설 수정에도 원인이 분리되지 않으면 Advisor 검토로 되돌린다.

### P2 — 빨간 재킷의 실제 연속 피복 복구

1. front wrap 두 장과 back panel 사이 측벽·겨드랑이·어깨 접합을 P1 결과에 따라 연결/보정한다. 각각 닫힌 box라도 서로 떨어져 있으면 피복 실패다. 셔츠 core를 가리는 불투명 빨간 외피가 측면·등·소매로 이어져야 한다.
2. 의도된 개구부는 중앙 흰 셔츠/칼라/넥타이, 양쪽 흰 손목 커프, 목과 손이다. 소매는 원화처럼 커프까지 내려오며 현재 archive의 손목 위 긴 맨살 구간을 재현하면 실패한다.
3. 가방을 diagnostic visibility off로 두고 등판을 검사해 가방으로 틈을 감추지 않는다. 겨드랑이·밑단·중앙 개구부 경계에 필요한 안쪽 return face를 배치하고 얇은 판끼리 공면으로 겹치지 않는다.

수용: neutral 정면·좌우 측면·뒤·상하 3/4에서 지정 개구부 밖 흰 몸통/피부/배경이 재킷 틈으로 보이는 건 0. 원화의 흰 셔츠 개구부와 커프는 유지. 각 폐곡면은 boundary/nonmanifold/zero-area/inconsistent winding 0; 의도된 의복 개구부는 위치·폐합/return 처리 목록을 별도 명시. 시각 노출 판정과 topology 판정을 모두 통과해야 한다.

### P3 — 가방을 물리적으로 닫힌 덩어리로 보장

1. backpack body를 단독 격리해 top/bottom/left/right/front/back을 전부 확인한다. 이미 벽이 있으면 지우고 다시 만드는 대신 P1에서 확인된 winding/노멀/조립 원인만 고친다.
2. lid/flap은 본체 빈 면을 가리는 스티커가 아니라 외부 부속이어야 한다. 모든 외부 시점에서 내부나 몸통 반대쪽이 보이지 않아야 한다. 끈과 포켓은 본체 closure 판정에서 분리한다.
3. 원화 측면의 납작하지만 두께 있는 파란 가방·뒤쪽 포켓을 유지한다. 몸통과의 관통/떠 있음, 끈의 어깨 경로도 캡처한다.

수용: 격리된 가방 본체 boundary edge=0, nonmanifold edge=0, zero-area=0, winding 불일치=0, outward orientation 확인. FrontSide/정상 depth에서 360도와 위·아래를 보아 열린 벽/관통 노출 0. DoubleSide/FX/outline/몸통을 숨김막으로 쓰지 않음. 부속과 본체 사이의 의도된 외부 이음은 목록화한다.

### P4 — 두개골과 어깨의 기준 구조 보정

1. 머리카락을 숨기고 완전한 skull의 crown→occiput(뒤통수)→nape(목 뒤) 단면을 먼저 만든다. 후두부 깊이를 원화 측면 외곽 안에서 풍부하게 조정한다. 얼굴 면만 넓히거나 머리카락 뒤에 속 빈 방을 만드는 방식은 금지.
2. 목 중심·상체 중심·어깨 실제 sleeve 접합점을 측면 같은 좌표계에서 측정한다. glTF archive head_neck_pivot은 torso에 대한 로컬 [0,0.68,0], shoulder pivot은 [±0.45,0.45,0.02]지만 이 값은 접합 표면 좌표나 원화 적합 증명이 아니다. V9 grp_arm의 z=0.22와 neck z=0.085도 별도 모델의 좌표이므로 같은 목표값으로 이식하지 않는다.
3. 어깨가 목보다 과하게 앞에 떠 보이는 문제는 관절 pivot 이동·sleeve geometry 이동·torso depth 중 실제 원인 한 가지씩 보정한다. 목 아래 옆몸통으로 연결하고 가방끈도 같은 경로를 따라 재피팅한다. 부착점만 숨기려고 목을 앞으로 밀지 않는다.

수용: 머리카락 off 상태 skull은 닫힌 외피, boundary/nonmanifold/zero-area/winding 불일치 0. head-to-neck 및 shoulder-to-torso 배경 틈 0. 측면 원화의 목 밑·소매 상단·상체 전후 윤곽과 부착 landmark 오차가 P6 기준을 만족할 것. 수정 전후 ΔX/ΔY/ΔZ를 raw model units와 공통 world 환산 units/블록으로 기록한다. 사용자 미완성 문장의 정확한 등식은 승인 조건으로 만들지 않는다.

### P5 — 풍부한 skull에 맞는 머리카락 피팅

1. 보정된 skull 외피를 기준으로 단발 crown/back/side가 하나의 읽히는 실루엣을 이루게 맞춘다. 정면 넓이·앞머리 낮은 직선 끝·측면 볼륨을 동시에 유지한다.
2. 현재 hair boundary 20은 입증된 '삭제면'이 아니다. 얼굴/목 개구부인지 루프 위치를 확인하고 필요한 안쪽 rim을 만든다. 모든 hair shell을 무조건 막아 얼굴을 가리지 않는다.
3. 머리카락 off skull과 on fitted hair를 같은 카메라에서 번갈아 보여준다. 보이는 두피 관통·헤어 속 빈 공간·얼굴 위 떠 있는 판을 허용하지 않는다. 과도한 층/새 헤어 장식은 추가하지 않는다.

수용: front/side/back/3/4에서 crown 및 뒤통수 외곽이 연속. 의도된 얼굴/목 개구부 외 accidental open edge 0; 보이는 scalp breakthrough 0; 얼굴 texture 가림은 원화 앞머리 범위만 허용. 뒤쪽 정보 부족은 후면 원화 확정이 아니라 Terry 승인 대기 후보로 표시한다.

### P6 — 구조 통과 후 원화 수치 피팅 및 예산

- 정면·측면 PNG를 별도로 정렬하되 동일 모델·동일 높이 H로 비교한다. head crown, 턱, 목 밑, shoulder 접합, 커프, 재킷 밑단, 가방 상하/뒤끝, skirt 밑단, 무릎, 발바닥 landmark를 표시한다. 표기 좌표와 mask를 저장하고 실제 측정 전에는 숫자를 관측값으로 꾸미지 않는다.
- 제안 acceptance tolerance: 해당 패널 H의 2% 이내 landmark 오차, head/hair/torso/bag 주요 silhouette 최대 윤곽 거리 H의 2% 이내, 전체 silhouette IoU≥0.90. IoU는 두 외곽 영역의 겹침 비율이다. 가방처럼 가려진 부위는 측면 visible mask만 사용하고 억지 전면 mask를 만들지 않는다.
- 위 수치는 Planner의 제안 기준이지 Terry가 이미 승인한 측정값이 아니다. 초기 승인 checkpoint에서 확인하며 카메라를 부위별로 바꿔 점수를 통과시키지 않는다. 후면은 원화 mask 점수 대신 구조·연속성·Terry 판단을 쓴다.
- 공간 오차는 Δraw×candidate world scale로 units를 구하고 블록=units/4로 병기한다. H를 읽기 전용 V9 소스 높이 0.89244 world units (0.22311 블록)에 정규화할 때 H×2%=0.0178488 units (0.0044622 블록). gameplay 소스 높이 0.803196 units (0.200799 블록) 비교에서는 0.01606392 units (0.00401598 블록). 이는 환산 예시이며 실제 Firebase 값이나 candidate scale을 뜻하지 않는다.
- archive 후보 총 authored TRIANGLES≤1000. 현재 998이므로 무조건 추가하지 말고 가려진 불필요 면/작은 버튼 등에서 재배분한다. skull/가방을 닫기 위해 필요한 면을 예산 때문에 삭제하지 않는다. 충돌하면 중단해 예산·요구 충돌을 보고한다. final export triangulation 후 및 viewer renderer 기준을 각각 기록한다.
- 얼굴 눈/눈썹/입/볼은 원본 RGBA+UV texture-only. 별도 눈구체/눈썹판/입 메시 0, 원화 표정 유지. UV 변경이 꼭 필요하면 변환 이유와 동일 픽셀 특징 보존을 증명하며 기존 텍스처를 새 그림으로 교체하지 않는다.

### P7 — FX-free toon 미리보기·Blender 재현 증거·QA 인계

향후 archive-only 구현 승인 후 요구되는 증거이며 이번에 만들거나 실행하지 않는다.

1. threemini는 headless Blender 실제 실행 명령·exit code·console log, 작업 script, 저장된 .blend, 최종 GLB를 제공한다. .blend를 다시 열어 reference PNG 두 장과 카메라·모델이 남아 있는지 확인한다. 실제 Blender executable/version, 원본 대비 변경 부위와 삼각형 재배분을 기록한다. 선언만 한 stub script는 불합격이다.
2. exported GLB를 새로운 독립 clean toon viewer에서 다시 읽어 MeshToonMaterial 또는 단계형 toon shader로 검사한다. glow/stone/ribbon/scroll shell/bloom 모두 off이고 hidden shell이 depth에 쓰지 않아야 한다. 회색 단일조명/고정 노출, neutral pose, 정상 depth, diagnostic FrontSide가 기준이다. 별도 원화 overlay/wire/face orientation은 명시적 debug toggle이다. GLB를 PBR로만 보여 주거나 기존 glowing viewer intensity만 0으로 둔 결과로 대체하지 않는다.
3. 기본 no-outline archive study를 유지하되 게임 외곽선 정책은 그대로다. 셰이더 onBeforeCompile FX가 빠졌고 얼굴 texture/UV가 살아 있음을 viewer state로 기록한다. 원본 metadata의 FX on comparison은 새 PASS 근거가 아니다.
4. 최소 캡처: neutral front/left side/right side/back/3/4/top/bottom, skull hair-off, hair-on, jacket bag-off, backpack isolated, wire/face orientation. 추가로 좌우 arm swing 양극단과 몸 굽힘에서 재킷/어깨/끈/가방의 틈·관통을 확인한다. 애니메이션 구현이나 게임 포즈 코드는 이번 범위 밖이며 독립 후보의 검증 포즈만 사용한다.
5. Balance_QA_Mini는 제작자와 독립적으로 exported GLB의 count/topology/face texture-only/FX off/원화 overlay 숫자/normal winding 및 재킷·가방 모든 gate를 재확인한다. 기존 QA JSON을 복사해 새 PASS로 제출하지 않는다.

QA handoff 필수 표: 단계 ID, 원인 가설/입증 근거, 수정 mesh, before/after 캡처, topology count, per-part/total triangles, front/side landmark 오차, world units/블록 환산, viewer material/depth/side 설정, Blender 재오픈 여부, 판정(PASS/FAIL/미검증), 후면 승인 대기 여부.

## 3. 완료·중단 기준과 현재 blockers

- 이번 Planner 완료: 이 단일 계획의 readback 및 필수 항목 확인 후 기존 t_692d1738 댓글에 절대 경로·관측 범위·미검증 항목을 기록한다. mirror는 blocked로 되돌려/유지하여 자동 중복 dispatch를 막는다. unblock/새 worker dispatch/제품 완료 선언은 하지 않는다.
- 향후 모델 수용: P1 원인 분리 및 P2~P7 모든 gate 통과 + Balance_QA_Mini 독립 확인 + Terry 원화 적합 승인. 기술 PASS와 사용자 아트 승인을 분리한다. runtime/Studio/title parity는 이번 archive 범위의 PASS가 아니며 별도 명시 승인 없이는 검사·적용하지 않는다.
- 현재 blocker 1: 열린 가방처럼 보이는 현상과 어깨 깊이/재킷 틈의 정확한 causal diagnosis는 아직 미확정. 간이 edge 집계는 가방/몸통 닫힘 가능성을 보이므로 '벽 없음'으로 단정하면 안 된다. 새 Blender/clean viewer A/B 미실행.
- 현재 blocker 2: 후면 original 패널이 없고 사용자 마지막 어깨/목 문장이 미완성. 보수적 후면 후보는 가능하지만 exact equality/새 디테일 확정은 불가, 아트 승인은 대기.
- 현재 blocker 3: no-outline 입력은 998 triangles로 상한 여유가 거의 없다. 폐합·피팅은 삼각형 재배분이 필요하고 아직 새 후보 budget 검증을 하지 않았다.
- 현재 blocker 4: live Firebase 값/실제 게임 실행 화면/기기 성능/새 Blender export와 재오픈은 이번 권한 범위 밖이거나 미실행이다. 소스 GLB 관찰을 runtime 화면·제품 적용 PASS로 확대하지 않는다.
- 계획 파일 생성 자체의 입력 blocker는 없다. gate와 original PNG 두 장, 현재 V9 GLB, delivered archive GLB·메타는 읽을 수 있었다. hooks/profile/path policy를 복구하거나 변경하지 않았다.
