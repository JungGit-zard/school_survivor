# Stage5 / 자판기 플레이 슬라이스 — t_c49f88b6

## 범위와 정본
- Stage1 모바일 루프 보존이 우선. 기존 Stage1–4 수치/모델/타임라인과 Stage2 해금 dirty 변경은 수정하지 않는다.
- 현행 stageConfig, burstEvents, waveTimelines, stageRuntime, Enemies, useGameStore를 사용한다. 랜덤 웨이브는 실제 런타임 발화 경로가 아니므로 명시 버스트가 플레이 정본이다.
- Stage5 이름: 학교 최종 돌파. 기존 승인된 E01–E07 및 B03 체육교사 재대결을 사용한다. 새 보스/임시 모델/Studio 상태를 만들지 않는다.

## 공간·진행
- 기존 Stage3와 동일한 경계: halfX 7.5 units(1.875블록), halfZ 19.2 units(4.8블록); 전체 15×38.4 units(3.75×9.6블록).
- 시작 (0,0,0) units(0,0,0블록), 자판기 동쪽 (6.25,0,-14) units(1.5625,0,-3.5블록). 자판기 상호작용 반경 2.25 units(0.5625블록).
- Stage4 클리어 1회로 Stage5 해금. Stage4 포탈 → Stage5 resetGame → 마지막 포탈 → cleared. Stage5 뒤 추가 스테이지 없음.
- 기준 길이 240초, 보스 150초, 마틸다 경고 205초/실체 210초, 포탈 210초. 자동 클리어 없음. 300초 이후 기존 무한 보강 경로 재사용.

## 압박 곡선
- 5초 E01×12 → 24초 E03×6 → 40초 E07×6 → 60초 E03×8 → 72초 E04×2.
- 108초 E02×4, 110초 기존 E07×3/E02×3, 120초 E05×4, 144초 E07×6.
- 150초 B03×1 + E01×8; 168초 E04×2; 184초 E06×2; 216초 E05×4.
- 160/180/200/220초 E01×8 + E07×2 반복 보강. 보스 직후 10초를 비워 읽을 시간을 주며 이후 도주 동선을 압박한다. 240초 종료는 반복 descriptor exclusive 경계다.
- 기존 적 HP 누적 1.2배 곡선의 다음 값(1.2^4), 이동/피해/AI 불변. E04 실발사 72초 이후, 보스 중 원거리 억제는 기존 일반 규칙 유지. 동시 좀비/투사체 cap은 기존 경로를 그대로 사용한다.
- wave phases는 0–48 준비, 48–108 이동, 108–150 복합, 150–192 보스, 192–240 탈출. 실제 적은 위 명시 이벤트로 공급한다.

## 보상·자판기
- 48/144/192/240초 골드 5/7/11/20, 런당 1회. 210초 즉시 탈출 시 240초 보상은 받지 않는다. 기존 도지60/코인몬스터90·180 이벤트 재사용.
- Stage5 점수 보너스 +240, 기존 탈출15%/보스20% 순차 산식 유지.
- 회복음료 기존 잠정값 5 gold/35 HP/스테이지 런당 1개 유지(새 밸런스 승인 주장 금지). 영구 지갑만 차감, 즉시 maxHp 상한 회복. hydrate 실패 시 차감·회복 모두 거절한다.
- live playerPos 거리만 신뢰하고 caller 좌표 무시. 상속 키/다른 machine/stage/gameKey 거절. 효과·차감·구매권은 단일 Zustand 갱신, 영구 메모리 갱신도 구독자 알림 전에 수행해 재진입 구매가 지갑을 되돌리지 않게 한다.

## 수용 기준 / Balance_QA_Mini 인계
1. Stage4 해금 조건 보존, Stage4 clear→Stage5 playing→210초 포탈→Stage5 cleared를 실제 store 액션과 Game/Enemies/포탈 frame 하니스로 검증한다. 보스 처치만으로는 clear되지 않는다.
2. 모든 Stage5 이벤트의 실제 풀/보스 생성, 150초 보스 단 1회, pause 중 정지, 재시도 중복 없음, 무한 보강 및 cap 검증. helper-only 통과를 실제 화면 통과로 보고하지 않는다.
3. Stage5 기록키 clear/best가 playerRecords 및 Firebase payload 정규화에서 보존된다. Firebase 테스트는 주입된 메모리 transport만 쓴다. 실데이터/규칙 변경 금지.
4. 구매 성공/실패/재진입/상한/경계/옛 요청/exit/retry/next/new run 검증. Stage1–4 기존 회귀 테스트 유지.
5. 그래픽/UI 담당은 Developer/agent_room/stage5_full_release_contract.md의 mount/로비 카드를 연결하고 실기기 화면·포탈 접근성·자판기 가시성/터치 타깃을 확인해야 한다. 이 작업자는 장면/Floor/HUD/Lobby를 편집하지 않는다.
6. Firebase 배포 규칙의 stage whitelist는 backend 릴리스 담당 확인 항목이다. 규칙이 stage5를 거절하면 실제 저장/랭킹은 차단이며 테스트 mock 성공을 클라우드 성공으로 확대하지 않는다.

## 금지
RosariRoom/scene/Floor/HUD/Lobby, auth/title/Studio/audio 편집, live Firebase 테스트, 다른 dirty 변경 덮어쓰기, 커밋·푸시·배포, 다른 카드 dispatch 및 recursive delegation 없음. 카드 blocked direct-run fence 유지.
