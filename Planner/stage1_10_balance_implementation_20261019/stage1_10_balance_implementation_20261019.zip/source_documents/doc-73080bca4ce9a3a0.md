# 확장 스테이지 UI 인계 — uimini / t_ea4f9920

## 최신 후속 결과 — Advisor 확인

아래 본문은 최초 구현 인계 기록이다. 후속 실행에서는 Lobby.test.jsx의 오래된 고정 개수 기대값을 현재 5개 해금·5개 잠금 구성에 맞췄다. 최종 `ui_fixture_repair_focused.log`는 **62 통과 / 1 실패 / 63개**, 실제 종료 코드 1이다. 남은 실패는 10,000회 반복 검사의 600,000ms 시간 제한 초과이며, 검증 완료로 처리하지 않는다. 실행 시간과 명령은 `ui_fixture_repair_result.json`에 보존했다. 테스트 반복 횟수·제한과 런타임 인증 동작은 변경하지 않았다. 최신 전체 상태는 [통합 목차](README.md)를 따른다.

## 실행 경계
- Board: escape-zombie-school. 등록 uimini의 Advisor-managed blocked direct worker 실행. 카드와 parent t_3beb016a의 blocked/자동 dispatch 방지 상태는 변경하지 않았다.
- 실제 루트: F:/From_SSD_D_20261005/JungSil/2.Minigame_project/school_survivor-integration
- content_contract.md/content_data.json, ownership.md와 실제 stageConfig/expansionVisuals를 읽고 UI 소유 파일만 수정했다. STAGE_CONFIGS의 기존 Object.keys 열거와 isStageUnlocked를 그대로 소비한다. 새 게임플레이 데이터·모델을 복제하지 않았다.
- auth/records/readiness/backend, Stage1~5 카피·디자인·B01~B04 앵커, 타이틀 프레젠테이션, Rosari, 전역 CSS, 공유 부모, 정책/프로필, 오디오 로직은 수정하지 않았다. locales에 이미 있던 ranking/title.homepage/logoutSaveFailed 변경은 보존했다. 기존 테스트도 수정하지 않았다.

## 정확한 변경 경로 (아래는 루트 기준)
1. Developer/r3f_prototype/src/components/Lobby.jsx
   - Stage6~10 직전 스테이지 클리어 잠금 안내 연결. 기존 해금/진행도 판정은 변경 없음.
   - 신규 카드에만 테마 설명과 aria-describedby, 신규 보스 이름 쇼타임 표시.
   - 기존 스크롤 리스트에 키보드 포커스/region, 카드 flexShrink:0. 신규 잠금/보스 프리뷰는 pointerEvents:none으로 카드 클릭은 부모에 전달하고 Canvas의 스와이프 점유를 피한다. 기존 Stage1~5 프리뷰 스타일은 유지.
2. Developer/r3f_prototype/src/components/StageBossPreview.jsx
   - B05~B09 FACE_LOCAL_Y=0.83: expansionVisuals.makeRig의 head position.y와 일치. 기존 ENEMY_STATS별 scale 및 0.333 경로/Studio framing을 그대로 사용.
   - 신규 비인터랙티브 보스 프리뷰만 touchAction:pan-y. 기존 B01~B04와 interactive Studio의 none 유지. 모델/리그/카메라/zoom/모션 변경 없음.
3. Developer/r3f_prototype/src/lib/locales/ko.js
4. Developer/r3f_prototype/src/lib/locales/en.js
5. Developer/r3f_prototype/src/lib/locales/ja.js
   - 각각 신규 stage6~10 title/description/boss와 lobby.unlock.stage6~10 키만 추가. 기존 ranking 번역 등 삭제/수정 없음.
6. Developer/r3f_prototype/src/components/Lobby.expansion.test.jsx (신규 10 tests)
7. Developer/r3f_prototype/src/components/StageBossPreview.expansion.test.jsx (신규 8 tests)
8. Developer/agent_room/expansion_20261016/ui_handoff.md (이 파일)
- 실행 로그도 같은 인계 폴더에 신규 생성: ui_red.log, ui_red_corrected.log, ui_touch_red.log, ui_focused.log, ui_green.log, ui_final_focused.log.

## 실제 검증
- 최초 mandatory checker exit0, matched_domains=[ui,gameplay,qa], match_evidence=ui/ui, gameplay/stage, qa/review. gstack=GSTACK_OK.
- 최초 combined_receipt_sha256=b54ddb02ef802fecd87314990058e914e6d50656db768bdd09ff12b47dd9549d.
- 최종 재실행 exit0, 도메인/근거 동일. latest QA 선택이 full_release_20261015.md로 바뀌어 해당 문서를 전체 읽었다. 새 receipt=8e0499e7ea28f21046c8dd1be1d1f92721972dc12b74d18ce730c0a36500e6a8.
- 모든 테스트는 Developer/r3f_prototype에서 npm test로 실행했다. branch:check / no-legacy-b02 / dialogue-store(451 Korean IDs) / studio-game-sync pretest gates 모두 실제 통과. 우회 실행 없음.
- RED: ui_red.log에서 UI 소스 수정 전 기존 Lobby.test.jsx 실패 2건 확인. 신규 테스트의 0px/0 및 jsdom import.meta.url 경로 오류를 수정한 뒤 ui_red_corrected.log에서 신규 18개 중 15 실패/3 통과(키/앵커/스크롤/보스명 미구현)를 확인했다.
- 추가 touch RED: ui_touch_red.log에서 신규 프리뷰의 pointerEvents 미설정 때문에 5건 실패 확인 후 신규 카드에만 수정했다.
- GREEN 명령: npm test -- src/components/Lobby.expansion.test.jsx src/components/StageBossPreview.expansion.test.jsx src/components/StageBossPreview.test.jsx
  - ui_green.log: exit0, 3 files / 36 tests PASS (신규18 + 기존 StageBossPreview18).
- 최종 인접 회귀 명령: npm test -- src/components/Lobby.expansion.test.jsx src/components/StageBossPreview.expansion.test.jsx src/components/Lobby.test.jsx src/components/StageBossPreview.test.jsx
  - ui_final_focused.log: exit1, 3 files PASS / 1 file FAIL, 61 PASS / 2 FAIL / 63 total.
  - 기존과 동일한 Lobby.test.jsx:191 입장 버튼 4 기대/실제5, :234 잠금 프리뷰0 기대/실제5. 전자는 기존 Stage5 진입, 후자는 신규 Stage6~10 잠금 카드가 존재하는 현재 구성과 맞지 않는 고정 개수 단언이다. 두 실패 모두 이번 UI 수정 전 baseline에 존재했고 그대로 남겼다. 테스트 전체 통과 또는 10,000회 루프 완료를 주장하지 않는다. 기존 파일에는 act 환경 경고도 있다.
- 신규 테스트 범위: ko/en/ja 신규 키·렌더, 실제 stageConfig 기반 10개 카드, 마지막 Stage10 DOM 순서·스크롤/flex 계약, 직전 clear 전 잠금/이후 해당 stageId 진입, 1초 쇼타임·B05~B09 매핑, 기존 progress pending 게이트, rig head와 preview 앵커/타입별 scale 계산. Firebase는 기존 테스트용 메모리 seed/update만 사용했고 live API/저장값 변경 없음.
- git diff --check scoped source paths: exit0, 공백 오류 없음. Lobby 기존 CRLF에 대한 Git LF 정규화 경고는 있었으며 전체 파일 변환은 하지 않았다. locales의 HEAD diff에는 착수 전 ranking 변경 등이 포함되므로 전체 diff를 이번 UI 변경으로 계산하면 안 된다.

## 남은 의존성 / 검증 한계
- Advisor/levelmini/threemini의 최종 데이터·EnemyVisual/모델·환경 통합과 balanceqa 독립 acceptance 필요. 실제 현재 STAGE_CONFIGS를 읽는 UI 테스트는 통과했지만 작업 중인 전체 게임 경로를 승인한 것은 아니다.
- 기존 Lobby 테스트의 4/0 전역 고정 개수 단언을 소유자가 범위별 단언으로 갱신할 필요가 있다. 이 worker는 해당 기존 테스트나 진행 로직을 고치지 않았다.
- full build/full suite는 Advisor 이후 실행. 브라우저·서버·live Firebase·실기기 실행, commit/push/deploy 없음.
- 실제 10개 카드 터치 스크롤 도달/작은 화면 긴 제목·버튼 겹침/실제 보스 얼굴 프레이밍/FPS는 미검증이다. jsdom 스타일/DOM 및 앵커 수학 통과를 모바일·화면 시각 합격으로 해석하지 않는다. Studio pan/회전/사용자 튜닝을 수정하거나 보정하지 않았다.
