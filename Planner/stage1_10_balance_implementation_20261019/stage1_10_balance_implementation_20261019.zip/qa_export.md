# 문서 내보내기 QA

구현 기준 a9f84bf8e7f22d2b1b1c191f7b23ee2e0e908ff8

10개 상세 문서, HTML UTF-8·앵커·상대 링크, 614개 원문 복사 SHA-256, 42개 Git 고정 코드 해시 및 217개 소스 경로/라인/해시 인용 검사를 통과했다.

보안 검사는 패턴 기반이며 절대 무민감정보 보장이 아니다. 원문 내부의 역사적 링크는 바이트 보존 때문에 수정하지 않았으며 생성 문서/HTML의 링크만 검사했다. 모바일 실플레이·실제 Firebase/계정·해금 구현·자판기 실구매·청취·배포 검증은 수행하지 않았다.

ZIP 최종 CRC/항목별 바이트 일치/SHA-256 결과는 외부 Quaility_Assurance/stage_balance_export_20261019/qa-result.json에서 확인한다.

실행: python Quaility_Assurance/stage_balance_export_20261019/verify_package.py
