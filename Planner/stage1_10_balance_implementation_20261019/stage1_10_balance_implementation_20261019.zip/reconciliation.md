# 기획·고정 구현·최신 요구 대조

고정 구현: a9f84bf8e7f22d2b1b1c191f7b23ee2e0e908ff8 (F:/From_SSD_D_20261005/JungSil/2.Minigame_project/releases/owner-all-complete-20261018). 생성 UTC 2026-10-19T14:39:26.006947+00:00. 실제 Firebase 값과 실기기 플레이는 조회/시험하지 않았다. 숫자는 소스 기본값이며 Admin/Studio 오버라이드가 있으면 실효값은 달라질 수 있다. 원문 문서는 생성 시점의 canonical 파일을 바이트 그대로 보존했다.

| 주제 | a9f84bf8 고정 구현 | 최신 요구/과거 기획과의 차이 | 판정 |
|---|---|---|---|
| 해금 | Stage1 항상; Stage2~10 이전 stageClears>=1 | 최신 승인: 이전 보스 처치만으로 즉시 영구 해금, 탈출/시간/퀘스트 불필요 | 고정판 미반영; 동시 런타임 워커 소유 |
| Stage5→6 | NEXT_STAGE_BY_STAGE에 stage5 없음 / null | Stage6 로비 클리어 조건과 자동 다음 이동은 다름 | 문서만 기록; 수정 안 함 |
| Stage6~10 | 별도 확장 enemy/boss/events/스폰/안전성 런타임 | 과거 비플레이어블/미구현 기획을 그대로 현재 판정으로 쓰지 않음 | 고정 소스 구현 있음; 실제 플레이 미검증 |
| 웨이브 | getRuntimeSpawnEventsForStage=명시 burst+코인 이벤트 | 20~40초 랜덤/중간/호위 자동 웨이브는 비활성 | 프로브 target/weights와 활성 스폰 분리 |
| 기존 적 HP | round(base×1.2^(stage-1)); 신규 확장 제외 | 과거 HP 총량/앵커 주석은 과거 예산; 현재 함수가 우선 | 현재 계산은 문서 표 참조 |
| E08 | 90/180초 코인 이벤트가 실제 런타임에 합성됨 | enemyEntityPool의 아직 스폰 안 한다는 과거 주석과 충돌 | 실제 호출 코드 우선 |
| B03 Stage5 | B03 이벤트 있으나 shuttle 특수는 currentStageId stage3 조건 | 같은 보스 타입이라도 특수 동작을 복사해 설명하면 틀림 | Stage5 전용 특별 행동 추가 가정 안 함 |
| 자판기 | 기본 5 gold / HP35, provisional-not-owner-approved | 최종 승인 밸런스처럼 쓰면 안 됨 | 미승인 잠정값 라벨 유지 |
| 240초 | duration 기본값/마일스톤; 오버타임 경로 존재 | 4분에 자동 클리어/강제 종료라고 단정 불가 | 탈출/사망 계약과 구분 |
| Admin/Firebase | 소스의 default 값과 override 소비 함수만 조사 | 실효 계정/튜닝 데이터 미조회 | 실효값/계정 정상 동작 미검증 |

## 이전 문서 스냅샷과 최신 승인 변경

66c9198b는 과거 기준이며 이 최종 패키지의 구현 기준이 아니다. 최신 고정 기준은 a9f84bf8e7f22d2b1b1c191f7b23ee2e0e908ff8이다. Enemy.jsx + matildaDashSpeed.js의 실제 대시별 기본 속도 1% 가산, 전 플레이 가능 stage 자판기 연결/현재 벽 회전, HUD의 현재 저장 표시 변경을 최신 코드로 다시 읽었다. 승인된 오디오 정합/마틸다 음성 3종 변경은 최신 커밋 이력에 포함되나 오디오 실청·배포 검증은 이 문서 QA 범위가 아니다. 이 패키지에는 런타임 오디오 자산을 복제하지 않았다.

[Developer/r3f_prototype/src/lib/matildaDashSpeed.js:L1 · a9f84bf8 · SHA 3ae7adafc70a](index.html#code-036) · [Developer/r3f_prototype/src/components/StageVendingLayer.jsx:L1 · a9f84bf8 · SHA 33fadf9c0bb7](index.html#code-037) · [Developer/r3f_prototype/src/components/HUD.jsx:L1 · a9f84bf8 · SHA ed571a8f6148](index.html#code-038)

## 원격·동시 작업 보존

기준 SHA: a9f84bf8e7f22d2b1b1c191f7b23ee2e0e908ff8

현재 HEAD: a9f84bf8e7f22d2b1b1c191f7b23ee2e0e908ff8

fetch 후 origin/zombie_only: a9f84bf8e7f22d2b1b1c191f7b23ee2e0e908ff8

기준 이후 커밋:

```text
```

새 문서/QA 폴더만 작성했다. runtime 파일, tests, Rules, 기존 원문은 편집하지 않았다. checkout/reset/rebase/push/deploy·서버·브라우저·추가 worker를 실행하지 않았다. Dirty runtime 경로는 repository-checkpoint.json에 그대로 별도 관찰 기록했으며 이 문서 작업의 변경이라고 간주하지 않는다. 새 해금 ready receipt는 최종 QA에서 다시 경로 검색 후 추가 기록한다.
## 동시 보스 해금 워커 상태(소스와 별도 관찰)

관찰한 receipt: F:/From_SSD_D_20261005/JungSil/2.Minigame_project/school_survivor-integration/Developer/agent_room/boss_only_unlock_20261019/levelmini-blocked.json, SHA-256 f37ca66d79213dea5cac2937e882f76526e1c8ea9e6769b3a784bb8b79165977, 수정 UTC 2026-10-19T14:15:01.865944+00:00. 상태 BLOCKED_PRETEST_BRANCH_POLICY_CONFLICT, ready=False, baseline=a9f84bf8e7f22d2b1b1c191f7b23ee2e0e908ff8. 이 receipt는 과거 차단 시점의 기록이고 continuation 진행 여부는 보장하지 않는다. 최신 ready hash receipt가 없으면 구현/배포 완료라고 선언하지 않는다.

Advisor 별도 검토는 clear-only grandfathering도 불허한다. stageNClears=999만 있고 stage별 boss 증거가 없거나 0이면 다음 stage는 잠겨 있어야 한다. 전체 누적 bossKills는 stage별 처치 증거가 아니다. 기존 점수·골드·클리어 기록을 보스 처치 기록으로 합성하거나 계정 데이터를 원격 수정하지 않는다. 검토 경로: F:/From_SSD_D_20261005/JungSil/2.Minigame_project/school_survivor-integration/Developer/agent_room/boss_only_unlock_20261019/advisor-blocking-review.md, SHA-256 da033e207979aec021bfb0a43997e54dffd0dba9a6786ab7043a70ce62b0a0fd.

