# 공통 시스템 — 초보자를 위한 고정 구현 설명

고정 구현: a9f84bf8e7f22d2b1b1c191f7b23ee2e0e908ff8 (F:/From_SSD_D_20261005/JungSil/2.Minigame_project/releases/owner-all-complete-20261018). 생성 UTC 2026-10-19T14:39:26.006947+00:00. 실제 Firebase 값과 실기기 플레이는 조회/시험하지 않았다. 숫자는 소스 기본값이며 Admin/Studio 오버라이드가 있으면 실효값은 달라질 수 있다. 원문 문서는 생성 시점의 canonical 파일을 바이트 그대로 보존했다.

## 읽는 방법과 단위

HP는 적이 버티는 체력, damage는 공격 1회 기본 피해, cooldown은 다음 공격까지의 밀리초(ms)다. 1000ms=1초. 이동 속도는 world units/초이며 1 block=4 world units다. 표의 적 수는 생성 요청량이지 동시 생존 수/성공 보장이 아니다. 안전 위치 검색·전역 상한·스폰 큐·처치 속도에 따라 화면 밀도는 달라진다.

[Developer/r3f_prototype/src/lib/gameplayUnits.js:L1 · a9f84bf8 · SHA 7f70caf5aae3](index.html#code-027)

## 플레이어·피해·성장

초기 HP/최대 HP는 100, 속도는 3 world units/초 = 0.75 blocks/초, 레벨 1, XP 0, 다음 레벨 필요 XP 9다. 영구 최대 HP 레벨당 +2, 이동속도 레벨당 기본 대비 +1%, 공격력 패시브 레벨당 +(0.04/3), 성장 패시브 레벨당 +(0.05/3)이며 보스 패시브/무기별 영구 강화와 Admin 오버라이드는 별도다. 실제 계정 강화값은 읽지 않았다.

일반 피해는 playing 상태이고 무적이 아닐 때 HP에서 차감하며 0 이하이면 gameover다. 마틸다 killPlayer는 별도 즉사 경로다. 비치명 피격 후 무적 해제는 Player 프레임 경로가 소유한다.

플레이어 초기 상태와 영구 강화/무기 생성의 정확한 적용 순서는 아래 고정 코드 구간을 따른다. 계정 성장 실제값은 읽지 않았다. 공통값을 스테이지마다 임의로 복제하지 않는다.

[Developer/r3f_prototype/src/store/useGameStore.js:L1 · a9f84bf8 · SHA 263f032d74a1](index.html#code-031)

```javascript
... 별도 근거 구간 ...
163: }
164: 
165: const BASE_PLAYER = {
166:   hp: 100, maxHp: 100,
167:   speed: 3, baseSpeed: 3,
168:   level: 1, xp: 0, xpToNext: XP_TO_NEXT_START,
169:   invulnerable: false,
170:   hitFlashToken: 0,
171:   healFlashToken: 0,
172: }
173: 
174: function buildInitialPlayer(levels, bossPassiveUnlocks = {}) {
175:   const adminBalance = getAdminBalanceConfig()
176:   const maxHp = BASE_PLAYER.maxHp + 2 * (levels.maxHp ?? 0) + adminBalance.player.maxHpBonus
177:   const speed = BASE_PLAYER.speed * (1 + 0.01 * (levels.moveSpeed ?? 0)) * adminBalance.player.speedMultiplier
178:   return applyBossPassiveMaxHp(applyBossPassiveMovementSpeed({
179:     ...BASE_PLAYER,
180:     hp: maxHp,
181:     maxHp,
182:     speed,
183:     baseSpeed: speed,
184:   }, bossPassiveUnlocks), bossPassiveUnlocks)
185: }
186: 
187: // WEAPON_CATALOG가 무기 base 스탯의 단일 진실이다. starter 무기는 startsActive:true로 시작,
188: // 나머지는 unlock 카드가 fire될 때 비로소 weapons[key].active = true로 활성화.
189: // might passive multiplier는 모든 무기에 동일 적용.
190: function buildInitialWeapons(levels, { applyPermanent = true, bossPassiveUnlocks = {} } = {}) {
191:   const mightMult = 1 + (0.04 / 3) * (levels.might ?? 0)
192:   const out = {}
193:   for (const [key, entry] of Object.entries(WEAPON_CATALOG)) {
194:     const permanentBase = applyPermanent ? applyWeaponPermanentUpgradesToBaseWeapon(key, entry.base) : entry.base
195:     const passiveBase = applyBossPassiveDamageToBaseWeapon(key, permanentBase, bossPassiveUnlocks)
196:     const baseDamage = passiveBase?.damage ?? 0
197:     out[key] = {
198:       ...passiveBase,
199:       label: entry.label,
200:       level: entry.startsActive ? 1 : 0,
201:       active: !!entry.startsActive,
202:       // 소수 1자리 반올림을 걷어냈다(2026-08-15). 저데미지 무기에서 양자화 오차가 치명적이었다:
203:       // studentLantern 0.15는 0.2로 올라붙어 공격력 패시브를 3레벨 다 찍어도(×1.12 → 0.168 → 0.2)
204:       // 위력이 0% 오르지 않았고, chibiko 1.25는 1.3이 돼 +12%가 +7.7%로 깎였다.
... 별도 근거 구간 ...
217: }
218: 
219: function buildGrowthMultiplier(levels) {
220:   return 1 + (0.05 / 3) * (levels.growth ?? 0)
221: }
222: 
223: function applyMagnetPassive(levels) {
224:   const lvl = levels.magnet ?? 0
225:   setMagnetMultiplier(lvl === 0 ? 0 : 1 + (0.08 / 3) * lvl)
226: }
227: 
228: const GOLD_STORAGE_KEY = 'school_survivor:goldTotal'
229: 
230: export const SURVIVAL_MILESTONES = [
231:   { atMs: 48_000, gold: 1, label: '초반 생존 보너스' },
232:   { atMs: 144_000, gold: 3, label: '중반 돌파 보너스' },
233:   { atMs: 192_000, gold: 4, label: '보스 조우 보너스' },
... 별도 근거 구간 ...
425: 
426:     // 플레이어 피해
427:     damagePlayer: (amount, { ignoreInvulnerability = false, source = null } = {}) => {
428:       const { player, phase, godMode } = get()
429:       if (phase !== 'playing') return
430:       if (godMode) {
431:         if (isProjectMaster(useAuthStore.getState().user)) return
432:         set({ godMode: false })
433:       }
434:       if (player.invulnerable && !ignoreInvulnerability) return
435:       const hp = Math.max(0, player.hp - amount)
436:       logDamageTaken(amount, hp)
437:       // 플레이어 머리 위에 빨간 데미지 숫자(실제 피해 적용 시에만 — 무적 리턴은 위에서 이미 처리됨).
438:       emitDamageNumber({
439:         x: playerPos.x,
440:         y: 1.4,
441:         z: playerPos.z,
... 별도 근거 구간 ...
462:     //    마틸다 접촉 쿨다운 500ms를 덮어 즉사가 무효화되는 버그가 있었다).
463:     //  - 데미지 숫자 연출에 Infinity 같은 값이 뜨는 것도 막는다.
464:     killPlayer: (source = null) => {
465:       const { player, phase, godMode } = get()
466:       if (phase !== 'playing') return
467:       if (godMode) {
468:         if (isProjectMaster(useAuthStore.getState().user)) return
469:         set({ godMode: false })
470:       }
471:       set({ player: { ...player, hp: 0 }, phase: 'gameover', pauseSource: null, deathCause: source })
472:       emitSfx({ id: 'playerDeath' })
473:       vibrateRuntimeFeedback([40, 60, 40])
474:       get()._onRunEnd('gameover')
475:     },
476: 
477:     endInvulnerable: () => set((s) => ({ player: { ...s.player, invulnerable: false } })),
478: 
... 별도 근거 구간 ...
959:       applyMagnetPassive(levels)
960:       set((s) => ({
961:         player: buildInitialPlayer(levels, s.bossPassiveUnlocks),
962:         weapons: buildInitialWeapons(levels, { bossPassiveUnlocks: s.bossPassiveUnlocks }),
963:         growthMultiplier: buildGrowthMultiplier(levels),
964:         passiveVersion: s.passiveVersion + 1,
965:         levelUpChoiceSerial: s.levelUpChoiceSerial + 1,
966:       }))
967:       saveRuntimeProgress()
968:       return true
969:     },
970: 
971:     reloadPersistentProgress: () => {
972:       if (!isFirebaseProgressHydrated()) return false
973:       checkpointRun(get())
974:       const levels = getAllLevels()
975:       const bossPassiveUnlocks = loadBossPassiveUnlocks()
... 별도 근거 구간 ...
978:       set((s) => ({
979:         goldTotal: loadGoldTotal(),
980:         player: buildInitialPlayer(levels, bossPassiveUnlocks),
981:         weapons: buildInitialWeapons(levels, { bossPassiveUnlocks }),
982:         bossPassiveUnlocks,
983:         growthMultiplier: buildGrowthMultiplier(levels),
984:         passiveVersion: s.passiveVersion + 1,
985:         progressSaveWarning: consumeFirebaseProgressSaveWarning(),
986:       }))
987:       get().hydrateMissionProgress()
988:       return true
989:     },
990: 
991:     checkSurvivalMilestone: (elapsedOverrideMs) => {
992:       const s = get()
993:       const elapsedMs = Number.isFinite(elapsedOverrideMs)
994:         ? elapsedOverrideMs
... 별도 근거 구간 ...
1256:             player: {
1257:               ...s.player,
1258:               maxHp: s.player.maxHp + 7 * (s.player.bossPassiveMaxHpMultiplier ?? 1),
1259:               hp: s.player.hp + 7 * (s.player.bossPassiveMaxHpMultiplier ?? 1),
1260:             },
1261:             ...finishLevelupState(s),
1262:           }))
1263:         } else {
1264:           set((s) => finishLevelupState(s))
1265:         }
1266:         recordUpgradeMissionState()
1267:         return
1268:       }
1269: 
1270:       if (!effect) { set((s) => finishLevelupState(s)); return }
1271: 
1272:       const { player, weapons } = get()
```
경험치 곡선의 시작 필요 XP는 9, 성장률은 1.12, 평탄 가산은 2다. 단계별 반올림은 아래 함수를 그대로 따른다.

[Developer/r3f_prototype/src/lib/xpCurve.js:L1 · a9f84bf8 · SHA 584cd333c03b](index.html#code-025)

```javascript
... 별도 근거 구간 ...
4: // 각자 `xpToNext = 4` / `Math.ceil(xpToNext * 1.24 + 2)` 리터럴을 들고 있어서,
5: // 한쪽만 고치면 측정 프로브가 옛 곡선으로 돌면서 "고쳐졌다"는 거짓 합격을 냈다.
6: // 실게임(useGameStore)과 측정 하네스(stageBalanceProbe)는 반드시 여기서 읽는다.
7: //
8: // ── 2026-08-08 초반 XP 스노볼 제거 ──────────────────────────────────────────
9: // 이전: start 4, growth 1.24 → 4,7,11,16,22,30,40,52
... 별도 근거 구간 ...
24: export const XP_TO_NEXT_START = 9
25: 
26: export const XP_CURVE_GROWTH = 1.12
27: export const XP_CURVE_FLAT = 2
28: 
29: export function nextXpThreshold(current) {
30:   return Math.ceil(current * XP_CURVE_GROWTH + XP_CURVE_FLAT)
31: }
```
치명타는 각 무기 확률/배수를 사용한다. 실제 피해 전달·무적·사망 처리는 store.damagePlayer가 소유한다. 공격 기대 DPS와 실제 명중 DPS는 다르다.

[Developer/r3f_prototype/src/lib/criticalHits.js:L1 · a9f84bf8 · SHA 69e698c3d70c](index.html#code-026)

```javascript
... 별도 근거 구간 ...
7:   const damage = Number(value)
8:   return Number.isFinite(damage) && damage > 0 ? damage : 0
9: }
10: 
11: function sanitizeChance(value) {
12:   const chance = Number(value)
13:   if (!Number.isFinite(chance)) return DEFAULT_CRIT_CHANCE
14:   return Math.min(1, Math.max(0, chance))
15: }
16: 
17: function fixedCriticalMultiplier() {
18:   // Terry rule: every critical hit deals exactly 150% of original damage.
19:   // Weapon/card-provided critMultiplier values are intentionally ignored at hit resolution.
20:   return DEFAULT_CRIT_MULTIPLIER
21: }
22: 
23: export function canDamageCrit({ canCrit = true, damageType, attackTags } = {}) {
24:   return canDamageCritRaw(canCrit, damageType, attackTags)
25: }
26: 
27: export function canDamageCritRaw(canCrit = true, damageType, attackTags) {
28:   if (canCrit === false) return false
29:   if (NON_CRIT_DAMAGE_TYPES.has(damageType)) return false
30:   if (Array.isArray(attackTags) && attackTags.includes('explosive')) return false
31:   return true
32: }
33: 
34: export function resolveCriticalHit({
35:   baseDamage,
36:   canCrit = true,
37:   damageType,
38:   attackTags,
39:   critChance = DEFAULT_CRIT_CHANCE,
... 별도 근거 구간 ...
43:   const out = { damage: 0, isCritical: false }
44:   return resolveCriticalHitInto(out, baseDamage, canCrit, damageType, attackTags, critChance, critMultiplier, rng)
45: }
46: 
47: // Hot path API: caller-owned `out`를 갱신해 결과 객체를 만들지 않는다.
48: export function resolveCriticalHitInto(out, baseDamage, canCrit = true, damageType, attackTags,
49:   critChance = DEFAULT_CRIT_CHANCE, critMultiplier = DEFAULT_CRIT_MULTIPLIER, rng = Math.random) {
50:   if (!out || typeof out !== 'object') return null
51:   const damage = sanitizeDamage(baseDamage)
52:   out.damage = 0
53:   out.isCritical = false
54:   if (damage <= 0) return out
55:   if (!canDamageCritRaw(canCrit, damageType, attackTags)) { out.damage = damage; return out }
56: 
57:   const chance = sanitizeChance(critChance)
58:   if (chance <= 0) { out.damage = damage; return out }
59: 
60:   const roll = typeof rng === 'function' ? Number(rng()) : 1
61:   if (!Number.isFinite(roll) || roll < 0 || roll >= chance) { out.damage = damage; return out }
62: 
63:   out.damage = damage * fixedCriticalMultiplier()
64:   out.isCritical = true
65:   return out
66: }
```
## 무기 전체 기본값·해금·성장 경로

[Developer/r3f_prototype/src/lib/weaponCatalog.js:L15 · a9f84bf8 · SHA 5d6cf9e86b37](index.html#code-023)

| ID / 이름 | 기본 스탯(최종 export) | 계정 해금 조건 | 등장 최소 레벨 |
|---|---|---|---|
| pencilThrow / 연필 | {"damage":2.4,"cooldown":550,"lastFired":0,"projectileCount":1,"pierce":1,"speed":12,"range":2.25,"critChance":0.08,"critMultiplier":1.5} | starter | 1 |
| schoolBag / 30cm 자 | {"damage":12,"cooldown":1300,"range":0.633,"triggerRange":1,"swingMs":260,"critChance":0.2,"critMultiplier":1.5} | starter | 2 |
| boxCutter / 커터칼 | {"damage":7.2,"cooldown":1625,"range":1.4,"width":0.18,"knockback":1.8,"critChance":0.33,"critMultiplier":1.5} | starter | 2 |
| tumbler / 텀블러 | {"damage":6,"radius":1,"hitsPerSecond":2.5,"orbitSpeed":2.8,"count":1,"critChance":0.04,"critMultiplier":1.5,"sustainedDamageMultiplier":0.8} | starter | 2 |
| scienceFlask / 과학 플라스크 | {"damage":7.5,"cooldown":8400,"radius":1.6,"range":2,"zoneRadius":1.4,"zoneDurationMs":5000,"critChance":0.03,"critMultiplier":1.5,"zoneTickDamage":1.5} | [{"type":"totalRuns","value":2}] | 4 |
| bell / 벨 | {"damage":10,"cooldown":3200,"lastFired":0,"directions":8,"speed":10,"radius":1.7,"critChance":0.05,"critMultiplier":1.5} | [{"type":"stage1Clears","value":1}] | 4 |
| stunGun / 전기 | {"damage":18,"cooldown":3000,"lastFired":0,"chainCount":2,"critChance":0.06,"critMultiplier":1.5} | [{"type":"stage2Clears","value":1}] | 6 |
| onigiri / 오니기리 | {"damage":52.5,"cooldown":5000,"bounces":6,"bounceRange":4.5,"range":18,"critChance":0.08,"critMultiplier":1.5} | [{"type":"totalKills","value":700}] | 6 |
| chibiko / 치비코 | {"damage":1.25,"cooldown":1100,"lastFired":0,"range":22,"speed":12,"followDistance":0.72,"sideOffset":-0.28,"critChance":0.05,"critMultiplier":1.5,"singleTargetProjectiles":true} | [{"type":"totalRuns","value":3}] | 8 |
| hanako / 하나코 | {"healIntervalMs":20000,"healPercent":0.05,"followDistance":1.44} | 해당 없음(null) | 별도 조합 조건 |
| inucon / 이누콘 | {"damage":0,"healIntervalMs":2000,"healPercent":0.02,"followDistance":1.08,"pushRadius":0.85,"knockback":2.8,"knockbackMs":180,"contactPulseIntervalMs":250} | [{"type":"bossKills","value":3}] | 8 |
| guidedMissile / 보조배터리 미사일 | {"damage":8,"cooldown":6000,"lastFired":0,"range":7.34,"radius":1.6} | [{"type":"bossKills","value":1}] | 4 |
| sharkMissile / 상어미사일 | {"damage":20.8,"cooldown":4200,"lastFired":0,"range":28,"radius":1.8,"speed":8.5,"retargetIntervalMs":300} | [{"type":"stage2Clears","value":1}] | 8 |
| starlink / 고장난 스타링크 | {"damage":28,"cooldown":6500,"lastFired":0,"strikeCenter":5,"strikeRadius":1.2,"strikeCount":1,"strikeSpacingMs":450,"critChance":0.07,"critMultiplier":1.5} | [{"type":"totalKills","value":2500}] | 8 |
| compassBlade / 오리요강 | {"damage":5,"radius":1.15,"hitsPerSecond":2,"count":1,"orbitSpeed":3.4,"critChance":0.05,"critMultiplier":1.5} | [{"type":"totalKills","value":200}] | 3 |
| umbrellaGuard / 우산 방어막 | {"damage":12,"cooldown":3600,"radius":1.25,"spinDurationMs":1200,"knockback":3,"knockbackMs":220} | [{"type":"totalSurvivalSeconds","value":300}] | 3 |
| eraserBomb / 지우개 폭탄 | {"damage":26,"cooldown":6000,"lastFired":0,"radius":1.35,"range":12} | [{"type":"totalGold","value":160}] | 4 |
| studentLantern / 학생용 랜턴 | {"damage":0.075,"cooldown":8000,"lastFired":0,"durationMs":3000,"hitIntervalMs":150,"lightLength":2.08,"lightWidth":3.6,"lightBaseWidth":0.35,"healPercentOnHit":0.0008,"critChance":0.03,"critMultiplier":1.5} | [{"type":"stage3Clears","value":1}] | 5 |
| bikittyCutter / 바이키티 커터칼 | {"damage":5.4,"cooldown":1200,"range":1,"width":0.18,"knockback":1.8,"critChance":0.35,"critMultiplier":1.5,"segments":8,"segmentRangeStep":0.18,"segmentDamageStep":0.12,"snapDamage":9,"snapArcDeg":90,"snapRange":3.2,"reloadMs":1200} | 해당 없음(null) | 6 |
| lineDraw / 선긋기 | {"damage":20,"cooldown":4200,"range":6,"width":0.22,"pierce":999,"knockback":0,"critChance":0.35,"critMultiplier":1.5,"lineDurationMs":2000,"lineCrossDamage":14,"lineCrossCooldownMs":600} | 해당 없음(null) | 8 |

starter는 기본 계정 무기이고, 하나코/바이키티 커터칼/선긋기는 런 중 조합 조건이다. 이 세 무기를 영구 계정 해금으로 기록하지 않는다. 위력/쿨다운/범위 성장 및 카드의 실제 가산·곱셈은 업그레이드 효과 코드가 정한다.

[Developer/r3f_prototype/src/lib/upgrades.js:L1 · a9f84bf8 · SHA 14a10df2f9fc](index.html#code-024)

```javascript
... 별도 근거 구간 ...
1: // 모든 레벨업 카드의 기계적 효과를 한 곳에서 관리한다.
2: // useGameStore.applyUpgrade 와 HUD.pickThree 가 함께 참조하므로
3: // 카드 추가/수정 시 이 파일만 고치면 양쪽이 동기화된다.
4: 
5: import { isUnlocked as isWeaponUnlocked } from './weaponUnlocks.js'
6: 
7: export const CHIBIKO_BASE_ALL_WEAPON_BOOST = 0.1
... 별도 근거 구간 ...
23: // 연속형 전투 능력만 강화한다. 마커로 같은 무기에 중복 적용되는 것도 막는다.
24: export function applyChibikoAllWeaponBoost(weapon, boost = CHIBIKO_BASE_ALL_WEAPON_BOOST) {
25:   if (!weapon || typeof weapon !== 'object' || weapon.chibikoBoostApplied) return weapon
26:   const safeBoost = Math.max(0, Number.isFinite(boost) ? boost : CHIBIKO_BASE_ALL_WEAPON_BOOST)
27:   const out = { ...weapon, chibikoBoostApplied: true, chibikoBoostPercent: safeBoost }
28:   for (const stat of CHIBIKO_INCREASE_STATS) {
29:     if (typeof out[stat] === 'number') out[stat] = scaleChibikoStat(out[stat], 1 + safeBoost)
... 별도 근거 구간 ...
36: 
37: export function removeChibikoAllWeaponBoost(weapon) {
38:   if (!weapon?.chibikoBoostApplied) return weapon
39:   const boost = weapon.chibikoBoostPercent ?? CHIBIKO_BASE_ALL_WEAPON_BOOST
40:   const out = { ...weapon }
41:   delete out.chibikoBoostApplied
42:   delete out.chibikoBoostPercent
... 별도 근거 구간 ...
51: 
52: export function applyUpgradeWithChibikoBoost(weapon, effect, boost) {
53:   if (!weapon?.chibikoBoostApplied) return applyUpgradeToWeapon(weapon, effect)
54:   // 피해 비율 카드는 치비코가 적용된 현재 피해를 기준으로 강화해야 한다.
55:   if (Number.isFinite(effect.damageMultiplier)) return applyUpgradeToWeapon(weapon, effect)
56:   return applyChibikoAllWeaponBoost(
57:     applyUpgradeToWeapon(removeChibikoAllWeaponBoost(weapon), effect),
58:     boost ?? weapon.chibikoBoostPercent,
59:   )
60: }
61: 
62: // ── 레벨 곡선 정본(2026-08-15) ────────────────────────────────────────────────
... 별도 근거 구간 ...
72: export const UPGRADE_EFFECTS = {
73:   pencilDamage:   { weapon: 'pencilThrow',   kind: 'damage', dmg: 1.2 },
74:   pencilPower:    { weapon: 'pencilThrow',   kind: 'damage', dmg: 1.2 },
75:   pencilCount:    { weapon: 'pencilThrow',   kind: 'stat',   stat: 'projectileCount', step: 1,    cap: 4 },
76:   pencilPierce:   { weapon: 'pencilThrow',   kind: 'stat',   stat: 'pierce',          step: 1,    cap: 3 },
77:   pencilCrit:     { weapon: 'pencilThrow',   kind: 'crit',   chanceStep: 0.02, chanceCap: 0.24 },
78:   acquireBag:      { weapon: 'schoolBag',     kind: 'acquire', minLevel: 2 },
... 별도 근거 구간 ...
90:   // 단일 대상 기준 완전 무증가였다 — 19종 중 유일하게 "Lv1 → Lv2 +0%"인 무기였다.
91:   tumblerDamage:  { weapon: 'tumbler',       kind: 'damage', dmg: 2.7 },
92:   tumblerPower:   { weapon: 'tumbler',       kind: 'damage', dmg: 2.7 },
93:   tumblerCount:   { weapon: 'tumbler',       kind: 'stat',   stat: 'count',           step: 1,    cap: 3 },
94:   tumblerCrit:    { weapon: 'tumbler',       kind: 'crit',   chanceStep: 0.02, chanceCap: 0.2 },
95:   acquireFlask:    { weapon: 'scienceFlask',  kind: 'acquire', minLevel: 4 },
96:   // 리워크(2026-07-04): 착탄 데미지 능력 절반(dmg 8→4). 모든 플라스크 레벨업은
... 별도 근거 구간 ...
150:   chibikoCrit:          { weapon: 'chibiko',       kind: 'crit',   chanceStep: 0.02, chanceCap: 0.21 },
151:   acquireHanako:        { weapon: 'hanako',        kind: 'acquire', requiresActiveWeapon: 'chibiko', skipAccountUnlock: true },
152:   acquireInucon:        { weapon: 'inucon',        kind: 'acquire', minLevel: 8 },
153:   inuconHeal:           { weapon: 'inucon',        kind: 'stat',   stat: 'healPercent', step: 0.004, cap: 0.036 },
154:   inuconPushRadius:     { weapon: 'inucon',        kind: 'stat',   stat: 'pushRadius',  step: 0.1,  cap: 1.25 },
155:   inuconKnockback:      { weapon: 'inucon',        kind: 'stat',   stat: 'knockback',   step: 0.4,  cap: 4.4, bonus: { stat: 'knockbackMs', step: 20 } },
156:   // 바이키티 커터칼 — 커터칼을 런 중 보유해야만 카드가 뜬다(하나코/치비코와 같은 배선).
157:   // 계정 해금 게이트(weaponUnlocks)는 쓰지 않으므로 skipAccountUnlock: true.
158:   acquireBikittyCutter: { weapon: 'bikittyCutter', kind: 'acquire', minLevel: 6, requiresActiveWeapon: 'boxCutter', skipAccountUnlock: true },
159:   // 사용자 확정: 각 피해 카드가 현재 피해의 15%를 적용한다.
160:   bikittyCutterDamage: { weapon: 'bikittyCutter', kind: 'damage', damageMultiplier: 1.15 },
161:   bikittyCutterPower:  { weapon: 'bikittyCutter', kind: 'damage', damageMultiplier: 1.15 },
162:   bikittyCutterRange:  { weapon: 'bikittyCutter', kind: 'stat',   stat: 'segmentRangeStep', step: 0.02, cap: 0.28 },
163:   bikittyCutterCrit:   { weapon: 'bikittyCutter', kind: 'crit',   chanceStep: 0.02, chanceCap: 0.50 },
164:   // 선긋기 — 30cm 자 + 커터칼을 런 중 둘 다 보유해야만 카드가 뜬다. 단수형으로는 표현할 수
165:   // 없어 requiresActiveWeapons(복수형 배열)를 여기서 처음 쓴다. 계정 해금 게이트는 우회한다.
166:   acquireLineDraw:   { weapon: 'lineDraw', kind: 'acquire', minLevel: 8, requiresActiveWeapons: ['schoolBag', 'boxCutter'], skipAccountUnlock: true },
167:   // 선긋기 DPS의 41%는 잔류 절단선(lineCrossDamage 14)이라 직격 피해만 올리면 성장이 막힌다.
168:   // 데미지 카드가 절단선 피해도 함께 올리도록 bonus를 붙였다(플라스크 존 지속 +1초와 같은 배선).
169:   lineDrawDamage:    { weapon: 'lineDraw', kind: 'damage', dmg: 6.4, bonus: { stat: 'lineCrossDamage', step: 4.5 } },
170:   lineDrawPower:     { weapon: 'lineDraw', kind: 'damage', dmg: 6.4, bonus: { stat: 'lineCrossDamage', step: 4.5 } },
171:   lineDrawDuration:  { weapon: 'lineDraw', kind: 'stat',   stat: 'lineDurationMs', step: 400, cap: 4000 },
... 별도 근거 구간 ...
197: // 선택되어 active가 된 카드는 ledger에 남으므로 다음 화면이 아직 미노출인 획득 카드를 건너뛰지 않는다.
198: export function selectSequentialLevelupChoices({
199:   orderedKeys,
200:   availableKeys,
201:   pendingGuaranteedKeys = [],
202:   exposedAcquireKeys = [],
203:   weaponCycleIds = [],
... 별도 근거 구간 ...
322: 
323: export function applyUpgradeToWeapon(wpn, effect) {
324:   if (effect.kind === 'acquire') return { ...wpn, active: true, level: 1 }
325:   // bonus: 주 효과와 별개로 함께 오르는 부가 스탯 (예: 플라스크 존 지속시간 +1s/레벨)
326:   const withBonus = (w) => effect.bonus
327:     ? { ...w, [effect.bonus.stat]: (w[effect.bonus.stat] ?? 0) + effect.bonus.step }
328:     : w
... 별도 근거 구간 ...
342: 
343: export function isUpgradeAvailable(effect, level, weapons, player = null) {
344:   if (!effect) return true
345:   if (effect.kind === 'player') {
346:     if (effect.stat === 'speed' && player?.baseSpeed) {
347:       return player.speed < player.baseSpeed * effect.capMultiplier
348:     }
... 별도 근거 구간 ...
353:     if (wpn?.active) return false
354:     if (effect.requiresActiveWeapon && !weapons[effect.requiresActiveWeapon]?.active) return false
355:     // 복수형: 나열된 무기를 런 중 "전부" 보유해야 한다. 단수형 requiresActiveWeapon과 독립이며
356:     // 둘 다 있으면 둘 다 만족해야 한다. 선긋기(자 + 커터칼)가 첫 사용처다.
357:     if (effect.requiresActiveWeapons
358:       && !effect.requiresActiveWeapons.every((id) => weapons[id]?.active)) return false
359:     // 계정 해금 게이트: starter는 isWeaponUnlocked가 항상 true, 그 외는 weaponUnlocks 디스크 상태.
360:     // 계정 해금과 최소 레벨을 만족한 획득 카드는 full-cap에서도 교체 후보로 표시한다.
361:     // 실제 활성 무기 수는 교체 확정 시 기존 무기 하나를 제거해 MAX_OWNED_WEAPONS로 유지한다.
362:     const accountUnlockedAcquire = effect.skipAccountUnlock || isWeaponUnlocked(effect.weapon)
363:     if (!accountUnlockedAcquire) return false
```
## 처치 드롭·수집

적 xp 필드는 실제 드롭 성공률과 분리해서 읽어야 한다. 확장 일반 적은 textbookChance와 xpPerTextbook을 별도로 가지고, 확장 보스는 textbookXp/textbooks/gold가 있다. 기존 적의 드롭은 실제 처치 처리 아래 조건을 따른다.

[Developer/r3f_prototype/src/components/Enemies.jsx:L1 · a9f84bf8 · SHA 360fd766e324](index.html#code-005)

```javascript
... 별도 근거 구간 ...
83: // 보스/엘리트 사망 시 추가 보너스 (기획서 §3-3)
84: export const ELITE_BONUS = {
85:   ...Object.fromEntries(Object.values(EXPANSION_BOSSES).map(b => [b.id, {textbook:b.textbooks,textbookXp:b.textbookXp,gold:b.gold}])),
86:   E06: { textbook: 1, gold: 1 },
87:   // E08 코인 몬스터는 일반 확률 드롭 대신 코인 10개를 확정 산포한다.
88:   E08: { textbook: 0, gold: 10 },
89:   B01: { textbook: 3, textbookXp: 40, gold: 5 },
90:   B02: { textbook: 3, textbookXp: 40, gold: 5 },
91:   B03: { textbook: 3, textbookXp: 40, gold: 5 },
92:   // B04는 최종 보스인데도 이 표에서 빠져 있어 처치 보상이 0이었다.
93:   // 정본: Planner/permanent_upgrade_expansion_design_2026-07-26.md §5-1 — B01~B03과 동일 수치.
94:   B04: { textbook: 3, textbookXp: 40, gold: 5 },
95: }
96: 
97: export function getEliteBonusTextbookXp(type, fallbackXp) {
98:   const bonus = ELITE_BONUS[type]
99:   if (!bonus) return fallbackXp
100:   return bonus.textbookXp ?? fallbackXp
101: }
102: 
103: export function shouldDropTextbook(dropData, roll = Math.random(), elapsedSec = Infinity) {
104:   return (dropData?.xp ?? 0) > 0 && roll < (EXPANSION_ENEMIES[dropData?.type]?.textbookChance ?? getTextbookDropRate(elapsedSec))
105: }
106: 
107: export function createDeathCollapseEntry(id, dropData) {
108:   return {
109:     id,
110:     type: dropData.type,
... 별도 근거 구간 ...
1455:         const bonus = ELITE_BONUS[type]
1456:         if (bonus) {
1457:           const textbookXp = getEliteBonusTextbookXp(type, dropData.xp)
1458:           for (let rewardIndex = 0; rewardIndex < bonus.textbook; rewardIndex += 1) pushBounded(queue.textbooks, { id: ++_textbookId, pos, value: textbookXp })
1459:           for (let rewardIndex = 0; rewardIndex < bonus.gold; rewardIndex += 1) pushBounded(queue.gold, { id: ++_coinId, pos, value: 1 })
1460:         } else if (shouldDropTextbook(dropData, Math.random(), dropElapsedSec)) pushBounded(queue.textbooks, { id: ++_textbookId, pos, value: dropData.xp })
1461:         queue.deathRead = (slot + 1) % MAX_RUNTIME_QUEUE
1462:         queue.deathCount -= 1
1463:       }
1464:       if (queue.specialRemovals.length) {
1465:         const removed = new Set(queue.specialRemovals.splice(0, queue.specialRemovals.length))
... 별도 근거 구간 ...
1580:   }, [])
1581: 
1582:   const enqueueTextbook = useCallback((pos, value) => {
1583:     pushBounded(runtimeQueueRef.current.textbooks, { id: ++_textbookId, pos, value })
1584:     scheduleRuntimeFlush()
1585:   }, [scheduleRuntimeFlush])
1586: 
1587:   const enqueueGoldCoin = useCallback((pos, value = 1) => {
1588:     pushBounded(runtimeQueueRef.current.gold, { id: ++_coinId, pos, value })
... 별도 근거 구간 ...
1660: 
1661:   const dropTextbook = useCallback((pos, value) => {
1662:     enqueueTextbook(pos, value)
1663:   }, [enqueueTextbook])
1664: 
1665:   const dropGoldCoin = useCallback((pos, value = 1) => {
1666:     enqueueGoldCoin(pos, value)
1667:   }, [enqueueGoldCoin])
1668: 
1669:   // ── 춤추는 도지 이벤트 ─────────────────────────────────────────────────────
... 별도 근거 구간 ...
1887:     const bonus = ELITE_BONUS[dropData.type]
1888:     if (bonus) {
1889:       const textbookXp = getEliteBonusTextbookXp(dropData.type, dropData.xp)
1890:       for (let i = 0; i < bonus.textbook; i++) dropTextbook(dropData.pos, textbookXp)
1891:       for (let i = 0; i < bonus.gold; i++)     dropGoldCoin(dropData.pos)
1892:       return
1893:     }
1894: 
1895:     if (shouldDropTextbook(dropData)) {
1896:       dropTextbook(dropData.pos, dropData.xp)
```
[Developer/r3f_prototype/src/components/Enemy.jsx:L1 · a9f84bf8 · SHA 26c11bca50a8](index.html#code-006)

```javascript

```
## 저밀도 보충·생성 제한·시간

일반 스폰 시계와 실제 게임 경과 시계는 다르다. 기존 스테이지 화면 내 적이 3 이하이고 대기 생성이 없으면 다음 일반 이벤트로 스폰 시계를 당길 수 있다. 보스는 실제 게임 시계를 써서 당겨지지 않는다. 확장 스테이지의 spawnClock은 gameplayElapsedSec다. 포탈·HUD·마틸다의 실제 경과 시간과 일반 burst 표의 초를 혼동하지 않는다.

[Developer/r3f_prototype/src/lib/spawnCatchUp.js:L1 · a9f84bf8 · SHA 6dee2538c593](index.html#code-011) · [Developer/r3f_prototype/src/components/Enemies.jsx:L2060 · a9f84bf8 · SHA 360fd766e324](index.html#code-005)

저밀도 보충은 10 active seconds 동안 3 이하라는 판정과 E07×10+E01×10의 편성, 전역 150 상한·대기 포함 계산을 사용한다. 정확한 타이머 reset/정지 조건과 모든 Stage 1~10에서 적용되는 호출 경로는 아래 원문 그대로다. 화면 가시 수가 아니라 전역 생존 수를 쓴다. 다른 생성 큐는 이 타이머를 중단시키지 않으며 20개 슬롯이 확보될 때까지 준비된 상태를 유지한다.

[Developer/r3f_prototype/src/lib/lowDensityReinforcement.js:L1 · a9f84bf8 · SHA b7624688c4e4](index.html#code-010)

```javascript
... 별도 근거 구간 ...
1: // 화면/HP/처치속도와 무관한 실제 생존 좀비 저밀도 타이머.
2: export const LOW_DENSITY_REINFORCEMENT_ALIVE_THRESHOLD = 3
3: export const LOW_DENSITY_REINFORCEMENT_STREAK_SEC = 10
4: export const LOW_DENSITY_REINFORCEMENT_ENTRIES = Object.freeze([
5:   Object.freeze({ type: 'E07', count: 10 }),
6:   Object.freeze({ type: 'E01', count: 10 }),
7: ])
8: const NO_SPAWN = Object.freeze({ shouldSpawn: false, entries: Object.freeze([]) })
... 별도 근거 구간 ...
10: export function createLowDensityReinforcementState() {
11:   return { lowForSec: 0, pending: false, stageId: undefined, gameKey: undefined }
12: }
... 별도 근거 구간 ...
14: export function resetLowDensityReinforcementState(state) {
15:   if (!state) return state
16:   state.lowForSec = 0
17:   state.pending = false
18:   state.stageId = undefined
19:   state.gameKey = undefined
20:   return state
21: }
... 별도 근거 구간 ...
23: // 소비 후에만 자체 예약 잠금을 해제한다. 다른 시스템의 큐는 타이머를 막지 않는다.
24: export function finishLowDensityReinforcement(state) {
25:   if (!state) return
26:   state.pending = false
27:   state.lowForSec = 0
28: }
... 별도 근거 구간 ...
30: export function advanceLowDensityReinforcement(state, options = {}) {
31:   if (!state) return NO_SPAWN
32:   const { phase = 'playing', stageId, gameKey, deltaSec = 0, aliveEnemyCount = 0,
33:     queuedEnemyCount = 0, availableSpawnSlots = 20 } = options
34:   if (state.stageId !== stageId || state.gameKey !== gameKey) {
35:     resetLowDensityReinforcementState(state)
36:     state.stageId = stageId
37:     state.gameKey = gameKey
38:   }
39:   if (phase !== 'playing') return NO_SPAWN
40:   if (!Number.isFinite(aliveEnemyCount) || aliveEnemyCount < 0
41:     || aliveEnemyCount > LOW_DENSITY_REINFORCEMENT_ALIVE_THRESHOLD) {
42:     state.lowForSec = 0
43:     return NO_SPAWN
44:   }
45:   if (state.pending || !Number.isFinite(deltaSec) || deltaSec <= 0) return NO_SPAWN
46:   state.lowForSec = Math.min(LOW_DENSITY_REINFORCEMENT_STREAK_SEC, state.lowForSec + deltaSec)
47:   // 600 fixed steps can land a few ulps below ten seconds; not a gameplay grace window.
48:   if (state.lowForSec + 1e-9 < LOW_DENSITY_REINFORCEMENT_STREAK_SEC) return NO_SPAWN
49:   // 다른 예약은 생존 수가 아니며 슬롯 예약량은 caller가 계산한다.
50:   // 자체 pending 잠금만 중복을 막고, 20슬롯 미만이면 준비된 타이머를 보존한다.
51:   if (!Number.isFinite(availableSpawnSlots) || Math.floor(availableSpawnSlots) < 20) return NO_SPAWN
52:   const entries = LOW_DENSITY_REINFORCEMENT_ENTRIES.map((entry) => ({ ...entry }))
53:   state.pending = true
54:   state.lowForSec = 0
55:   return { shouldSpawn: true, entries }
56: }
```
[Developer/r3f_prototype/src/components/Enemies.jsx:L1 · a9f84bf8 · SHA 360fd766e324](index.html#code-005)

```javascript
... 별도 근거 구간 ...
47: import { recordZombieEncounter } from '../lib/zombieEncyclopedia.js'
48: import { BOSS_TELEGRAPH_LEAD_SEC, LOW_DENSITY_ENEMY_THRESHOLD, advanceSpawnCatchUp, createSpawnCatchUpState, publishSpawnCatchUpOffsetSec, resetSpawnCatchUpState } from '../lib/spawnCatchUp.js'
49: import { LOW_DENSITY_REINFORCEMENT_ENTRIES, advanceLowDensityReinforcement, createLowDensityReinforcementState, finishLowDensityReinforcement, resetLowDensityReinforcementState } from '../lib/lowDensityReinforcement.js'
50: import { createDominanceSwarmSpawnPlan, createDominanceSwarmState, evaluateDominanceSwarm, recordDominanceSwarmSpawn, recordEmptyField, recordEnemyKill, recordPlayerDamage, resetDominanceSwarmState } from '../lib/dominanceSwarmRespawn.js'
51: 
52: // 황금 코인 시계 드랍: 4분에 약 10개 → 20–28s 무작위 간격 (5분 기준 ×0.8)
53: const GOLD_INTERVAL_MIN_MS = 20_000
54: const GOLD_INTERVAL_MAX_MS = 28_000
55: const GOLD_VISIBLE_RADIUS = 10  // 플레이어 기준 이 거리 내 적에서 드랍 시도
... 별도 근거 구간 ...
1143: const SCHEDULE_DOMINANCE_SWARM = 8
1144: const SCHEDULE_LOW_DENSITY_REINFORCEMENT = 9
1145: 
1146: export function isPooledEnemyType(type) {
1147:   const code = enemyTypeToCode(type)
1148:   // Boss meshes (including the current stage2-boss-v2 B02) are rendered by
1149:   // Enemy/ZombieMesh. ZombieInstanceLayer intentionally has no boss body mesh.
1150:   return (code >= 1 && code <= STANDARD_POOL_TYPE_MAX || isExpansionEnemy(type)) && !isBossType(type)
... 별도 근거 구간 ...
1166:     const kind = queue.scheduleKind[(queue.scheduleRead + offset) % capacity]
1167:     if (kind === SCHEDULE_BURST || kind === SCHEDULE_OVERTIME || kind === SCHEDULE_MATILDA || kind === SCHEDULE_DOGE || kind === SCHEDULE_DOMINANCE_SWARM || kind === SCHEDULE_LOW_DENSITY_REINFORCEMENT) count += 1
1168:   }
1169:   return count
1170: }
1171: 
1172: // 스폰 시계(spawnSec) 기준으로 "아직 안 터진 다음 스폰"이 언제인지 — 캐치업 점프 폭의 단일 소스.
1173: // 후보는 런타임에 실제로 발화하는 세 경로뿐이다: 단발 버스트 · 반복 버스트 · 오버타임 보강.
... 별도 근거 구간 ...
1255:   const wanted = Math.min(20, Math.max(0, Math.floor(count) || 0))
1256:   for (const entry of LOW_DENSITY_REINFORCEMENT_ENTRIES) {
1257:     for (let index = 0; index < entry.count && batch.length < wanted; index += 1) {
1258:       const type = entry.type
1259:       // 기존 링/장애물 검사를 먼저 사용. 링 밀집으로 실패해도 안전한 기존 formation 탐색으로 보충한다.
1260:       const pos = spawnPosForBurstType(type, cache.bounds, taken, random, cache.obstacles)
1261:         ?? findNearestFreeFormationPosition(
1262:           [playerPos.x + SPAWN_MIN_RADIUS, BASE_COL_Y * ENEMY_STATS[type].scale * ENEMY_SIZE_MULTIPLIER, playerPos.z],
... 별도 근거 구간 ...
1688:       spawnDoge()
1689:     } else if (kind === SCHEDULE_LOW_DENSITY_REINFORCEMENT) {
1690:       const count = clampZombieSpawnRequest(20, totalZombieCounts())
1691:       const batch = buildLowDensityReinforcementBatch(cache, count)
1692:       // 20마리 전체가 들어갈 때만 내보낸다. 같은 RAF에서 재예약 루프를 만들지 않는다.
1693:       if (count < 20 || batch.length !== 20) {
1694:         queue.lowDensityDeferred = true
1695:         return
... 별도 근거 구간 ...
1936:     if (lowDensity.shouldSpawn || retryLowDensity) {
1937:       runtimeQueueRef.current.lowDensityDeferred = !enqueueScheduled(SCHEDULE_LOW_DENSITY_REINFORCEMENT)
1938:     }
1939: 
1940:     // ── 스폰 시계 캐치업 ───────────────────────────────────────────────────────────
1941:     // 화면 안 몹이 3마리 이하이고 생성 대기가 없으면 다음 일반 스폰을 즉시 당긴다.
1942:     // 남은 스케줄의 상대 간격은 유지한다. 스폰 게이트만 spawnSec을 읽고,
1943:     // HUD 타이머·탈출 포탈·마틸다·적 AI(context.elapsedSec)는 실시간 sec 그대로다.
... 별도 근거 구간 ...
1956:       // 저밀도일 때만 다음 일반 스폰 후보를 계산한다.
1957:       nextPendingSpawnSec: visibleEnemyCount <= LOW_DENSITY_ENEMY_THRESHOLD
1958:         ? nextPendingSpawnSec(
1959:             stageRuntime.burstEvents,
1960:             firedBurstsRef.current,
1961:             scheduledRepeatBurstTicksRef.current,
1962:             pendingSpawnSec,
1963:             stageRuntime.id,
```
상한은 일반 풀·특수 개체·생성 대기를 합산한 좀비 150이다. 새 적의 예고 동시 수 2, 피해 영역 동시 수 4, 확장 보스 상한 1이라는 데이터도 별개로 있다. 데이터 선언뿐 아니라 실제 소비 경로를 확인해야 한다.

[Developer/r3f_prototype/src/lib/enemyEntityPool.js:L3 · a9f84bf8 · SHA 5b731263df46](index.html#code-013) · [Developer/r3f_prototype/src/lib/expansionAttackRuntime.js:L34 · a9f84bf8 · SHA 812467d150ed](index.html#code-008)

| 확장 제한 | 값 |
|---|---|
| globalActiveAndDeferredEnemies | 150 |
| bosses | 1 |
| simultaneousNewTelegraphs | 2 |
| simultaneousDamagingAreas | 4 |

## 오버타임·우세 보충

240초 duration은 무조건 런 종료/자동 클리어를 뜻하지 않는다. 탈출하지 않으면 오버타임이 계속될 수 있다. 기존 Stage3은 240초부터, 기타 기존 스테이지와 확장은 각 startSec에서 30초 간격 증원한다. 300초 이후 90초 계단으로 수량·HP 10%씩 증가하는 적용 순서를 아래 구현으로 보존했다.

[Developer/r3f_prototype/src/components/Enemies.jsx:L1 · a9f84bf8 · SHA 360fd766e324](index.html#code-005)

```javascript
... 별도 근거 구간 ...
331: 
332: export const STAGE3_OVERTIME_REINFORCEMENT_START_SEC = 240
333: 
334: export function getOvertimeReinforcementStartSec(stageId) {
335:   if (EXPANSION_STAGES[stageId]) return EXPANSION_STAGES[stageId].overtime.startSec
336:   return OVERTIME_REINFORCEMENT_START_SEC
337: }
338: 
339: export function overtimeReinforcementTick(elapsedSec, stageId = 'stage1') {
340:   const startSec = getOvertimeReinforcementStartSec(stageId)
341:   if (!Number.isFinite(elapsedSec) || elapsedSec < startSec) return null
342:   return Math.floor((elapsedSec - startSec) / OVERTIME_REINFORCEMENT_INTERVAL_SEC)
343: }
344: 
345: export function shouldScheduleOvertimeReinforcement(lastFiredTick, elapsedSec, stageId = 'stage1') {
346:   const tick = overtimeReinforcementTick(elapsedSec, stageId)
347:   return { shouldSchedule: tick !== null && tick > lastFiredTick, tick }
348: }
349: 
350: // 오버타임 보강 계단 — 마릿수 램프와 개체 강화가 같은 계단을 밟게 하는 단일 소스.
351: // 계단 s는 OVERTIME_ESCALATION_START_SEC(300초)부터 OVERTIME_ESCALATION_SPAWNS_PER_STEP(3틱)마다
352: // 하나씩 올라간다. 보강 간격이 30초이므로 s = floor((t - 300) / 90).
353: export function overtimeEscalationSteps(tick, stageId = 'stage1') {
354:   const safeTick = Math.floor(tick)
355:   if (!Number.isFinite(safeTick)) return 0
356:   const escalationStartTick = overtimeReinforcementTick(OVERTIME_ESCALATION_START_SEC, stageId)
357:   if (escalationStartTick === null || safeTick < escalationStartTick) return 0
358:   return Math.floor((safeTick - escalationStartTick) / OVERTIME_ESCALATION_SPAWNS_PER_STEP)
359: }
360: 
361: export function overtimeReinforcementCountForTick(tick, stageId = 'stage1', baseCount = OVERTIME_REINFORCEMENT_COUNT) {
362:   const safeBase = Math.max(0, Math.floor(baseCount) || 0)
363:   if (!Number.isFinite(Math.floor(tick))) return safeBase
364:   const steps = overtimeEscalationSteps(tick, stageId)
365:   if (steps <= 0) return safeBase
366:   return Math.max(1, Math.round(safeBase * (1 + steps * OVERTIME_ESCALATION_RATE)))
367: }
368: 
369: export function overtimeHpMultiplierForTick(tick, stageId = 'stage1') {
370:   return 1 + overtimeEscalationSteps(tick, stageId) * OVERTIME_HP_ESCALATION_RATE
371: }
372: 
373: // 오버타임 경로 전용 statOverride. 스테이지 HP 사다리(stageHpOverride)를 그대로 타고 그 위에
374: // 시간 배수를 곱한다. spawnPooledEnemy가 `hp: stats.hp, maxHp: stats.hp`로 쓰므로 hp와 maxHp가
375: // 함께 올라간다(체력바가 넘치지 않는다).
376: export function overtimeHpStatOverride(type, stageId, tick) {
377:   const stageOverride = stageHpOverride(type, stageId)
378:   const base = ENEMY_STATS[type]
379:   // 보스는 오버타임 풀에 없다(STAGE1/DEFAULT_OVERTIME_MIXED_TYPES). 나중에 섞이더라도
380:   // 시간 배수를 타지 않도록 구조적으로 막는다.
381:   if (!base || isBossType(type)) return stageOverride
382:   const multiplier = overtimeHpMultiplierForTick(tick, stageId)
383:   if (!(multiplier > 1)) return stageOverride
384:   return { ...stageOverride, hp: Math.max(1, Math.round((stageOverride?.hp ?? base.hp) * multiplier)) }
385: }
386: 
387: export function overtimeMixedTypesForStage(stageId) {
388:   if (EXPANSION_STAGES[stageId]) return [...EXPANSION_STAGES[stageId].overtime.mixedTypes]
389:   return [...(stageId === 'stage1' ? STAGE1_OVERTIME_MIXED_TYPES : DEFAULT_OVERTIME_MIXED_TYPES)]
390: }
391: 
392: export function buildOvertimeMixedReinforcementEntries(stageId, random = Math.random, count = OVERTIME_REINFORCEMENT_COUNT) {
393:   const pool = overtimeMixedTypesForStage(stageId)
394:   const entries = []
395:   const wanted = Math.max(0, Math.floor(count) || 0)
396:   while (entries.length < wanted) {
397:     const type = pool[Math.floor(random() * pool.length) % pool.length]
398:     entries.push({ type })
399:   }
400:   return entries
401: }
... 별도 근거 구간 ...
1112: export const MAX_CONCURRENT_ZOMBIES = MAX_ENEMIES
1113: export const OVERTIME_REINFORCEMENT_START_SEC = 240
1114: export const OVERTIME_REINFORCEMENT_INTERVAL_SEC = 30
1115: export const OVERTIME_REINFORCEMENT_COUNT = 30
1116: export const OVERTIME_ESCALATION_START_SEC = 300
1117: export const OVERTIME_ESCALATION_SPAWNS_PER_STEP = 3
1118: export const OVERTIME_ESCALATION_RATE = 0.1
1119: // 마릿수 램프는 MAX_ENEMIES(150) 천장에서 멈춘다 — clampZombieSpawnRequest가 `150 - alive`로
1120: // 잘라내므로 요청을 아무리 키워도 필드는 150에서 포화한다. 그런데 플레이어 레벨업에는 상한이
1121: // 없어서(xpCurve 무한 기하급수) 포화 이후로는 플레이어만 계속 강해지고, "고득점 vs 탈출"의
1122: // 손익분기가 사라진다. 마릿수 대신 개체 HP를 같은 계단으로 올려 천장 위에서도 압박이 자라게 한다.
1123: //
1124: // HP만 올리고 damage/speed는 건드리지 않는다:
1125: //  - 구조: ENEMY_RUNTIME_DAMAGE/SPEED는 타입 인덱스 lookup(enemySimulation.js)이고 풀에는
1126: //    개체별 damage/speed 칼럼이 없다. hp/maxHp만이 개체별로 저장되는 스탯이다.
1127: //  - 설계: 접촉 피해는 개체마다 ENEMY_CONTACT_COOLDOWN_MS(500ms) 쿨다운을 따로 갖는다.
... 별도 근거 구간 ...
1131: //    저울질 자체가 사라지고, speed를 올리면 카이팅이 불가능해져 곡선이 아니라 벽이 된다.
1132: export const OVERTIME_HP_ESCALATION_RATE = 0.1
1133: const STAGE1_OVERTIME_MIXED_TYPES = Object.freeze(['E01', 'E02', 'E03', 'E05', 'E06', 'E07'])
1134: const DEFAULT_OVERTIME_MIXED_TYPES = Object.freeze(['E01', 'E02', 'E03', 'E04', 'E05', 'E06', 'E07'])
1135: const MAX_SPECIAL_ENEMIES = 3
1136: const MAX_RUNTIME_QUEUE = 256
1137: const EMPTY_IMPACT = Object.freeze({})
1138: const SCHEDULE_GOLD = 1
1139: const SCHEDULE_DOGE = 2
1140: const SCHEDULE_BURST = 5
1141: const SCHEDULE_MATILDA = 6
1142: const SCHEDULE_OVERTIME = 7
1143: const SCHEDULE_DOMINANCE_SWARM = 8
```
[Developer/r3f_prototype/src/lib/dominanceSwarmRespawn.js:L1 · a9f84bf8 · SHA ab428b64dfe1](index.html#code-012)

```javascript
... 별도 근거 구간 ...
1: export const DOMINANCE_SWARM_CONFIG = Object.freeze({
2:   evaluateIntervalMs: 3000,
3:   killWindowMs: 10000,
4:   damageWindowMs: 10000,
5:   emptyFieldWindowMs: 15000,
6:   cooldownMs: 8000,
... 별도 근거 구간 ...
32: 
33: export function createDominanceSwarmState() {
34:   return {
35:     kills: [],
36:     damage: [],
37:     emptyFields: [],
38:     lastEvaluateMs: -Infinity,
... 별도 근거 구간 ...
43: 
44: export function resetDominanceSwarmState(state) {
45:   if (!state) return createDominanceSwarmState()
46:   state.kills.length = 0
47:   state.damage.length = 0
48:   state.emptyFields.length = 0
49:   state.lastEvaluateMs = -Infinity
... 별도 근거 구간 ...
54: 
55: export function recordEnemyKill(state, nowMs) {
56:   if (!state || !Number.isFinite(nowMs)) return state
57:   state.kills.push({ t: nowMs })
58:   pruneWindow(state.kills, nowMs, DOMINANCE_SWARM_CONFIG.killWindowMs)
59:   return state
60: }
61: 
62: export function recordPlayerDamage(state, amount, nowMs) {
63:   if (!state || !(amount > 0) || !Number.isFinite(nowMs)) return state
64:   state.damage.push({ t: nowMs, amount })
65:   pruneWindow(state.damage, nowMs, DOMINANCE_SWARM_CONFIG.damageWindowMs)
66:   return state
67: }
68: 
69: export function recordEmptyField(state, nowMs) {
70:   if (!state || !Number.isFinite(nowMs)) return state
71:   if (nowMs - state.lastEmptyFieldMs < 1000) return state
72:   state.lastEmptyFieldMs = nowMs
73:   state.emptyFields.push({ t: nowMs })
74:   pruneWindow(state.emptyFields, nowMs, DOMINANCE_SWARM_CONFIG.emptyFieldWindowMs)
... 별도 근거 구간 ...
77: 
78: export function recordDominanceSwarmSpawn(state, nowMs) {
79:   if (!state || !Number.isFinite(nowMs)) return state
80:   state.lastSpawnMs = nowMs
81:   return state
82: }
83: 
84: export function evaluateDominanceSwarm(state, context = {}, config = DOMINANCE_SWARM_CONFIG) {
85:   const nowMs = Number.isFinite(context.nowMs) ? context.nowMs : 0
86:   if (!state) return { shouldSpawn: false, reason: 'missing-state', dominanceScore: 0, spawnCount: 0 }
87:   if (nowMs < config.minRunTimeMs) return { shouldSpawn: false, reason: 'opening-grace', dominanceScore: 0, spawnCount: 0 }
88:   if (nowMs - state.lastEvaluateMs < config.evaluateIntervalMs) return { shouldSpawn: false, reason: 'evaluate-cooldown', dominanceScore: 0, spawnCount: 0 }
89:   state.lastEvaluateMs = nowMs
... 별도 근거 구간 ...
133: 
134: export function createDominanceSwarmSpawnPlan(result, context = {}, random = Math.random) {
135:   const count = Math.max(0, Math.min(DOMINANCE_SWARM_CONFIG.maxSpawnPerBurst, Math.floor(result?.spawnCount ?? 0) || 0))
136:   const stageId = context.stageId ?? 'stage1'
137:   const pool = STAGE_WEAK_SWARM_TYPES[stageId] ?? STAGE_WEAK_SWARM_TYPES.stage1
138:   const entries = []
139:   for (let i = 0; i < count; i += 1) {
140:     const type = pool[Math.floor(random() * pool.length) % pool.length]
141:     entries.push({ type, source: 'dominance-swarm' })
142:   }
```
## 마틸다·탈출·기록·점수

마틸다는 205초 예고, 210초 등장하는 추격자다. HP는 스폰 당시 이론 DPS×1800을 바탕으로 스테이지 배율까지 적용한다. 30분은 실측 보장이 아니다. 접촉 즉사 지연 0ms이며 일반 피해 무적 우회 경로가 있다.

[Developer/r3f_prototype/src/lib/playerDpsEstimate.js:L1 · a9f84bf8 · SHA 4d1bf8bfbe04](index.html#code-017)

```javascript
... 별도 근거 구간 ...
35: // 신 지정: 30분.
36: export const MATILDA_ATTACK_SECONDS = 1800
37: 
38: // 플라스크 웅덩이 틱 주기. 정본은 components/Weapons/Flask.jsx의 ZONE_TICK_MS(1000)다.
39: const FLASK_ZONE_TICK_MS = 1000
40: 
41: function positiveNumber(value, fallback) {
42:   return Number.isFinite(value) && value > 0 ? value : fallback
43: }
44: 
45: // 기대 치명타 배율. 모든 크리티컬 피해는 원래 데미지의 150%로 고정된다.
46: export function expectedCritMultiplier(weapon) {
47:   const chance = Number.isFinite(weapon?.critChance) ? weapon.critChance : 0
... 별도 근거 구간 ...
56: //  3) 그 외 쿨다운형: 1000 / cooldown.
57: export function weaponHitsPerSecond(weapon) {
58:   if (!weapon) return 0
59:   const orbitalRate = positiveNumber(weapon.hitsPerSecond, 0)
60:   if (orbitalRate > 0) return orbitalRate
61: 
62:   const cooldownMs = positiveNumber(weapon.cooldown, 0)
63:   if (cooldownMs <= 0) return 0
64: 
65:   const durationMs = positiveNumber(weapon.durationMs, 0)
66:   const hitIntervalMs = positiveNumber(weapon.hitIntervalMs, 0)
67:   if (durationMs > 0 && hitIntervalMs > 0) {
68:     return (durationMs / hitIntervalMs) / (cooldownMs / 1000)
... 별도 근거 구간 ...
154: // 장착 무기 전체 합산 DPS. weapons는 useGameStore의 weapons 맵.
155: export function estimatePlayerDps(weapons) {
156:   if (!weapons || typeof weapons !== 'object') return 0
157:   let total = 0
158:   for (const weapon of Object.values(weapons)) {
159:     total += estimateWeaponDps(weapon)
160:   }
161:   return total
162: }
163: 
164: // 마틸다 HP = 스폰 시점 DPS × 1800초.
165: // 신 지정값을 clamp/보정하지 않는다 — 나온 값을 그대로 쓴다.
166: export function matildaHpFromWeapons(weapons) {
167:   return estimatePlayerDps(weapons) * MATILDA_ATTACK_SECONDS
168: }
```
[Developer/r3f_prototype/src/components/Enemy.jsx:L105 · a9f84bf8 · SHA 26c11bca50a8](index.html#code-006) · [Developer/r3f_prototype/src/components/Enemies.jsx:L1752 · a9f84bf8 · SHA 360fd766e324](index.html#code-005)

기본 점수는 floor(생존 초)+스테이지 보너스다. 스테이지 보너스 기본은 Stage1=0에서 한 단계당 +60, Stage10=540. 탈출 성공 때 기본 점수 15%를 내림해 추가하고, 보스도 처치한 성공 런은 (기본+탈출 보너스)의 20%를 내림해 추가한다. 보스만 죽이고 죽은 런에는 클리어/점수 보너스를 붙이지 않는다. 이것은 점수 계약이며 최신 보스 전용 영구 해금 요구와 별개다. Admin의 시즌 scorePolicy 오버라이드는 읽지 않았다.

[Developer/r3f_prototype/src/lib/rankingScorePolicy.js:L1 · a9f84bf8 · SHA c738659f1fee](index.html#code-ranking)

```javascript
... 별도 근거 구간 ...
3: export const SCORE_TYPE = 'survival_v1'
4: // 탈출구로 탈출하면 기본 점수(생존 초 + 스테이지 보너스)의 15%를 보너스로 받는다.
5: export const ESCAPE_BONUS_RATE = 0.15
6: // 보스 처치 보너스는 탈출 보너스까지 합산된 점수의 20%다(탈출 보너스와 순차 적용).
7: export const BOSS_BONUS_RATE = 0.2
8: // 스테이지 보너스는 난이도 단조증가에 맞춰 선형 +60.
9: // 런 길이에도 점수에도 상한이 없다 — 버틴 만큼 무한히 기록되는 것이 무한모드 경합의 전제다.
10: export const STAGE_BONUS = {
11:   stage1: 0,
12:   stage2: 60,
13:   stage3: 120,
14:   stage4: 180,
15:   stage5: 240,
16:   stage6: 300,
17:   stage7: 360,
18:   stage8: 420,
19:   stage9: 480,
... 별도 근거 구간 ...
37: export function getRankingBaseScore({ stageId = 'stage1', survivalSeconds = 0 } = {}, policy = getRankingScorePolicy()) {
38:   return readNonNegativeInt(survivalSeconds) + readNonNegativeInt(policy.stageBonus?.[stageId])
39: }
40: 
41: // 탈출구 탈출 보너스 = 기본 점수의 15%.
42: export function getEscapeBonus({ stageId = 'stage1', survivalSeconds = 0, cleared = false } = {}, policy = getRankingScorePolicy()) {
43:   if (cleared !== true) return 0
44:   return Math.floor(getRankingBaseScore({ stageId, survivalSeconds }, policy) * ESCAPE_BONUS_RATE)
45: }
46: 
47: export function getRankingScore({ stageId = 'stage1', survivalSeconds = 0, cleared = false, bossBonus = 0 } = {}, policy = getRankingScorePolicy()) {
48:   return getRankingBaseScore({ stageId, survivalSeconds }, policy)
49:     + getEscapeBonus({ stageId, survivalSeconds, cleared }, policy)
50:     // 보스 처치는 포탈 탈출을 대체하지 않는다. 미클리어 런에는 호출자가 보너스를 넘겨도 붙지 않는다.
51:     + (cleared ? readNonNegativeInt(bossBonus) : 0)
52: }
53: 
54: // 마지막 보스를 처치했다는 사실은 런 중에 기록한다. 다만 보너스 점수는 포탈
55: // 클리어 시점의 기본 점수 + 탈출 보너스를 기준으로 단 한 번 확정한다.
56: export function getBossClearBonus({ stageId = 'stage1', survivalSeconds = 0, cleared = false, bossDefeated = false } = {}, policy = getRankingScorePolicy()) {
57:   if (cleared !== true || bossDefeated !== true) return 0
58:   const base = getRankingBaseScore({ stageId, survivalSeconds }, policy)
59:   return Math.floor((base + getEscapeBonus({ stageId, survivalSeconds, cleared }, policy)) * BOSS_BONUS_RATE)
60: }
61: 
62: export function getRankingScorePolicy(seasonConfig = getAdminRankingSeasonConfig()) {
63:   const scorePolicy = seasonConfig?.scorePolicy ?? {}
64:   return {
65:     stageBonus: {
66:       stage1: readNonNegativeInt(scorePolicy.stageBonus?.stage1 ?? STAGE_BONUS.stage1),
67:       stage2: readNonNegativeInt(scorePolicy.stageBonus?.stage2 ?? STAGE_BONUS.stage2),
68:       stage3: readNonNegativeInt(scorePolicy.stageBonus?.stage3 ?? STAGE_BONUS.stage3),
69:       stage4: readNonNegativeInt(scorePolicy.stageBonus?.stage4 ?? STAGE_BONUS.stage4),
70:       stage5: readNonNegativeInt(scorePolicy.stageBonus?.stage5 ?? STAGE_BONUS.stage5),
71:       stage6: readNonNegativeInt(scorePolicy.stageBonus?.stage6 ?? STAGE_BONUS.stage6),
```
## 자판기 공통 계약

Recovery Drink 가격 5 gold, healHp 35. 이 값의 balanceStatus는 provisional-not-owner-approved이므로 최종 승인 밸런스로 표기하지 않는다. 상호작용 반경 2.25 units / 0.5625 blocks이며, 잔액/게임 상태/사거리/최대 HP 처리 등 실제 허용 조건은 아래 함수와 store 구매 경로다. 계정/서버 실제 잔액을 조회하거나 구매하지 않았다.

[Developer/r3f_prototype/src/lib/stageVending.js:L1 · a9f84bf8 · SHA 3ece7f4b519e](index.html#code-028)

```javascript
... 별도 근거 구간 ...
16:     label: 'Recovery Drink',
17:     priceGold: 5,
18:     effectType: 'heal',
19:     healHp: 35,
20:     balanceStatus: 'provisional-not-owner-approved',
21:   }),
22: })
23: 
24: export const STAGE_VENDING_PLACEMENTS = Object.freeze({
25:   // Preserve the accepted vending contract on the existing expansion maps.
26:   ...Object.fromEntries(Object.keys(EXPANSION_STAGES).map(stageId => [stageId, Object.freeze({
... 별도 근거 구간 ...
75: 
76: export function getStageVendingItem(itemId) {
77:   if (!Object.prototype.hasOwnProperty.call(STAGE_VENDING_ITEMS, itemId)) return null
78:   return STAGE_VENDING_ITEMS[itemId]
79: }
80: 
81: export function getStageVendingPlacement(stageId) {
82:   if (!Object.prototype.hasOwnProperty.call(STAGE_VENDING_PLACEMENTS, stageId)) return null
83:   return STAGE_VENDING_PLACEMENTS[stageId]
84: }
85: 
86: export function isWithinStageVendingRange(playerPosition, placement, radius = placement?.interactionRadiusUnits) {
87:   if (!playerPosition || !placement?.position) return false
88:   const px = Number(playerPosition.x)
89:   const pz = Number(playerPosition.z)
90:   const x = Number(placement.position.x)
91:   const z = Number(placement.position.z)
92:   const r = Number(radius)
93:   if (![px, pz, x, z, r].every(Number.isFinite) || r < 0) return false
94:   const dx = px - x
95:   const dz = pz - z
96:   return (dx * dx + dz * dz) <= (r * r)
97: }
```
[Developer/r3f_prototype/src/store/useGameStore.js:L1 · a9f84bf8 · SHA 263f032d74a1](index.html#code-031)

```javascript
... 별도 근거 구간 ...
880:     },
881: 
882:     purchaseStageVendingItem: (itemId, { machineId = null, stageId = null, gameKey = null } = {}) => {
883:       const item = getStageVendingItem(itemId)
884:       if (!item) return { ok: false, reason: 'invalid-item', itemId }
885:       if (!isFirebaseProgressHydrated()) return { ok: false, reason: 'progressUnavailable', itemId }
886:       const progressUid = getFirebaseProgressRuntimeSnapshot().uid
887:       const authUid = useAuthStore.getState().user?.uid
888:       const runOwnerUid = pendingRuns.get(get().progressRunId)?.uid
889:       if (!authUid || authUid !== progressUid || runOwnerUid !== authUid) return { ok: false, reason: 'progressUnavailable', itemId }
890:       let result = { ok: false, reason: 'not-applied', itemId }
891:       set((s) => {
892:         const reject = (reason) => { result = { ok: false, reason, itemId }; return s }
893:         if (s.phase !== 'playing') return reject('not-playing')
894:         if (stageId !== null && stageId !== s.currentStageId) return reject('stale-stage')
```
## 공통 검증 한계

이 팩의 QA는 고정 소스에서의 값 추출, 문서 구조·링크·원문 해시·ZIP 무결성 검사다. 기기에서의 프레임률/입력/보스 처치/해금 영속성/Firebase 실효 튜닝은 미검증이다. Stage 1 모바일 플레이 안정성 합격을 이 문서 QA로 대체하지 않는다.
## 최신 승인 스냅샷의 마틸다 대시

실제 대시가 시작될 때에만 해당 마틸다 인스턴스의 시작 횟수를 증가시킨다. 첫 대시는 기본 속도, 다음은 기본의 1.01배, 이후 매 시작마다 기본 속도의 1%를 가산한다. 복리 증가/프레임별 증가/기다리는 시간별 증가가 아니다. 인스턴스 초기화에서 횟수를 0으로 되돌리며 다른 스탯은 이 함수에서 바꾸지 않는다.

[Developer/r3f_prototype/src/lib/matildaDashSpeed.js:L1 · a9f84bf8 · SHA 3ae7adafc70a](index.html#code-036)

```javascript
... 별도 근거 구간 ...
1: // Actual dash starts only: first dash is base; later starts add 1% of base, never compound.
2: // Count is owned/reset by the Matilda instance, not global state or the frame clock.
3: export function getMatildaDashSpeed(baseSpeed, startedDashCount) {
4:   return baseSpeed * (1 + Math.max(0, startedDashCount - 1) * 0.01)
5: }
```
[Developer/r3f_prototype/src/components/Enemy.jsx:L1 · a9f84bf8 · SHA 26c11bca50a8](index.html#code-006)

```javascript
... 별도 근거 구간 ...
28: } from '../lib/chefBossPhase.js'
29: import { getStageBounds, getStageConfig } from '../lib/stageConfig.js'
30: import { getRuntimeElapsedMs } from '../lib/gameRuntimeTime.js'
31: import { getMatildaDashSpeed } from '../lib/matildaDashSpeed.js'
32: import { getSpawnCatchUpOffsetSec } from '../lib/spawnCatchUp.js'
33: import { isBossType } from '../lib/burstEvents.js'
34: import { deathSfxId } from '../lib/enemyDeathSfx.js'
35: import {
36:   B02_BLOCKADE_LINE_WIDTH,
37:   advanceB02CorridorBlockade,
38:   consumeB02CorridorBlockadeHit,
... 별도 근거 구간 ...
919:   const matildaLaughRemainingRef = useRef(0)
920:   const matildaLaughCuePendingRef = useRef(false)
921:   const matildaChargeStallMsRef = useRef(0)
922:   const matildaDashCountRef = useRef(0)
923:   const matildaPreviousChargePosRef = useRef({ x: spawnPos[0], z: spawnPos[2] })
924:   const chargeDir    = useRef(new THREE.Vector3())
925: 
926:   // B04 주방장 2페이즈 상태
927:   const chefPhaseRef = useRef(CHEF_PHASE1)
928:   const chefTelegraphStartRef = useRef(0)
929: 
... 별도 근거 구간 ...
988:     matildaLaughRemainingRef.current = isMatilda ? MATILDA_LAUGH_DURATION_MS : 0
989:     matildaLaughCuePendingRef.current = isMatilda
990:     matildaChargeStallMsRef.current = 0
991:     matildaDashCountRef.current = 0
992:     matildaContactKillCountdownRef.current = createMatildaContactKillCountdown()
993:     matildaPreviousChargePosRef.current.x = spawnPos[0]
994:     matildaPreviousChargePosRef.current.z = spawnPos[2]
995:     chefPhaseRef.current = CHEF_PHASE1
996:     setIsChefPhase2(false)
997:     chefTelegraphStartRef.current = 0
998:     chefProjectileKindRef.current = 0
... 별도 근거 구간 ...
1436:           matildaPreviousChargePosRef.current.x = t.x
1437:           matildaPreviousChargePosRef.current.z = t.z
1438:           matildaChargeStallMsRef.current = 0
1439:           matildaDashCountRef.current += 1
1440:           chargeState.current = 'charge'
1441:           queueVisualState('animPhase', 'charge')
1442:           _applyRotation(groupRef, chargeDir.current.x, chargeDir.current.z, 1)
1443:           emitSfx(MATILDA_DASH_SFX)
1444:         } else if (chargeState.current === 'charge') {
1445:           const cd = chargeDir.current
1446:           const previous = matildaPreviousChargePosRef.current
1447:           const movedAlong = (t.x - previous.x) * cd.x + (t.z - previous.z) * cd.z
1448:           const dashSpeed = getMatildaDashSpeed(stats.chargeSpeed, matildaDashCountRef.current)
1449:           const expectedMove = dashSpeed * delta
1450:           const hitDistance = getChargeHitDistance(stats, true)
1451:           const blockedFrame = isMatildaChargeBlockedValues(movedAlong, expectedMove, dist, hitDistance)
1452:           matildaChargeStallMsRef.current = blockedFrame
1453:             ? matildaChargeStallMsRef.current + delta * 1000
1454:             : 0
1455:           if (shouldReverseMatildaChargeOnObstacleValues(movedAlong, expectedMove, dist, hitDistance, matildaChargeStallMsRef.current)) {
```
## 전 플레이 가능 스테이지 자판기 연결

Stage 1~10 모두 placement가 선언되고 FloorVisual → StageVendingLayer 경로가 렌더한다. 단 Stage5 환경 스케일 정본이 없으면 FloorVisual 자체가 null인 기존 가드가 있어 화면 표시를 무조건 보장하지 않는다. HUD는 현재 스테이지 placement에 맞춘 StageVendingPrompt를 연결한다. 회전 Y는 north=0, south=π, west=π/6, east=-π/6이며 이전 ±π/2 기록을 현재 값으로 복제하지 않는다.

[Developer/r3f_prototype/src/components/Floor.jsx:L1 · a9f84bf8 · SHA 04249a64324b](index.html#code-040)

```javascript
... 별도 근거 구간 ...
6: import Stage5Environment, { getStage5EnvironmentScale } from './Stage5Environment.jsx'
7: import StageVendingLayer from './StageVendingLayer.jsx'
8: import StudioTunedGroup from './StudioTunedGroup.jsx'
9: import { getStageBounds } from '../lib/stageConfig.js'
10: 
11: export function FloorVisual({ stageId = 'stage1' }) {
12:   if (stageId === 'stage5' && !getStage5EnvironmentScale()) return null
13: 
14:   return (
15:     <>
... 별도 근거 구간 ...
21:       <StageObjectLayer stageId={stageId} />
22:       <StageVendingLayer stageId={stageId} />
23:     </>
24:   )
25: }
... 별도 근거 구간 ...
27: export default function Floor({ stageId = 'stage1' }) {
28:   if (stageId === 'stage5' && !getStage5EnvironmentScale()) return null
29: 
30:   // 맵 경계는 스테이지별로 다르다 (stage1: 세로로 긴 직사각형, stage2: 정사각).
31:   const { halfX, halfZ } = getStageBounds(stageId)
... 별도 근거 구간 ...
34:     <group>
35:       <FloorVisual stageId={stageId} />
36:       <StageObjectColliderLayer stageId={stageId} />
37: 
38:       <RigidBody type="fixed" colliders="cuboid">
```
[Developer/r3f_prototype/src/components/StageVendingLayer.jsx:L1 · a9f84bf8 · SHA 33fadf9c0bb7](index.html#code-037)

```javascript
... 별도 근거 구간 ...
5: 
6: const WALL_ROTATION_Y = Object.freeze({
7:   north: 0,
8:   south: Math.PI,
9:   west: Math.PI / 6,
... 별도 근거 구간 ...
12: 
13: function placementToVector(placement) {
14:   return [placement.position.x, placement.position.y ?? 0, placement.position.z]
15: }
16: 
17: export function getStageVendingMachineTransform(stageId) {
18:   const placement = getStageVendingPlacement(stageId)
19:   if (!placement) return null
20:   return {
21:     id: placement.id,
22:     position: placementToVector(placement),
23:     rotation: [0, WALL_ROTATION_Y[placement.wallSide] ?? 0, 0],
24:   }
25: }
26: 
... 별도 근거 구간 ...
37:         rotation={transform.rotation}
38:         soldOut={purchasedItemIds.includes(STAGE_VENDING_ITEM_IDS.RECOVERY_DRINK)}
39:       />
40:     </group>
41:   )
```
[Developer/r3f_prototype/src/components/HUD.jsx:L1 · a9f84bf8 · SHA ed571a8f6148](index.html#code-038)

```javascript
... 별도 근거 구간 ...
46: import MissionTracker from './MissionTracker.jsx'
47: import StageVendingPrompt from './StageVendingPrompt.jsx'
48: import { milestoneLabel, t as translate, useT, weaponLabel } from '../lib/i18n.js'
49: import { dispatchStarlinkCheatCrash } from './Weapons/Starlink.jsx'
50: import pencilIconSrc from '../assets/weapon_icon/01_wea_pencil.png.webp'
... 별도 근거 구간 ...
1524: 
1525:       <StageVendingPrompt />
1526:       <MissionTracker
1527:         missionProgress={missionProgress}
1528:         hidden={phase !== 'playing' || bossWarning != null || e04IntroWarning != null || matildaWarning != null || formationWarning != null || questInventoryOpen}
```
[Developer/r3f_prototype/src/components/StageVendingPrompt.jsx:L1 · a9f84bf8 · SHA 07b1a03da404](index.html#code-041)

```javascript
... 별도 근거 구간 ...
24: 
25: export function getStageVendingUiState({ phase, player, goldTotal, purchasedItemIds, inRange, item }) {
26:   if (phase !== 'playing' || !Number.isFinite(player?.hp) || player.hp <= 0) return 'notPlaying'
27:   if (!inRange) return 'outOfRange'
28:   if (purchasedItemIds.includes(item.id)) return 'purchased'
29:   if ((player?.hp ?? 0) >= (player?.maxHp ?? 0)) return 'full'
30:   if ((goldTotal ?? 0) < item.priceGold) return 'insufficient'
31:   return 'available'
... 별도 근거 구간 ...
52:   }))
53:   const placement = useMemo(() => getStageVendingPlacement(currentStageId), [currentStageId])
54:   const [inRange, setInRange] = useState(() => isWithinStageVendingRange(playerPos, placement))
55:   const [feedback, setFeedback] = useState(null)
56: 
57:   useEffect(() => { setFeedback(null) }, [currentStageId, gameKey])
58: 
59:   useEffect(() => {
... 별도 근거 구간 ...
80:   })
81:   const visible = state !== 'outOfRange' && state !== 'notPlaying'
82:   const disabled = state !== 'available'
83:   const statusText = feedback?.message ?? STATUS_COPY[state]
84: 
85:   const onPurchase = useCallback((event) => {
86:     event.preventDefault()
87:     event.stopPropagation()
```
